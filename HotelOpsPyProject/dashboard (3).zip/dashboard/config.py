class Config:
    API_URL = 'https://hotelops.in/API/EmployeeDashboardMobileAPI/' 
    TOKEN_URL = 'https://hotelops.in//API/PyModuleAuthAPI/GenerateToken'
    MobileAppToken='cOwzYa08a1Z9rF4jwbylBiMmkvPym1sKVYau7lzRQgUTE3CtfgvQQ0I0KKWD58q28xpZHD6cE7rg3a2rbpLH1JqXYFRZopr346PFCgTdu8oe1SgcJBiSLGZxbcCgfvMm08by9mLc3vyTmX25ggX8jMAQxcQwxmg2kcZ4HZw1uI4Zo4TBTLwszOZyyo0Bb0HPJTBUEJ65wAIskDEKArKhRu3MLefqRDaebVjTopAfxkCyehLPSd3e0ct05Y'
    