    const chartDomonroll = document.getElementById('onrollChart');
    const onrolldataChart = echarts.init(chartDomonroll);
    try {
        const response = await fetch(`api/CEO_ManningGuide/?level=${level}`);
        if (!response.ok) {
            throw new Error('Network response was not ok ' + response.statusText);
        }
        const data = await response.json();
        
        const HTL = data.map(item => item.OnRoll.Department);
        const Budget = data.map(item => item.OnRoll.Budget);
        const Actual = data.map(item => item.OnRoll.Actual);
        const Variance = data.map(item => item.OnRoll.Variance);
        
        function formatToINR(number) {
            if (number === undefined || number === null || isNaN(number)) {
                return 0; 
            }
            return number.toLocaleString('en-IN');
        }
        
        const option = {
            tooltip: {
                trigger: 'axis',
                axisPointer: { type: 'shadow' },
            },
            legend: {
                data: ['Budget', 'Actual', 'Variance']
            },
            grid: {
                left: '3%', right: '3%', bottom: '10%', containLabel: true
            },
            xAxis: {
                type: 'category',
                data: HTL,
                axisLabel: {
                    interval: 0,
                    rotate: 45,  // Tilts labels for readability
                    fontSize: 9,
                },
                
                barCategoryGap: '50%', 
            },
            yAxis: {
                type: 'value',
            },
            series: [
                {
                    name: 'Budget',  // Add Total series
                    type: 'bar',
                    barWidth: '30%',  // Set width for the bar
                    data: Budget,
                    itemStyle: { color: 'rgb(95, 75, 139)' },  // Color for total contracts
                    label: {
                        show: true,
                        position: 'top',
                        fontSize: 9,
                        formatter: function (params) {
                            let value = params.value;
                            if (value >= 10000000) {
                                return (value / 10000000).toFixed(0) + 'Cr'; // Crores (for values >= 1 crore)
                            } else if (value >= 100000) {
                                return (value / 100000).toFixed(0) + 'L';  // Lakhs (for values >= 1 lakh)
                            } else if (value >= 1000) {
                                return (value / 1000).toFixed(0) + 'k';    // Thousands (for values >= 1 thousand)
                            } else {
                                return value;  // If value is below 1000, show it as it is
                            }
                        }
                    }
                   
                },
                
                {
                    name: 'Actual',  // Active series
                    type: 'bar',
                    barWidth: '30%',  // Set width for the bar
                    data: Actual,
                    itemStyle: { color: 'rgb(140,217,201)' },  // Color for active contracts
                    label: {
                        show: true,
                        position: 'top',
                        fontSize: 9,
                        formatter: function (params) {
                            let value = params.value;
                            if (value >= 10000000) {
                                return (value / 10000000).toFixed(0) + 'Cr'; 
                            } else if (value >= 100000) {
                                return (value / 100000).toFixed(0) + 'L';  // Lakhs (for values >= 1 lakh)
                            } else if (value >= 1000) {
                                return (value / 1000).toFixed(0) + 'k';    // Thousands (for values >= 1 thousand)
                            } else {
                                return value;  // If value is below 1000, show it as it is
                            }
                        },
                        
                    }
                },
                {
                    name: 'Variance',  // Expired series
                    type: 'bar',
                    barWidth: '30%',  // Set width for the bar
                    data: Variance,
                    itemStyle: { color: 'rgb(238,164,127)' } , // Color for expired contracts
                    label: {
                        show: true,
                        fontSize: 9,
                        position: 'top',
                        formatter: function (params) {
                            let value = params.value;
                            let absValue = Math.abs(value);  
                            let formattedValue;
                            if (absValue >= 10000000) {
                                formattedValue = (absValue / 10000000).toFixed(0) + 'Cr'; 
                            } else if (absValue >= 100000) {
                                formattedValue = (absValue / 100000).toFixed(0) + 'L';  
                            } else if (absValue >= 1000) {
                                formattedValue = (absValue / 1000).toFixed(0) + 'k';    
                            } else {
                                formattedValue = absValue;  
                            }
                            return value < 0 ? '-' + formattedValue : formattedValue;
                                               
                        }
                    }
                }
            ]
        };

        onrolldataChart.setOption(option);
    } 
    catch (error) {
        hideLoader(chartType);
        console.error('Error fetching mainingGuideChart data:', error);
    }