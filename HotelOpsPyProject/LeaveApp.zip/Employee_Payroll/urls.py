from django.urls import path
from .views import Payroll_List,View_Attendance,View_Emmployee_Salary_Details,Generate_Salary_Slip,Update_Attendance,UpdateRequest,UpdateRequestlist,UpdateRequestlist_HR,Employees_Payroll_List,Upload_Attendace,Update_Attendance_HR,Daily_Attendace,Upload_Attendance_List,AttendanceProcess,OrgConfigList,AddConfig,index,all_events,ConfigDelete,SalaryList,DumpAttendace,SalarySendEmails,update_verification,AttendaceMonthlyReport,AttendanceLockView,UpdateStatus,add_event,remove,download_weekoff,upload_weekoff,ShfitList,UpdateShift,IntialShfitCreate,AttendaceCorrectEtmExlUp,UploadAttendanceSalaryFile,download_file,AttendanceSalaryList,attendance_report
# ,GenerateWeekoff
urlpatterns = [
    path('View_Attendance/', View_Attendance, name='View_Attendance'),
    path('', View_Attendance, name='View_Attendance'),
    path('AttendaceCorrectEtmExlUp/', AttendaceCorrectEtmExlUp, name='AttendaceCorrectEtmExlUp'),
    path('UploadAttendanceSalaryFile/', UploadAttendanceSalaryFile, name='UploadAttendanceSalaryFile'),
    path('download_file/', download_file, name='download_file'),
    path('AttendanceSalaryList/', AttendanceSalaryList, name='AttendanceSalaryList'),


    
    
    # path('ReadAttendanceFromAzure/', ReadAttendanceFromAzure, name='ReadAttendanceFromAzure'),

    
    # path('get_leave_application/', get_leave_application, name='get_leave_application'),
    # path('GetAttendance/', GetAttendance, name='GetAttendance'),


    path('Payroll_List',Payroll_List,name = "Payroll_List"),
    path('View_Emmployee_Salary_Details/', View_Emmployee_Salary_Details, name='View_Emmployee_Salary_Details'),
    path('Generate_Salary_Slip/', Generate_Salary_Slip, name='Generate_Salary_Slip'),
    path('Update_Attendance/', Update_Attendance, name='Update_Attendance'),
    path('Update_Attendance_HR/', Update_Attendance_HR, name='Update_Attendance_HR'),
    path('UpdateRequest/', UpdateRequest, name='UpdateRequest'),
    path('UpdateRequestlist/', UpdateRequestlist, name='UpdateRequestlist'),
    path('UpdateRequestlist_HR/', UpdateRequestlist_HR, name='UpdateRequestlist_HR'),
    path('Employees_Payroll_List/', Employees_Payroll_List, name='Employees_Payroll_List'),
    path('Upload_Attendace/', Upload_Attendace, name='Upload_Attendace'),
    path('AttendaceMonthlyReport/', AttendaceMonthlyReport, name='AttendaceMonthlyReport'),
    
    path('Daily_Attendace/', Daily_Attendace, name='Daily_Attendace'),
    path('AttendanceLockView/', AttendanceLockView, name='AttendanceLockView'),
    # path('GenerateWeekoff/', GenerateWeekoff, name='GenerateWeekoff'),



    path('UpdateStatus/', UpdateStatus, name='UpdateStatus'),

    
    path('Upload_Attendance_List/', Upload_Attendance_List, name='Upload_Attendance_List'),

    path('SalaryList/', SalaryList, name='SalaryList'),
    path('update_verification/', update_verification, name='update_verification'),

    



    path('AttendanceProcess/', AttendanceProcess, name='AttendanceProcess'),
    path('DumpAttendace/', DumpAttendace, name='DumpAttendace'),


    #  OrgConfig
    path('OrgConfigList/', OrgConfigList, name='OrgConfigList'),
    path('AddConfig/', AddConfig, name='AddConfig'),
    path('ConfigDelete/', ConfigDelete, name='ConfigDelete'),

    


    # Weekoff Mapping 
    path('index', index, name='index'), 
    path('all_events/', all_events, name='all_events'), 
    path('add_event/', add_event, name='add_event'), 
    path('remove/', remove, name='remove'),
    path('download_weekoff/', download_weekoff, name='download_weekoff'),
    path('upload_weekoff/', upload_weekoff, name='upload_weekoff'),


    # shfit 
    
    path('ShfitList/', ShfitList, name='ShfitList'),
    path('IntialShfitCreate/', IntialShfitCreate, name='IntialShfitCreate'),
    path('UpdateShift/', UpdateShift, name='UpdateShift'),


    path('attendance-report/', attendance_report, name='attendance_report'),
 

    # SendEmails    
    path('SalarySendEmails/', SalarySendEmails, name='SalarySendEmails'),




    

]
 

 