from django.db import models
from hotelopsmgmtpy.GlobalConfig import MasterAttribute
from django.utils import timezone
import datetime


class Organization_Details(models.Model):
    OID_Code =  models.CharField(max_length=255,null=True,blank=True)
    OID = models.CharField(max_length=255,null=True,blank=True)
    
    UploadFormatType = models.CharField(max_length=255,null=True,blank=True)
    DownloadFormat = models.FileField(upload_to="Employee_Payroll/DownloadFormat", max_length=100,null=True,blank=True)
    EndDate =  models.IntegerField(null=False,blank=False)


    OrgUrl  = models.TextField(null=True, blank=True)
    cid =  models.CharField(max_length=255,null=True,blank=True)


    OrganizationID = models.BigIntegerField(default=0)
    CreatedBy = models.BigIntegerField(default=0)
    CreatedDateTime = models.DateTimeField(default=datetime.datetime.now())
    ModifyBy = models.BigIntegerField(default=0)
    ModifyDateTime = models.DateTimeField(default=datetime.datetime.now())
    IsDelete = models.BooleanField(default=False)

    def __str__(self):
        return f'{self.OID_Code}   {self.OID}'






from django.utils import timezone


class APILog(models.Model):
    TimeStamp = models.DateTimeField(default=timezone.now)
    Url = models.URLField(max_length=1000)
    Status_Code = models.IntegerField()
    Response_Time = models.FloatField()
    Message = models.TextField()
    
    
    OrganizationID = models.BigIntegerField(default=0)
    CreatedBy = models.BigIntegerField(default=0)
    CreatedDateTime = models.DateTimeField(default=timezone.now)
    ModifyBy = models.BigIntegerField(default=0)
    ModifyDateTime = models.DateTimeField(default=timezone.now)
    IsDelete = models.BooleanField(default=False)

    


class Raw_Attendance_Data_File(models.Model):
    File_Name = models.CharField(max_length=255,null=True,blank=True)
    Attendance_Date = models.DateField()
    
    OrganizationID = models.BigIntegerField(default=0)
    CreatedBy = models.BigIntegerField(default=0)
    CreatedDateTime = models.DateTimeField(default=datetime.datetime.now())
    ModifyBy = models.BigIntegerField(default=0)
    ModifyDateTime = models.DateTimeField(default=datetime.datetime.now())
    IsDelete = models.BooleanField(default=False)






class Raw_Attendance_Data(models.Model):
    EmployeeCode = models.CharField(max_length=255)
    Date =models.CharField(max_length=255,null=True,blank=True)
    Time = models.CharField(max_length=255,null=True,blank=True)
    Status = models.CharField(max_length=255,null=True,blank=True)

    OrganizationID = models.BigIntegerField(default=0)
    CreatedBy = models.BigIntegerField(default=0)
    CreatedDateTime = models.DateTimeField(default=datetime.datetime.now())
    ModifyBy = models.BigIntegerField(default=0)
    ModifyDateTime = models.DateTimeField(default=datetime.datetime.now())
    IsDelete = models.BooleanField(default=False)

    



class Attendance_Data(models.Model):
    EmployeeCode = models.CharField(max_length=255)
    Date = models.DateField()
    In_Time =  models.CharField(max_length=255,null=True,blank=True)
    Out_Time = models.CharField(max_length=255,null=True,blank=True)

    S_In_Time =  models.CharField(max_length=255,null=True,blank=True)
    S_Out_Time = models.CharField(max_length=255,null=True,blank=True)


    Duty_Hour  = models.CharField(max_length=255,null=True,blank=True)
    Status = models.CharField(max_length=255,null=True,blank=True)
    IsUpload = models.BooleanField(default=False)
    
    OrganizationID = models.BigIntegerField(default=0)
    CreatedBy = models.BigIntegerField(default=0)
    CreatedDateTime = models.DateTimeField(default=datetime.datetime.now())
    ModifyBy = models.BigIntegerField(default=0)
    ModifyDateTime = models.DateTimeField(default=datetime.datetime.now())
    IsDelete = models.BooleanField(default=False)

class AttendanceLock(models.Model):
    EmployeeCode = models.CharField(max_length=255)
    month = models.IntegerField()
    year = models.IntegerField()
    month_name = models.CharField(max_length=255,null=True,blank=True) 
    total_no_Days_in_month = models.CharField(max_length=255)
    PaiDays  = models.CharField(max_length=255)
    IsLock = models.BooleanField(default=False)

    
    
    OrganizationID = models.BigIntegerField(default=0)
    CreatedBy = models.BigIntegerField(default=0)
    CreatedDateTime = models.DateTimeField(default=datetime.datetime.now())
    ModifyBy = models.BigIntegerField(default=0)
    ModifyDateTime = models.DateTimeField(default=datetime.datetime.now())
    IsDelete = models.BooleanField(default=False)




class AttendanceSalaryFile(models.Model):
    Type = models.CharField(max_length=255,null=True,blank=True)
    Month = models.CharField(max_length=255,null=True,blank=True)
    Year = models.CharField(max_length=255,null=True,blank=True)
   
    FileName = models.CharField(null=True,blank=True,max_length=255)
    FileTitle = models.CharField(null=True,blank=True,max_length=255)
    
    PdfFileName = models.CharField(null=True,blank=True,max_length=255)
    PdfFileTitle = models.CharField(null=True,blank=True,max_length=255)
    
    
    OrganizationID = models.BigIntegerField(default=0)
    CreatedBy = models.BigIntegerField(default=0)
    CreatedDateTime = models.DateTimeField(default=datetime.datetime.now())
    ModifyBy = models.BigIntegerField(default=0)
    ModifyDateTime = models.DateTimeField(default=datetime.datetime.now())
    IsDelete = models.BooleanField(default=False)




class SalarySlip(models.Model):
    EmployeeCode = models.CharField(max_length=255)
    Emp_Name = models.CharField(max_length=255,null=True,blank=True)
    
    month = models.IntegerField()
    year = models.IntegerField()
    month_name = models.CharField(max_length=255,null=True,blank=True) 
    
    generated = models.BooleanField(default=False)
    HrVerify = models.BooleanField(default=False)
    FcVerify =  models.BooleanField(default=False)
    
    Desingation = models.CharField(max_length=255,null=True,blank=True)
    Department = models.CharField(max_length=255,null=True,blank=True)
    DOJ = models.CharField(max_length=255,null=True,blank=True)
    DOB = models.CharField(max_length=255,null=True,blank=True)
    
    total_no_Days_in_month =   models.CharField(max_length=255,null=True,blank=True)
    no_of_days =   models.CharField(max_length=255,null=True,blank=True)
    no_of_absent = models.CharField(max_length=255,null=True,blank=True)
    
    fixed_basic =   models.CharField(max_length=255,null=True,blank=True)
    fixed_HRA =  models.CharField(max_length=255,null=True,blank=True)
    ConveyanceAllowance = models.CharField(max_length=255,null=True,blank=True)
    CCA	 = models.CharField(max_length=255,null=True,blank=True)
    OtherAllowance = models.CharField(max_length=255,null=True,blank=True)
    gross_salary =   models.CharField(max_length=255,null=True,blank=True)
    
    
    Earned_Basic =   models.CharField(max_length=255,null=True,blank=True)
    Earned_HRA =   models.CharField(max_length=255,null=True,blank=True)
    Arrear =  models.CharField(max_length=255,null=True,blank=True)
    RewardIncentive	 =  models.CharField(max_length=255,null=True,blank=True)
    Earned_Total_Allowance = models.CharField(max_length=255,null=True,blank=True)

    
    ESIC =   models.CharField(max_length=255,null=True,blank=True)
    EPFO =   models.CharField(max_length=255,null=True,blank=True)
    PT	= models.CharField(max_length=255,null=True,blank=True)
    Meals	=models.CharField(max_length=255,null=True,blank=True)
    Accommodation	= models.CharField(max_length=255,null=True,blank=True)
    AdvanceLoan	= models.CharField(max_length=255,null=True,blank=True)
    TaxDeduction	= models.CharField(max_length=255,null=True,blank=True)
    OtherDeduction	= models.CharField(max_length=255,null=True,blank=True)


    EmployeePF = 	models.CharField(max_length=255,null=True,blank=True)
    CompanyContributionToESIC =	models.CharField(max_length=255,null=True,blank=True)
    TotalCompanyContribution =	models.CharField(max_length=255,null=True,blank=True)
    CTC = models.CharField(max_length=255,null=True,blank=True)

    
    Total_Earning =   models.CharField(max_length=255,null=True,blank=True)
    Total_Deduction =  models.CharField(max_length=255,null=True,blank=True)
    Net_salary =   models.CharField(max_length=255,null=True,blank=True)
    Net_salary_In_Words =   models.CharField(max_length=255,null=True,blank=True) 
    
    ProvidentFundNumber = models.CharField(max_length=255,null=True,blank=True)
    ESINumber = models.CharField(max_length=255,null=True,blank=True)
    BankAccountNumber = models.CharField(max_length=255,null=True,blank=True)
    PayMode =  models.CharField(max_length=255,null=True,blank=True)
    BankName =   models.CharField(max_length=255,null=True,blank=True)
    BankIFSCCode =   models.CharField(max_length=255,null=True,blank=True)
    BankBranch = models.CharField(max_length=255,null=True,blank=True)





    OrganizationID = models.BigIntegerField(default=0)
    CreatedBy = models.BigIntegerField(default=0)
    CreatedDateTime = models.DateTimeField(default=datetime.datetime.now())
    ModifyBy = models.BigIntegerField(default=0)
    ModifyDateTime = models.DateTimeField(default=datetime.datetime.now())
    IsDelete = models.BooleanField(default=False)


    def get_approval_status_html(self):
        if not self.HrVerify and not self.FcVerify:
            return '<p style="color: #f8ac59;">Pending from HR</p>'
        if self.HrVerify and not self.FcVerify:
            return '<p style="color: #f8ac59;">Approved by HR <br> Pending from Finance</p>'
        elif self.HrVerify and self.FcVerify:
            return '<p style="color: #1ab394;">Approved</p>'
        else:
            return ''



    

class Update_Attendance_Request(models.Model):
    Attendance_Data = models.ForeignKey(Attendance_Data,on_delete=models.CASCADE)
    Reason = models.TextField(null= True,blank= True)
    Apporve_status = models.CharField(max_length=255,null=True,blank=True,default=0) 
    
    OrganizationID = models.BigIntegerField(default=0)
    CreatedBy = models.BigIntegerField(default=0)
    CreatedDateTime = models.DateTimeField(default=datetime.datetime.now())
    ModifyBy = models.BigIntegerField(default=0)
    ModifyDateTime = models.DateTimeField(default=datetime.datetime.now())
    IsDelete = models.BooleanField(default=False)






class SalaryEmails(models.Model):
    EmpCode = models.CharField(max_length=255) 
    email = models.CharField(max_length=255)

    OrganizationID = models.BigIntegerField(default=0)
    CreatedBy = models.BigIntegerField(default=0)
    CreatedDateTime = models.DateTimeField(default=datetime.datetime.now())
    ModifyBy = models.BigIntegerField(default=0)
    ModifyDateTime = models.DateTimeField(default=datetime.datetime.now())
    IsDelete = models.BooleanField(default=False)




class WeekOffDetails(models.Model):
    Emp_Code = models.CharField(max_length=255,null=False,blank=False)
    WeekoffDate  = models.DateField(null=False,blank=False)
    
     
    OrganizationID = models.BigIntegerField(default=0)
    CreatedBy = models.BigIntegerField(default=0)
    CreatedDateTime = models.DateTimeField(default=datetime.datetime.now())
    ModifyBy = models.BigIntegerField(default=0)
    ModifyDateTime = models.DateTimeField(default=datetime.datetime.now())
    IsDelete = models.BooleanField(default=False)


class ShfitMaster(models.Model):
    EmployeeCode = models.CharField(max_length=255,null=False,blank=False)
    ShfitType = models.CharField(max_length=255,null=False,blank=False,default="General")
     
    OrganizationID = models.BigIntegerField(default=0)
    CreatedBy = models.BigIntegerField(default=0)
    CreatedDateTime = models.DateTimeField(default=datetime.datetime.now())
    ModifyBy = models.BigIntegerField(default=0)
    ModifyDateTime = models.DateTimeField(default=datetime.datetime.now())
    IsDelete = models.BooleanField(default=False)
    


class PayrollErrorLog(models.Model):
    ErrorMessage  = models.CharField(max_length=255,null=False,blank=False)
    ErrorPage = models.CharField(max_length=255,null=False,blank=False)
    ErrorFucntion = models.CharField(max_length=255,null=False,blank=False)
   

    OrganizationID = models.BigIntegerField(default=0)
    CreatedBy = models.BigIntegerField(default=0)
    CreatedDateTime = models.DateTimeField(default=datetime.datetime.now())
    ModifyBy = models.BigIntegerField(default=0)
    ModifyDateTime = models.DateTimeField(default=datetime.datetime.now())
    IsDelete = models.BooleanField(default=False)
