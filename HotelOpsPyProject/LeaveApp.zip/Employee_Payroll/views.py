from django.shortcuts import render,redirect
from hotelopsmgmtpy.GlobalConfig import MasterAttribute,OrganizationDetail
from app.models import OrganizationMaster,EmployeeMaster
from .models import Attendance_Data,Update_Attendance_Request,SalarySlip,Raw_Attendance_Data,Organization_Details,SalaryEmails,Raw_Attendance_Data_File,WeekOffDetails,PayrollErrorLog,AttendanceLock,ShfitMaster
from Leave_Management_System.models import  Leave_Type_Master,Emp_Leave_Balance_Master
import calendar
import requests
from django.contrib import messages
from django.db import   transaction
from datetime import datetime, timedelta
from datetime import datetime
from Employee_Payroll.models import Raw_Attendance_Data, Attendance_Data
from Leave_Management_System.models import Leave_Application
from django.db.models import Q

from django.db.models import Min, Max
from datetime import datetime
import csv
import pandas as pd
from django.shortcuts import get_object_or_404



from django.http import HttpResponse
from io import BytesIO
from django.template.loader import get_template
from xhtml2pdf import pisa
from app.views import EmployeeDataSelect



# @transaction.atomic
# def Upload_Attendace(request):
#     if 'OrganizationID' not in request.session:
#         return redirect(MasterAttribute.Host)
#     else:
#         print("Show Page Session")

#     OrganizationID = request.session["OrganizationID"]
#     print(OrganizationID)
#     UserID = str(request.session["UserID"])
#     UserType = request.session["UserType"]
#     EmployeeCode = request.session["EmployeeCode"]
#     print(EmployeeCode)
#     hotelapitoken = MasterAttribute.HotelAPIkeyToken
#     headers = {
#         'hotel-api-token': hotelapitoken  
#     }
#     api_url = "http://hotelops.in/API/PyAPI/HREmployeeList?OrganizationID="+str(OrganizationID)
    

#     try:
#         response = requests.get(api_url, headers=headers)
#         response.raise_for_status() 
#         emp_list = response.json()
     
#     except requests.exceptions.RequestException as e:
#         print(f"Error occurred: {e}")
     
#     OrganizationID = request.session["OrganizationID"]
#     UserID = str(request.session["UserID"])
#     try :
#         org_obj  = Organization_Details.objects.get(OID=OrganizationID,IsDelete=False)
#         OID_Code  = org_obj.OID_Code
#     except Organization_Details.DoesNotExist:
#         messages.warning(request,'Data Configuration is not present for Your Organization Contact To IT  ')
#         return redirect('Daily_Attendace')
    
    
#     with transaction.atomic():
#         if request.method == "POST":
#             file = request.FILES.get('file')
#             Attendance_Date = request.POST['Attendance_Date']            
#             parsed_date = datetime.strptime(Attendance_Date, '%Y-%m-%d')
#             messages_Date = parsed_date.strftime('%d-%m-%Y')
#             attendance_date_obj = datetime.strptime(Attendance_Date, '%Y-%m-%d').date()
#             if org_obj.UploadFormatType != "." +Path(file.name).suffix.lower()[1:]:
#                     messages.warning(request,f'Upload format type is not macthed to  {org_obj.UploadFormatType}')
#                     return redirect('Upload_Attendace')

#             if file.name.endswith('.xls') or file.name.endswith('.xlsx'):
                    
#                     df = pd.read_excel(file)
                    
                   
#                     for index, row in df.iterrows():
#                         employee_code = row['Employee Code']
#                         EmployeeCode =  str(OID_Code)+employee_code
                        
                       
#                         date_excel = row['AttendanceDate'].date()
                        
                       
#                         if date_excel != attendance_date_obj:  
#                             messages.warning(request, f"Attendance record of file does not match with selected date {messages_Date}")    
#                             return redirect('Upload_Attendace')
                        
#                         in_time = row['InTime']
#                         out_time = row['OutTime']
                        
                       
#                         in_time_str = str(in_time) if not pd.isna(in_time) else '00:00'
#                         out_time_str = str(out_time) if not pd.isna(out_time) else '00:00'

                       
#                         if in_time_str != '00:00' and out_time_str != '00:00':
#                             Duty_IN = datetime.strptime(in_time_str, '%H:%M')
#                             Duty_OUT = datetime.strptime(out_time_str, '%H:%M')
#                             Duty_Hour = Duty_OUT - Duty_IN
#                         else:
#                             Duty_Hour = timedelta(hours=0)
                        
                       
#                         status = "Absent"
#                         if Duty_Hour >= timedelta(hours=9):
#                             status = "Present"
#                         elif Duty_Hour >= timedelta(hours=5):
#                             status = "Half Day Present"
                        
                      
#                         obj = Attendance_Data.objects.create(
#                             EmployeeCode=EmployeeCode,
#                             Date=date_excel,
#                             In_Time=in_time,
#                             Out_Time=out_time,
#                             Duty_Hour=Duty_Hour.total_seconds() // 3600 if Duty_Hour else None,
#                             OrganizationID=OrganizationID,
#                             CreatedBy=UserID,
#                             Status=status,
#                             IsUpload = True
#                         )
                        
                       
#                         if in_time == '00:00' and out_time == '00:00':
#                             try:
#                                 leave = Leave_Application.objects.get(Start_Date__lte=Attendance_Date, End_Date__gte=Attendance_Date, IsDelete=False, Emp_code=EmployeeCode, Status=1)
#                                 obj.Status = leave.Leave_Type_Master.Type
#                                 obj.save()
#                             except Leave_Application.DoesNotExist:
#                                 try:
#                                     weekoff =  WeekOffDetails.objects.get(Emp_Code=EmployeeCode,WeekoffDate=Attendance_Date,IsDelete=False)
#                                     obj.Status = "WeekOff"
#                                     obj.save()
#                                 except WeekOffDetails.DoesNotExist:
#                                      obj.Status = "Absent"
#                                      obj.save()


#                     messages.success(request, f"Uploaded Successfully for {messages_Date}")    
#                     return redirect('/Employee_Payroll/Daily_Attendace/?Q_Date='+str(Attendance_Date))
                            

#             elif file.name.endswith('.csv'):
#                 csv_reader = csv.DictReader(file.read().decode('utf-8').splitlines())
#                 for row in csv_reader:
                 
#                     employee_code = row['Employee Code']
                    
                    

#                     EmployeeCode = str(OID_Code)+employee_code
                    
#                     date_Csv = datetime.strptime(row['AttendanceDate'], '%d-%m-%Y').date()
                            
#                     if date_Csv != attendance_date_obj:  
                        
#                         messages.warning(request, f"Attendance record of file does not match with selected date {messages_Date}")    
#                         return redirect('Upload_Attendace')

                    
                    
#                     in_time = row['InTime']
#                     out_time = row['OutTime']
#                     if in_time != '00:00' and out_time != '00:00':
                    
#                         Duty_IN = datetime.strptime(in_time, '%H:%M')
#                         Duty_OUT = datetime.strptime(out_time, '%H:%M')
                    
#                         Duty_Hour = Duty_OUT - Duty_IN
                    
#                     else:
#                         Duty_Hour = timedelta(hours=0)
#                     status = "Absent"
#                     if Duty_Hour >= timedelta(hours=9):
#                         status = "Present"
#                     elif Duty_Hour >= timedelta(hours=5):
#                         status = "Half Day Present"

                    
                    
                    
#                     obj=Attendance_Data.objects.create(
#                         EmployeeCode=EmployeeCode,
#                         Date=date_Csv,
#                         In_Time=in_time,
#                         Out_Time=out_time,
#                         Duty_Hour=Duty_Hour.total_seconds() // 3600 if Duty_Hour else None,
#                         OrganizationID=OrganizationID,
#                         CreatedBy=UserID,
#                         Status=status,
#                           IsUpload = True
#                     )

                    
#                     if in_time == '00:00' and out_time == '00:00':
#                         try:
#                             leave = Leave_Application.objects.get(Start_Date__lte=Attendance_Date, End_Date__gte=Attendance_Date, IsDelete=False, Emp_code=EmployeeCode, Status=1)
#                             obj.Status = leave.Leave_Type_Master.Type
#                             obj.save()
#                         except Leave_Application.DoesNotExist:
#                                 try:
#                                     weekoff =  WeekOffDetails.objects.get(Emp_Code=EmployeeCode,WeekoffDate=Attendance_Date,IsDelete=False)
#                                     obj.Status = "WeekOff"
#                                     obj.save()
#                                 except WeekOffDetails.DoesNotExist:
#                                      obj.Status = "Absent"
#                                      obj.save()
                
#                 messages.success(request, f"Uploaded Successfully for {messages_Date}")    
#                 return redirect('/Employee_Payroll/Daily_Attendace/?Q_Date='+str(Attendance_Date))
#             else:
            
#                 try:
#                     Attendance_check = Raw_Attendance_Data_File.objects.get(Attendance_Date = Attendance_Date,OrganizationID = OrganizationID,IsDelete = False)
#                     messages.warning(request, f"Attendance record is present for {messages_Date}")    
#                     return redirect('Upload_Attendace')
#                 except Raw_Attendance_Data_File.DoesNotExist:    
#                     decoded_file = file.read().decode('utf-8').splitlines()
#                     Attendance_create = Raw_Attendance_Data_File.objects.create(File_Name=file.name, Attendance_Date=Attendance_Date, OrganizationID=OrganizationID, CreatedBy=UserID)

#                     match_found = False 
                      
#                     for row in decoded_file:
#                         fields = row.split(',')
#                         if len(fields) == 4:  
#                             RawEmployeeCode, Date, Time, Status = fields
#                             date_obj = datetime.strptime(Date, '%d/%m/%Y').date()
                         
#                             if len(RawEmployeeCode) == 1:
#                                     RawEmployeeCode = '00' + RawEmployeeCode
#                             elif len(RawEmployeeCode) == 2:
#                                     RawEmployeeCode = '0' + RawEmployeeCode

                                
#                             DumpEmployeeCode = str(OID_Code) + RawEmployeeCode

                          
#                             DumpEmployeeCode = DumpEmployeeCode.zfill(9)
                            
#                             if date_obj == attendance_date_obj: 
#                                 raw_attendance = Raw_Attendance_Data.objects.create(
#                                     EmployeeCode = DumpEmployeeCode,
#                                     Date=date_obj, 
#                                     Time=Time,  
#                                     Status=Status,
#                                     OrganizationID=OrganizationID,
#                                     CreatedBy=UserID
#                                 )
#                                 match_found = True  
                               

#                     if not match_found:  
#                         Attendance_create.IsDelete = True
#                         Attendance_create.save() 
#                         messages.warning(request, f"Attendance record of file does not match with selected date {messages_Date}")    
#                         return redirect('Upload_Attendace')



#                     for emp in emp_list:
#                         EmployeeCode = emp['EmployeeCode']
#                         min_in_time = None
#                         max_out_time = None
#                         raw_attendance_records = Raw_Attendance_Data.objects.filter(EmployeeCode=EmployeeCode, Date=attendance_date_obj).values('Date', 'EmployeeCode').annotate(
#                             min_in_time=Min('Time', filter=Q(Status='IN')),
#                             max_out_time=Max('Time', filter=Q(Status='OUT'))
#                         )

                    
                     
#                         if raw_attendance_records.exists():
#                             raw_date = raw_attendance_records[0]['Date']
#                             min_in_time = raw_attendance_records[0]['min_in_time'] 
#                             max_out_time = raw_attendance_records[0]['max_out_time'] 
                        
#                             if min_in_time is not None and max_out_time is not None:
#                                 Duty_IN = datetime.strptime(min_in_time, '%H:%M:%S')
#                                 Duty_OUT = datetime.strptime(max_out_time, '%H:%M:%S')
#                                 Duty_Hour = Duty_OUT - Duty_IN
#                             else:
#                                 Duty_Hour = None

#                             status = "Absent"
#                             if Duty_Hour is not None:
#                                 if Duty_Hour >= timedelta(hours=9):
#                                     status = "Present"
#                                 elif Duty_Hour >= timedelta(hours=5):
#                                     status = "Half Day Present"

                        
                            

#                             in_time = None
#                             out_time = None
#                             in_time = min_in_time
#                             out_time = max_out_time

#                             Attendance_Data.objects.create(
#                                 EmployeeCode=EmployeeCode,
#                                 Date=raw_date,
#                                 In_Time=in_time,
#                                 Out_Time=out_time,
#                                 Duty_Hour=Duty_Hour.total_seconds() // 3600 if Duty_Hour else None,
#                                 OrganizationID=OrganizationID,
#                                 CreatedBy=UserID,
#                                 Status=status,
#                                   IsUpload = True
#                             )


#                         else:


                                    
#                                 try:
#                                     leave = Leave_Application.objects.get(Start_Date__lte=Attendance_Date, End_Date__gte=Attendance_Date, IsDelete=False, Emp_code=EmployeeCode, Status=1)
#                                     status = leave.Leave_Type_Master.Type
#                                     attendance_record = Attendance_Data.objects.create(EmployeeCode=EmployeeCode, Date=Attendance_Date, In_Time = min_in_time,Out_Time=max_out_time,OrganizationID= OrganizationID,Status =status,  IsUpload = True,
#                                     CreatedBy = UserID)
#                                 except Leave_Application.DoesNotExist:

#                                     try:
#                                         weekoff =  WeekOffDetails.objects.get(Emp_Code=EmployeeCode,WeekoffDate=Attendance_Date,IsDelete=False)
#                                         status = "WeekOff"
#                                         attendance_record = Attendance_Data.objects.create(EmployeeCode=EmployeeCode, Date=Attendance_Date, In_Time = min_in_time,Out_Time=max_out_time,OrganizationID= OrganizationID,Status =status,  IsUpload = True,
#                                         CreatedBy = UserID)                                        
#                                     except WeekOffDetails.DoesNotExist:
#                                         status = "Absent"
#                                         attendance_record = Attendance_Data.objects.create(EmployeeCode=EmployeeCode, Date=Attendance_Date, In_Time = min_in_time,Out_Time=max_out_time,OrganizationID= OrganizationID,Status =status,  IsUpload = True,
#                                         CreatedBy = UserID)   
                                    

                                    
                    

#                     messages.success(request, f"Uploaded Successfully for {messages_Date}")    
#                     return redirect('/Employee_Payroll/Daily_Attendace/?Q_Date='+str(Attendance_Date))

#     context = {'org_obj':org_obj}
#     return render(request, "EMP_PAY/Upload_Attendace.html", context)






# @transaction.atomic
# def Upload_Attendace(request):
#     if 'OrganizationID' not in request.session:
#         return redirect(MasterAttribute.Host)
#     else:
#         print("Show Page Session")

#     OrganizationID = request.session["OrganizationID"]
   
#     UserID = str(request.session["UserID"])
#     UserType = request.session["UserType"]
    
     
#     hotelapitoken = MasterAttribute.HotelAPIkeyToken
#     headers = {
#         'hotel-api-token': hotelapitoken  
#     }
#     api_url = "http://hotelops.in/API/PyAPI/HREmployeeList?OrganizationID="+str(OrganizationID)
    

#     try:
#         response = requests.get(api_url, headers=headers)
#         response.raise_for_status() 
#         emp_list = response.json()
     
#     except requests.exceptions.RequestException as e:
#         print(f"Error occurred: {e}")
     
#     OrganizationID = request.session["OrganizationID"]
#     UserID = str(request.session["UserID"])
#     try :
#         org_obj  = Organization_Details.objects.get(OID=OrganizationID,IsDelete=False)
#         OID_Code  = org_obj.OID_Code
#         UploadFormatType = org_obj.UploadFormatType
#         DownloadFormat = org_obj.DownloadFormat.url
        
#     except Organization_Details.DoesNotExist:
        
#         OID_Code = ''
#         UploadFormatType = '.txt'
#         DownloadFormat =  '/Employee_Payroll/DownloadFormat/Defaultformat.txt'
      

    
    
#     with transaction.atomic():
#         if request.method == "POST":
#             file = request.FILES.get('file')
#             Attendance_Date = request.POST['Attendance_Date']            
#             attendance_date_obj = datetime.strptime(Attendance_Date, '%Y-%m-%d').date()
            
#             parsed_date = datetime.strptime(Attendance_Date, '%Y-%m-%d')
#             messages_Date = parsed_date.strftime('%d-%m-%Y')
            
          
#             if UploadFormatType != "." +Path(file.name).suffix.lower()[1:]:
#                     messages.warning(request,f'Upload format type is not macthed to  {UploadFormatType}')
#                     return redirect('Upload_Attendace')
            
              
            
#             try:
#                 Attendance_check = Raw_Attendance_Data_File.objects.get(Attendance_Date = Attendance_Date,OrganizationID = OrganizationID,IsDelete = False)
#                 messages.warning(request, f"Attendance record is present for {messages_Date}")    
#                 return redirect('Upload_Attendace')
#             except Raw_Attendance_Data_File.DoesNotExist:    
#                 decoded_file = file.read().decode('utf-8').splitlines()
#                 Attendance_create = Raw_Attendance_Data_File.objects.create(File_Name=file.name, Attendance_Date=Attendance_Date, OrganizationID=OrganizationID, CreatedBy=UserID)

#                 match_found = False 
                    
#                 for row in decoded_file:
#                     fields = row.split(',')
#                     if len(fields) == 4:  
#                         RawEmployeeCode, Date, Time, Status = fields
#                         date_obj = datetime.strptime(Date, '%d/%m/%Y').date()
#                         DumpEmployeeCode = RawEmployeeCode
#                         if OID_Code !='':
#                                 if len(RawEmployeeCode) == 1:
#                                         RawEmployeeCode = '00' + RawEmployeeCode
#                                 elif len(RawEmployeeCode) == 2:
#                                         RawEmployeeCode = '0' + RawEmployeeCode

                                    
#                                 DumpEmployeeCode = str(OID_Code) + RawEmployeeCode

                                
#                                 DumpEmployeeCode = DumpEmployeeCode.zfill(9)
                        
#                         if date_obj == attendance_date_obj: 
#                             raw_attendance = Raw_Attendance_Data.objects.create(
#                                 EmployeeCode = DumpEmployeeCode,
#                                 Date=date_obj, 
#                                 Time=Time,  
#                                 Status=Status,
#                                 OrganizationID=OrganizationID,
#                                 CreatedBy=UserID
#                             )
#                             match_found = True  
                            

#                 if not match_found:  
#                     Attendance_create.IsDelete = True
#                     Attendance_create.save() 
#                     messages.warning(request, f"Attendance record of file does not match with selected date {messages_Date}")    
#                     return redirect('Upload_Attendace')

   
#                 for emp in emp_list:
#                     Level = emp['Level']
#                     Level_List = ["M","M1","M2","M3","M4","M5","M6"]
                   
#                     EmployeeCode = emp['EmployeeCode']
                    
                   
                    
#                     latest_out_time_query = f"""
#                         SELECT MAX(Time) AS MaxOutTime
#                         FROM Employee_Payroll_raw_attendance_data
#                         WHERE EmployeeCode = '{EmployeeCode}'
#                             AND OrganizationID = {OrganizationID}
#                             AND IsDelete = 0
#                             AND Status = 'OUT'
#                             AND Date >= '{attendance_date_obj}'
#                             AND Date < '{attendance_date_obj + timedelta(days=1)}';
#                     """
#                     earliest_in_time_query = f"""
#                         SELECT MIN(Time) AS MinInTime
#                         FROM Employee_Payroll_raw_attendance_data
#                         WHERE EmployeeCode = '{EmployeeCode}'
#                             AND Date = '{attendance_date_obj}'
#                             AND OrganizationID = {OrganizationID}
#                             AND IsDelete = 0
#                             AND Status = 'IN';
#                     """
#                     with connection.cursor() as cursor:
#                         cursor.execute(latest_out_time_query)
#                         latest_out_time_result = cursor.fetchone()

#                         cursor.execute(earliest_in_time_query)
#                         earliest_in_time_result = cursor.fetchone()

#                     latest_out_time = latest_out_time_result[0] if latest_out_time_result else None
#                     earliest_in_time = earliest_in_time_result[0] if earliest_in_time_result else None
#                     if (latest_out_time and earliest_in_time) or (Level in Level_List and (latest_out_time or earliest_in_time)):
#                         attendance_records = {
#                             'EmployeeCode': EmployeeCode,
#                             'Date': attendance_date_obj,
#                             'MinInTime': earliest_in_time,
#                             'MaxOutTime': latest_out_time
#                         }
#                         in_time_str = attendance_records['MinInTime']
#                         out_time_str = attendance_records['MaxOutTime']
                   
                        
#                         if Level in Level_List:
                               
#                                 if in_time_str and out_time_str:
#                                     in_time = datetime.strptime(in_time_str, '%H:%M:%S')
#                                     out_time = datetime.strptime(out_time_str, '%H:%M:%S')
#                                     duty_hours = out_time - in_time
#                                     duty_hours_time = str(duty_hours).split()[-1]
#                                     attendance_records['DutyHours'] = duty_hours_time

#                                     duty_hours_timedelta = datetime.strptime(duty_hours_time, '%H:%M:%S') - datetime(1900, 1, 1)
#                                 else:
#                                     attendance_records['DutyHours'] = None
#                                     duty_hours_timedelta = timedelta(hours=0)
                              
#                                 status = "Absent"
#                                 if in_time_str or out_time_str:
#                                         status = "Present"
#                                 attendance_records['status'] = status

#                         else:   
                               
                                     
#                                 if in_time_str and out_time_str:
#                                     in_time = datetime.strptime(in_time_str, '%H:%M:%S')
#                                     out_time = datetime.strptime(out_time_str, '%H:%M:%S')
#                                     duty_hours = out_time - in_time
#                                     duty_hours_time = str(duty_hours).split()[-1]
#                                     attendance_records['DutyHours'] = duty_hours_time

#                                     duty_hours_timedelta = datetime.strptime(duty_hours_time, '%H:%M:%S') - datetime(1900, 1, 1)
#                                 else:
#                                     attendance_records['DutyHours'] = None
#                                     duty_hours_timedelta = timedelta(hours=0)

#                                 status = "Absent"
#                                 if duty_hours_timedelta is not None:
#                                     if duty_hours_timedelta >= timedelta(hours=9):
#                                         status = "Present"
#                                     elif duty_hours_timedelta >= timedelta(hours=5):
#                                         status = "Half Day Present"
#                                 attendance_records['status'] = status
                        
#                         if attendance_records:
#                             Attendance_Data.objects.create(
#                                 EmployeeCode=EmployeeCode,
#                                 Date=Attendance_Date,
#                                 In_Time=attendance_records['MinInTime'],
#                                 Out_Time=attendance_records['MaxOutTime'],
#                                 Duty_Hour=attendance_records['DutyHours'],
#                                 OrganizationID=OrganizationID,
#                                 CreatedBy=UserID,
#                                 Status=attendance_records['status'],
#                                 IsUpload=True
#                             )
                        
#                     else:
                       
#                         MinInTime = None
#                         MaxOutTime = None
#                         Duty_Hour = None
#                         try:
                            
                           
                            
#                             query = """
#                             SELECT * 
#                             FROM Leave_Management_System_leave_application 
#                             WHERE Start_Date <= %s
#                             AND End_Date >= %s
#                             AND IsDelete = 0
#                             AND Emp_code = %s
#                             AND OrganizationID = %s
#                             AND Status = 1;
#                             """ 
#                             with connection.cursor() as cursor:
#                                 cursor.execute(query, [Attendance_Date,Attendance_Date,EmployeeCode, OrganizationID])
#                                 rows = cursor.fetchall()
#                                 columns = [col[0] for col in cursor.description]
#                             rowslist = [dict(zip(columns, row)) for row in rows] 
                            
#                             if rowslist:
#                                 leave_id = rowslist[0].get('Leave_Type_Master_id') 
#                                 if leave_id is not None:
#                                     leave = get_object_or_404(Leave_Type_Master, id=leave_id, OrganizationID=OrganizationID, IsDelete=False)
#                                     status = leave.Type

#                                 attendance_record = Attendance_Data.objects.create(EmployeeCode=EmployeeCode, Date=Attendance_Date, In_Time=MinInTime, Out_Time=MaxOutTime, OrganizationID=OrganizationID, Status=status, IsUpload=True, CreatedBy=UserID, Duty_Hour=Duty_Hour)
                       
#                         except Leave_Application.DoesNotExist:
#                                 status = "Absent"
#                                 attendance_record = Attendance_Data.objects.create(EmployeeCode=EmployeeCode, Date=Attendance_Date, In_Time=MinInTime, Out_Time=MaxOutTime, OrganizationID=OrganizationID, Status=status, IsUpload=True, Duty_Hour=Duty_Hour, CreatedBy=UserID)
 
                                

                                
                

#                 messages.success(request, f"Uploaded Successfully for {messages_Date}")    
#                 return redirect('/Employee_Payroll/Daily_Attendace/?Q_Date='+str(Attendance_Date))

#     context = {'UploadFormatType':UploadFormatType,'DownloadFormat' : DownloadFormat}
#     return render(request, "EMP_PAY/Attendance/Upload_Attendace.html", context)

# from azure.storage.blob import BlobServiceClient, ContentSettings
# import json

# def create_blob_client(blob_name):
#     connection_string = 'AccountName=devstoreaccount1;AccountKey=Eby8vdM02xNOcqFlqUwJPLlmEtlCDXJ1OUzFT50uSRZ6IFsuFq2UVErCz4I6tq/K1SZFPTOtr/KBHBeksoGMGw==;DefaultEndpointsProtocol=http;BlobEndpoint=http://127.0.0.1:10000/devstoreaccount1;QueueEndpoint=http://127.0.0.1:10001/devstoreaccount1;TableEndpoint=http://127.0.0.1:10002/devstoreaccount1;'
#     container_name = "attendancedata"
#     blob_service_client = BlobServiceClient.from_connection_string(connection_string)
#     container_client = blob_service_client.get_container_client(container_name)
#     return container_client.get_blob_client(blob_name)

# def download_blob(blob_name):
#     blob_client = create_blob_client(blob_name)
#     try:
#         blob_content = blob_client.download_blob().readall()
#         return blob_content
#     except Exception as e:
#         print(f"Error downloading blob: {e}")
#         return None

# from Leave_Management_System.views import EmployeeDataSelect

# def ReadAttendanceFromAzure(request):
#     if 'OrganizationID' not in request.session:
#         return redirect(settings.MasterAttribute.Host)
#     else:
#         print("Show Page Session")
    
#     Attendance_Date = request.GET.get('Attendance_Date')
#     if not Attendance_Date:
#         return JsonResponse({'error': 'Attendance_Date parameter is missing.'}, safe=False)
    
#     OrganizationID = request.session["OrganizationID"]
#     FileName = Raw_Attendance_Data_File.objects.filter(OrganizationID = OrganizationID ,IsDelete=False,Attendance_Date = Attendance_Date).order_by('-CreatedDateTime').first().File_Name
#     blob_name = FileName
#     print(blob_name)
    
#     try:
#         blob_content = download_blob(blob_name)
#     except Exception as e:
#         return JsonResponse({'error': f'Error occurred while downloading blob: {str(e)}'}, safe=False)

#     if not blob_content:
#         return JsonResponse({'error': 'Blob content is None or error occurred while downloading blob.'}, safe=False)
    
#     try:
#         FullData  = json.loads(blob_content)
#     except json.JSONDecodeError as e:
#         return JsonResponse({'error': f'JSON decode error: {str(e)}'}, safe=False)
#     employeedata =  EmployeeDataSelect(OrganizationID)
#     print(employeedata)
#     print(FullData)
#     if 'data' in FullData:
#         data = FullData['data']
#         if data is not None:
#             for d in data:
#                 print(d)
    
#     return JsonResponse({'success': 'Blob content is downloaded and processed.'}, safe=False)


    




@transaction.atomic
def Upload_Attendace(request):
    if 'OrganizationID' not in request.session:
        return redirect(MasterAttribute.Host)
    else:
        print("Show Page Session")

    OrganizationID = request.session["OrganizationID"]
   
    UserID = str(request.session["UserID"])
    UserType = request.session["UserType"]
    
    # emp_list =  EmployeeMaster.objects.filter(OrganizationID=OrganizationID,IsDelete=False)
    emp_list =  EmployeeDataSelect(OrganizationID)
    
     
    try :
        org_obj  = Organization_Details.objects.get(OID=OrganizationID,IsDelete=False)
        OID_Code  = org_obj.OID_Code
        UploadFormatType = org_obj.UploadFormatType
        DownloadFormat = org_obj.DownloadFormat.url
        
    except Organization_Details.DoesNotExist:
        
        OID_Code = ''
        UploadFormatType = '.txt'
        DownloadFormat =  '/Employee_Payroll/DownloadFormat/Defaultformat.txt'
      

    
    
    with transaction.atomic():
        if request.method == "POST":
            file = request.FILES.get('file')
            Attendance_Date = request.POST['Attendance_Date']            
            attendance_date_obj = datetime.strptime(Attendance_Date, '%Y-%m-%d').date()
            
            parsed_date = datetime.strptime(Attendance_Date, '%Y-%m-%d')
            messages_Date = parsed_date.strftime('%d-%m-%Y')
            
          
            if UploadFormatType != "." +Path(file.name).suffix.lower()[1:]:
                    messages.warning(request,f'Upload format type is not macthed to  {UploadFormatType}')
                    return redirect('Upload_Attendace')
            
              
            
            try:
                Attendance_check = Raw_Attendance_Data_File.objects.get(Attendance_Date = Attendance_Date,OrganizationID = OrganizationID,IsDelete = False)
                messages.warning(request, f"Attendance record is present for {messages_Date}")    
                return redirect('Upload_Attendace')
            except Raw_Attendance_Data_File.DoesNotExist:    
                decoded_file = file.read().decode('utf-8').splitlines()
                Attendance_create = Raw_Attendance_Data_File.objects.create(File_Name=file.name, Attendance_Date=Attendance_Date, OrganizationID=OrganizationID, CreatedBy=UserID)

                match_found = False 
                    
                for row in decoded_file:
                    fields = row.split(',')
                    if len(fields) == 4:  
                        RawEmployeeCode, Date, Time, Status = fields
                        date_obj = datetime.strptime(Date, '%d/%m/%Y').date()
                        DumpEmployeeCode = RawEmployeeCode
                        if OID_Code !='':
                                if len(RawEmployeeCode) == 1:
                                        RawEmployeeCode = '00' + RawEmployeeCode
                                elif len(RawEmployeeCode) == 2:
                                        RawEmployeeCode = '0' + RawEmployeeCode

                                    
                                DumpEmployeeCode = str(OID_Code) + RawEmployeeCode

                                
                                DumpEmployeeCode = DumpEmployeeCode.zfill(9)
                        
                        if date_obj == attendance_date_obj: 
                            raw_attendance = Raw_Attendance_Data.objects.create(
                                EmployeeCode = DumpEmployeeCode,
                                Date=date_obj, 
                                Time=Time,  
                                Status=Status,
                                OrganizationID=OrganizationID,
                                CreatedBy=UserID
                            )
                            match_found = True  
                            

                if not match_found:  
                    Attendance_create.IsDelete = True
                    Attendance_create.save() 
                    messages.warning(request, f"Attendance record of file does not match with selected date {messages_Date}")    
                    return redirect('Upload_Attendace')

   
                for emp in emp_list:
                    Level = emp.Level
                    Level_List = ["M","M1","M2","M3","M4","M5","M6"]
                   
                    EmployeeCode = emp['EmployeeCode']
                    
                   
                    
                    latest_out_time_query = f"""
                        SELECT MAX(Time) AS MaxOutTime
                        FROM Employee_Payroll_raw_attendance_data
                        WHERE EmployeeCode = '{EmployeeCode}'
                            AND OrganizationID = {OrganizationID}
                            AND IsDelete = 0
                            AND Status = 'OUT'
                            AND Date >= '{attendance_date_obj}'
                            AND Date < '{attendance_date_obj + timedelta(days=1)}';
                    """
                    earliest_in_time_query = f"""
                        SELECT MIN(Time) AS MinInTime
                        FROM Employee_Payroll_raw_attendance_data
                        WHERE EmployeeCode = '{EmployeeCode}'
                            AND Date = '{attendance_date_obj}'
                            AND OrganizationID = {OrganizationID}
                            AND IsDelete = 0
                            AND Status = 'IN';
                    """
                    with connection.cursor() as cursor:
                        cursor.execute(latest_out_time_query)
                        latest_out_time_result = cursor.fetchone()

                        cursor.execute(earliest_in_time_query)
                        earliest_in_time_result = cursor.fetchone()

                    latest_out_time = latest_out_time_result[0] if latest_out_time_result else None
                    earliest_in_time = earliest_in_time_result[0] if earliest_in_time_result else None
                    if (latest_out_time and earliest_in_time) or (Level in Level_List and (latest_out_time or earliest_in_time)):
                        attendance_records = {
                            'EmployeeCode': EmployeeCode,
                            'Date': attendance_date_obj,
                            'MinInTime': earliest_in_time,
                            'MaxOutTime': latest_out_time
                        }
                        in_time_str = attendance_records['MinInTime']
                        out_time_str = attendance_records['MaxOutTime']
                   
                        
                        if Level in Level_List:
                               
                                if in_time_str and out_time_str:
                                    in_time = datetime.strptime(in_time_str, '%H:%M:%S')
                                    out_time = datetime.strptime(out_time_str, '%H:%M:%S')
                                    duty_hours = out_time - in_time
                                    duty_hours_time = str(duty_hours).split()[-1]
                                    attendance_records['DutyHours'] = duty_hours_time

                                    duty_hours_timedelta = datetime.strptime(duty_hours_time, '%H:%M:%S') - datetime(1900, 1, 1)
                                else:
                                    attendance_records['DutyHours'] = None
                                    duty_hours_timedelta = timedelta(hours=0)
                              
                                status = "Absent"
                                if in_time_str or out_time_str:
                                        status = "Present"
                                attendance_records['status'] = status

                        else:   
                               
                                     
                                if in_time_str and out_time_str:
                                    in_time = datetime.strptime(in_time_str, '%H:%M:%S')
                                    out_time = datetime.strptime(out_time_str, '%H:%M:%S')
                                    duty_hours = out_time - in_time
                                    duty_hours_time = str(duty_hours).split()[-1]
                                    attendance_records['DutyHours'] = duty_hours_time

                                    duty_hours_timedelta = datetime.strptime(duty_hours_time, '%H:%M:%S') - datetime(1900, 1, 1)
                                else:
                                    attendance_records['DutyHours'] = None
                                    duty_hours_timedelta = timedelta(hours=0)

                                status = "Absent"
                                if duty_hours_timedelta is not None:
                                    if duty_hours_timedelta >= timedelta(hours=8, minutes=30):
                                        status = "Present"
                                    elif duty_hours_timedelta >= timedelta(hours=5):
                                        status = "Half Day Present"
                                attendance_records['status'] = status
                        
                        if attendance_records:
                            Attendance_Data.objects.create(
                                EmployeeCode=EmployeeCode,
                                Date=Attendance_Date,
                                In_Time=attendance_records['MinInTime'],
                                Out_Time=attendance_records['MaxOutTime'],
                                Duty_Hour=attendance_records['DutyHours'],
                                OrganizationID=OrganizationID,
                                CreatedBy=UserID,
                                Status=attendance_records['status'],
                                IsUpload=True
                            )
                        
                    else:
                       
                        MinInTime = None
                        MaxOutTime = None
                        Duty_Hour = None
                        try:
                            
                           
                            
                            query = """
                            SELECT * 
                            FROM Leave_Management_System_leave_application 
                            WHERE Start_Date <= %s
                            AND End_Date >= %s
                            AND IsDelete = 0
                            AND Emp_code = %s
                            AND OrganizationID = %s
                            AND Status = 1;
                            """ 
                            with connection.cursor() as cursor:
                                cursor.execute(query, [Attendance_Date,Attendance_Date,EmployeeCode, OrganizationID])
                                rows = cursor.fetchall()
                                columns = [col[0] for col in cursor.description]
                            rowslist = [dict(zip(columns, row)) for row in rows] 
                            
                            if rowslist:
                                leave_id = rowslist[0].get('Leave_Type_Master_id') 
                                if leave_id is not None:
                                    leave = get_object_or_404(Leave_Type_Master, id=leave_id, IsDelete=False,Is_Active=True)
                                    status = leave.Type

                                attendance_record = Attendance_Data.objects.create(EmployeeCode=EmployeeCode, Date=Attendance_Date, In_Time=MinInTime, Out_Time=MaxOutTime, OrganizationID=OrganizationID, Status=status, IsUpload=True, CreatedBy=UserID, Duty_Hour=Duty_Hour)
                       
                        except Leave_Application.DoesNotExist:
                                status = "Absent"
                                attendance_record = Attendance_Data.objects.create(EmployeeCode=EmployeeCode, Date=Attendance_Date, In_Time=MinInTime, Out_Time=MaxOutTime, OrganizationID=OrganizationID, Status=status, IsUpload=True, Duty_Hour=Duty_Hour, CreatedBy=UserID)
 
                                

                                
                

                messages.success(request, f"Uploaded Successfully for {messages_Date}")    
                return redirect('/Employee_Payroll/Daily_Attendace/?Q_Date='+str(Attendance_Date))

    context = {'UploadFormatType':UploadFormatType,'DownloadFormat' : DownloadFormat}
    return render(request, "EMP_PAY/Attendance/Upload_Attendace.html", context)


# import pyodbc
# from django.http import JsonResponse
# from django.db import connection

# def GetAttendance(request):
#     try:
#         with connection.cursor() as cursor:
#             cursor.execute("exec SP_EmployeePayRoll_Attendance_InTimeOutTimeDutyHours_Data_Select '451000004',1001,'2024-05-16'")
#             result = cursor.fetchall()  
#             if result:
#                 print(result)  
#         return JsonResponse({'message': 'Stored procedure executed successfully'}, status=200)
#     except pyodbc.Error as err:
#         return JsonResponse({'error': str(err)}, status=500)

# from django.db.models import Min, Max, ExpressionWrapper, F, DateTimeField
# from datetime import timedelta
# from django.utils import timezone
# def GetAttendance(self,  employee_code = '451000004',organization_id=1001,date='2024-05-16'):
#         # Subquery to get min time for InTime
#         subquery_in_time = Raw_Attendance_Data.objects.filter(
#             EmployeeCode=employee_code,
#             Date=date,
#             IsDelete=False,
#             OrganizationID=organization_id,
#             Time__gt='02:00',
#             Status='IN'
#         ).aggregate(in_time=Min('Time'))

#         # Subquery to get max time for OutTime
#         subquery_out_time = Raw_Attendance_Data.objects.filter(
#             EmployeeCode=employee_code,
#             Date=date,
#             IsDelete=False,
#             Status='Out'
#         ).annotate(
#             next_day_date=ExpressionWrapper(F('Date') + timedelta(days=1), output_field=DateTimeField())
#         ).filter(
#             next_day_date=F('Date')
#         ).aggregate(out_time=Min('Time'))

#         # Fetching InTime, OutTime and calculating DutyHours
#         in_time = subquery_in_time['in_time']
#         out_time = subquery_out_time['out_time']

#         # Handling case where no OutTime is found for the given day
#         if out_time is None:
#             # Assuming the next day's first entry as OutTime
            
#             next_day = date + timedelta(days=1)
#             next_day_out_time = Raw_Attendance_Data.objects.filter(
#                 EmployeeCode=employee_code,
#                 Date=next_day,
#                 IsDelete=False,
#                 Status='Out'
#             ).aggregate(next_day_out_time=Min('Time'))
#             if next_day_out_time['next_day_out_time'] is not None:
#                 out_time = next_day_out_time['next_day_out_time']

#         # Calculating DutyHours
#         if in_time and out_time:
#             in_time = timezone.make_aware(in_time)
#             out_time = timezone.make_aware(out_time)
#             duty_hours = out_time - in_time
#             duty_hours = duty_hours.total_seconds() / 3600  # Convert to hours
#         else:
#             duty_hours = None

#         # Constructing the result set
#         result_set = [{
#             'EmployeeCode': employee_code,
#             'Date': date,
#             'InTime': in_time.strftime('%H:%M') if in_time else None,
#             'OutTime': out_time.strftime('%H:%M') if out_time else None,
#             'DutyHours': duty_hours
#         }]
       
#         return JsonResponse(result_set,safe=False)




# from django.core.files.storage import FileSystemStorage
# def AttendaceCorrectEtmExlUp(request):
#     if 'OrganizationID' not in request.session:
#         return redirect(MasterAttribute.Host)
#     else:
#         print("Show Page Session")
     
#     OrganizationID = request.session["OrganizationID"]
#     UserID = str(request.session["UserID"])
#     EmployeeCode = request.session["EmployeeCode"]
#     if request.method == "POST":
#         print("hello POST")
#         file = request.FILES['doc']
#         fs = FileSystemStorage()
#         filename = fs.save(file.name, file)
#         file_path = fs.path(filename)
#         df = pd.read_excel(file_path)  # Skipping first rows to get to the data
 
#         # Identify the relevant columns in the Excel sheet
#         columns = df.columns
 
#         from_date_str =df.iloc[2, 0]
#         print("FromDate",from_date_str)
#         to_date_str = df.iloc[3, 0]
#         print("ToDate",to_date_str)
#         from_date_cleaned = from_date_str.replace("From :", "").strip()
#         to_date_cleaned = to_date_str.replace("To :", "").strip()
 
#         # Convert the cleaned date strings to datetime objects
#         from_date = datetime.strptime(from_date_cleaned, '%d %b %Y')
#         to_date = datetime.strptime(to_date_cleaned, '%d %b %Y')
 
#         print("FromDate:", from_date)
#         print("ToDate:", to_date)
#         # Iterate over the dates in the Excel file
#         for index, row in df.iterrows():
#             if index>6:
#                     print(index)
                       
       
#         print("Attendance data uploaded successfully.")
 
#     return redirect("AttendaceMonthlyReport")

# from django.core.files.storage import FileSystemStorage
# import pandas as pd
# from datetime import datetime
 
# def AttendaceCorrectEtmExlUp(request):
#     if 'OrganizationID' not in request.session:
#         return redirect(MasterAttribute.Host)
#     else:
#         print("Show Page Session")
 
#     if request.method == "POST":
#         file = request.FILES['doc']
#         fs = FileSystemStorage()
#         filename = fs.save(file.name, file)
#         file_path = fs.path(filename)
 
      
#         df = pd.read_excel(file_path)
 
       
#         from_date_str = df.iloc[2, 0]
#         to_date_str = df.iloc[3, 0]
#         from_date_cleaned = from_date_str.replace("From :", "").strip()
#         to_date_cleaned = to_date_str.replace("To :", "").strip()
#         from_date = datetime.strptime(from_date_cleaned, '%d %b %Y')
#         to_date = datetime.strptime(to_date_cleaned, '%d %b %Y')
       
#         attendance_data = []
 
       
#         for index, row in df.iterrows():
#             if index > 6:
#                 cid = row[1]  
#                 name = row[1]  
#                 department = row[2]  
#                 designation = row[3]  
 
#                 for day in range(26, 32):  
#                     date = f"2024-06-{day}" 
#                     in_time = row[day + 4]  
#                     out_time = row[day + 5] 
#                     duty_hours = row[day + 6] 
#                     status = row[day + 7]  
 
#                     attendance_data.append({
#                         'EmployeeCode': cid,
#                         'Date': date,
#                         'IN': in_time,
#                         'OUT': out_time,
#                         'Duty Hours': duty_hours,
#                         'STATUS': status
#                     })
 
#         for entry in attendance_data:
#             print(entry)
 
#         print("Attendance data uploaded successfully.")
#     return redirect("AttendaceMonthlyReport")
import pandas as pd
from io import BytesIO
from django.http import HttpResponse,Http404
from django.core.files.storage import FileSystemStorage
from datetime import datetime

# def AttendaceCorrectEtmExlUp(request):
#     if 'OrganizationID' not in request.session:
#         return redirect(MasterAttribute.Host)
    
#     OrganizationID = request.session["OrganizationID"]
#     UserID = str(request.session["UserID"])
#     EmployeeCode = request.session["EmployeeCode"]

#     if request.method == "POST":
#         print("hello POST")
#         file = request.FILES['doc']
#         fs = FileSystemStorage()
#         filename = fs.save(file.name, file)
#         file_path = fs.path(filename)
        
#         # Read the Excel file
#         df = pd.read_excel(file_path)

#         # Debugging: Print out the values in the relevant rows
#         from_date_str =df.iloc[2, 0]
#         print("FromDate",from_date_str)
#         to_date_str = df.iloc[3, 0]
#         print("ToDate",to_date_str)

#         print(f"Raw From Date Value: {from_date_str}")
#         print(f"Raw To Date Value: {to_date_str}")

#         # Check if the date strings are valid (not float or NaN)
#         if isinstance(from_date_str, str):
#             from_date_cleaned = from_date_str.replace("From :", "").strip()
#         else:
#             from_date_cleaned = None

#         if isinstance(to_date_str, str):
#             to_date_cleaned = to_date_str.replace("To :", "").strip()
#         else:
#             to_date_cleaned = None

#         # Only process if the date values are valid
#         if from_date_cleaned and to_date_cleaned:
#             try:
#                 from_date = datetime.strptime(from_date_cleaned, '%d %b %Y')
#                 to_date = datetime.strptime(to_date_cleaned, '%d %b %Y')
#                 print("FromDate:", from_date)
#                 print("ToDate:", to_date)
#             except ValueError as e:
#                 return HttpResponse(f"Date format error: {str(e)}", status=400)
#         else:
#             return HttpResponse("Invalid From/To Date in the Excel file", status=400)

#         # List to store the processed attendance data
#         attendance_data = []

#         # Extract attendance details starting from the 7th row
#         for index, row in df.iterrows():
#             if index >= 7:  # Start reading from row 7 (index 6 in zero-based index)
#                 employee_code = row[1]  # 'ID' is in column B (index 1)
#                 employee_name = row[2]  # 'NAME' is in column C (index 2)
#                 department = row[3]     # 'DEPARTMENT' is in column D (index 3)
#                 designation = row[4]    # 'DESIGNATION' is in column E (index 4)
#                 date = row[5]           # 'DATE' is in column F (index 5)
#                 in_time = row[6]        # 'IN' time is in column G (index 6)
#                 out_time = row[7]       # 'OUT' time is in column H (index 7)
#                 total_hours = row[8]    # 'TOTAL' duty hours in column I (index 8)
#                 status = row[9]         # 'STATUS' in column J (index 9)

#                 # Create a dictionary for the attendance record
#                 attendance_record = {
#                     'EmployeeCode': employee_code,
#                     'Date': date,
#                     'IN': in_time,
#                     'OUT': out_time,
#                     'Duty Hours': total_hours,
#                     'STATUS': status
#                 }

#                 # Add the record to the attendance data list
#                 attendance_data.append(attendance_record)

#         # Create a DataFrame for the attendance data
#         attendance_df = pd.DataFrame(attendance_data)

#         # Use BytesIO to create an in-memory buffer for the Excel file
#         output = BytesIO()
#         writer = pd.ExcelWriter(output, engine='xlsxwriter')

#         # Write the DataFrame to Excel
#         attendance_df.to_excel(writer, index=False, sheet_name='Attendance')

#         # Save the Excel file
#         writer.close()

#         # Set the buffer's position to the beginning
#         output.seek(0)

#         # Return the Excel file as a response
#         response = HttpResponse(output, content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
#         response['Content-Disposition'] = f'attachment; filename=attendance_data_{from_date_cleaned}_to_{to_date_cleaned}.xlsx'

#         return response

#     return redirect("AttendaceMonthlyReport")


import pandas as pd
from io import BytesIO
from django.http import HttpResponse
from django.core.files.storage import FileSystemStorage
from datetime import datetime
from django.shortcuts import redirect

# def AttendaceCorrectEtmExlUp(request):
#     if 'OrganizationID' not in request.session:
#         return redirect(MasterAttribute.Host)
    
#     OrganizationID = request.session["OrganizationID"]
#     UserID = str(request.session["UserID"])
#     EmployeeCode = request.session["EmployeeCode"]

#     if request.method == "POST":
#         print("hello POST")
#         file = request.FILES['doc']
#         fs = FileSystemStorage()
#         filename = fs.save(file.name, file)
#         file_path = fs.path(filename)

#         # Read the Excel file
#         df = pd.read_excel(file_path)

#         # Identify the range of dates from the top rows
#         from_date_str = df.iloc[2, 0]
#         print("FromDate", from_date_str)
#         to_date_str = df.iloc[3, 0]
#         print("ToDate", to_date_str)

#         # Clean and process date strings
#         if isinstance(from_date_str, str):
#             from_date_cleaned = from_date_str.replace("From :", "").strip()
#         else:
#             from_date_cleaned = None

#         if isinstance(to_date_str, str):
#             to_date_cleaned = to_date_str.replace("To :", "").strip()
#         else:
#             to_date_cleaned = None

#         # Only process if the date values are valid
#         if from_date_cleaned and to_date_cleaned:
#             try:
#                 from_date = datetime.strptime(from_date_cleaned, '%d %b %Y')
#                 to_date = datetime.strptime(to_date_cleaned, '%d %b %Y')
#             except ValueError as e:
#                 return HttpResponse(f"Date format error: {str(e)}", status=400)
#         else:
#             return HttpResponse("Invalid From/To Date in the Excel file", status=400)

#         # List to store processed attendance data
#         attendance_data = []

#         # Initialize column indexes for the employee details
#         employee_code_col = 1
       

#         # Start iterating from the row that has the 'IN', 'OUT', 'TOTAL', 'STATUS' rows
#         row_index = 8  # Starting from row 8 (zero-indexed 7)

#         while row_index < len(df):
#             # Read employee details (same for all attendance rows)
#             try:
#                 employee_code = df.iloc[row_index, employee_code_col]
               
#             except IndexError:
#                 print(f"IndexError at row {row_index}: check if data is available")
#                 break  # Exit loop if there's an issue with row indexing

#             # Extract attendance data
#             try:
#                 days = df.iloc[row_index, 6:].tolist()  # here date will come in loop like 26-06-2024 to 25-07-2024
#                 in_times = df.iloc[row_index + 1, 5:].tolist()  # IN row is present on  9 th row G9 col 
#                 out_times = df.iloc[row_index + 2, 5:].tolist()  # OUT row is present on  10 th row G10 col 
#                 total_hours = df.iloc[row_index + 3, 5:].tolist()  # TOTAL row is present on  11 th row G11 col 
#                 statuses = df.iloc[row_index + 4, 5:].tolist()  # STATUS row is present on  12 th row G12 col 
#                 # now to tract till 25-07-2024 you have to coun day diff btw in  26-06-2024 to 25-07-2024 then increase by 1 
#                 # for example for 26-06-2024 IN row will ce  present on  9 th row H9 col
#                 # After proecessing for one Employee Code Go on next for that add  5 for IN row G9  its becomes G14 5 for IN row H9  its becomes H14  same for all
#             except IndexError:
#                 print(f"Data for employee at row {row_index} is incomplete.")
#                 break  # Exit loop if there's an issue with row indexing

#             # Process each day's attendance for this employee
#             for i, day in enumerate(days):
#                 if not pd.isnull(day):  # Only process if day is not NaN
#                     attendance_record = {
#                         'EmployeeCode': employee_code,
                      
#                         'Date': day,  # The day column contains the date
#                         'IN': in_times[i] if i < len(in_times) else None,
#                         'OUT': out_times[i] if i < len(out_times) else None,
#                         'Duty Hours': total_hours[i] if i < len(total_hours) else None,
#                         'STATUS': statuses[i] if i < len(statuses) else None
#                     }
#                     # Append to the attendance data list
#                     attendance_data.append(attendance_record)

#             # Move to the next set of rows for the next employee
#             row_index += 5  # Increment by 5 for the next employee

#         # Create a DataFrame for the attendance data
#         attendance_df = pd.DataFrame(attendance_data)

#         # Use BytesIO to create an in-memory buffer for the Excel file
#         output = BytesIO()
#         writer = pd.ExcelWriter(output, engine='xlsxwriter')

#         # Write the DataFrame to Excel
#         attendance_df.to_excel(writer, index=False, sheet_name='Attendance')

#         # Close the writer to finalize the Excel file in the buffer
#         writer.close()

#         # Set the buffer's position to the beginning
#         output.seek(0)

#         # Return the Excel file as a response
#         response = HttpResponse(output, content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
#         response['Content-Disposition'] = f'attachment; filename=attendance_data_{from_date_cleaned}_to_{to_date_cleaned}.xlsx'

#         return response

#     return redirect("AttendaceMonthlyReport")

import pandas as pd
from io import BytesIO
from django.http import HttpResponse
from django.core.files.storage import FileSystemStorage
from datetime import datetime
from django.shortcuts import redirect

# def AttendaceCorrectEtmExlUp(request):
#     if 'OrganizationID' not in request.session:
#         return redirect(MasterAttribute.Host)
    
#     OrganizationID = request.session["OrganizationID"]
#     UserID = str(request.session["UserID"])
#     EmployeeCode = request.session["EmployeeCode"]

#     if request.method == "POST":
#         print("hello POST")
#         file = request.FILES['doc']
#         fs = FileSystemStorage()
#         filename = fs.save(file.name, file)
#         file_path = fs.path(filename)

#         # Read the Excel file
#         df = pd.read_excel(file_path)

#         # Identify the range of dates from the top rows
#         from_date_str = df.iloc[2, 0]
#         print("FromDate", from_date_str)
#         to_date_str = df.iloc[3, 0]
#         print("ToDate", to_date_str)

#         # Clean and process date strings
#         if isinstance(from_date_str, str):
#             from_date_cleaned = from_date_str.replace("From :", "").strip()
#         else:
#             from_date_cleaned = None

#         if isinstance(to_date_str, str):
#             to_date_cleaned = to_date_str.replace("To :", "").strip()
#         else:
#             to_date_cleaned = None

#         # Only process if the date values are valid
#         if from_date_cleaned and to_date_cleaned:
#             try:
#                 from_date = datetime.strptime(from_date_cleaned, '%d %b %Y')
#                 to_date = datetime.strptime(to_date_cleaned, '%d %b %Y')
#             except ValueError as e:
#                 return HttpResponse(f"Date format error: {str(e)}", status=400)
#         else:
#             return HttpResponse("Invalid From/To Date in the Excel file", status=400)

#         # List to store processed attendance data
#         attendance_data = []

#         # Initialize column indexes for the employee details
#         employee_code_col = 1

#         # Start iterating from the row that has the 'IN', 'OUT', 'TOTAL', 'STATUS' rows
#         row_index = 8  # Starting from row 8 (zero-indexed)

#         while row_index < len(df):
#             try:
#                 employee_code = df.iloc[row_index, employee_code_col]

#                 # Extract attendance data
#                 days = df.iloc[row_index, 6:].tolist()  # Assuming dates start from column index 6
#                 in_times = df.iloc[row_index + 1, 6:].tolist()  # IN row
#                 out_times = df.iloc[row_index + 2, 6:].tolist()  # OUT row
#                 total_hours = df.iloc[row_index + 3, 6:].tolist()  # TOTAL row
#                 statuses = df.iloc[row_index + 4, 6:].tolist()  # STATUS row

#             except IndexError:
#                 print(f"Data for employee at row {row_index} is incomplete or out of range.")
#                 break  # Exit loop if there's an issue with row indexing

#             # Process each day's attendance for this employee
#             for i, day in enumerate(days):
#                 if not pd.isnull(day):  # Only process if day is not NaN
#                     attendance_record = {
#                         'EmployeeCode': employee_code,
#                         'Date': day,
#                         'IN': in_times[i] if i < len(in_times) else None,
#                         'OUT': out_times[i] if i < len(out_times) else None,
#                         'Duty Hours': total_hours[i] if i < len(total_hours) else None,
#                         'STATUS': statuses[i] if i < len(statuses) else None
#                     }
#                     # Append to the attendance data list
#                     attendance_data.append(attendance_record)

#             # Move to the next set of rows for the next employee
#             row_index += 5  # Increment by 5 for the next employee

#         # Create a DataFrame for the attendance data
#         attendance_df = pd.DataFrame(attendance_data)

#         # Optionally drop rows with all NaN values
#         attendance_df.dropna(how='all', inplace=True)

#         # Use BytesIO to create an in-memory buffer for the Excel file
#         output = BytesIO()
#         writer = pd.ExcelWriter(output, engine='xlsxwriter')

#         # Write the DataFrame to Excel
#         attendance_df.to_excel(writer, index=False, sheet_name='Attendance')

#         # Close the writer to finalize the Excel file in the buffer
#         writer.close()

#         # Set the buffer's position to the beginning
#         output.seek(0)

#         # Return the Excel file as a response
#         response = HttpResponse(output, content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
#         response['Content-Disposition'] = f'attachment; filename=attendance_data_{from_date_cleaned}_to_{to_date_cleaned}.xlsx'

#         return response

#     return redirect("AttendaceMonthlyReport")
# def AttendaceCorrectEtmExlUp(request):
#     if 'OrganizationID' not in request.session:
#         return redirect(MasterAttribute.Host)
    
#     OrganizationID = request.session["OrganizationID"]
#     UserID = str(request.session["UserID"])
#     EmployeeCode = request.session["EmployeeCode"]

#     if request.method == "POST":
#         print("hello POST")
#         file = request.FILES['doc']
#         fs = FileSystemStorage()
#         filename = fs.save(file.name, file)
#         file_path = fs.path(filename)

#         # Read the Excel file
#         df = pd.read_excel(file_path)

#         # List to store processed attendance data
#         attendance_data = []

#         # Initialize column indexes for the employee details
#         employee_code_col = 1  # Assuming employee code is in the second column (0-indexed 1)

#         # Start iterating from the row that contains attendance data
#         row_index = 8  # Starting from row 1 to capture data, adjust based on your header row
#         from_date_str =df.iloc[2, 0]
#         print("FromDate",from_date_str)
#         to_date_str = df.iloc[3, 0]
#         print("ToDate",to_date_str)
#         from_date_cleaned = from_date_str.replace("From :", "").strip()
#         to_date_cleaned = to_date_str.replace("To :", "").strip()

#         # Convert the cleaned date strings to datetime objects
#         from_date = datetime.strptime(from_date_cleaned, '%d %b %Y')
#         to_date = datetime.strptime(to_date_cleaned, '%d %b %Y')
#         date_difference = to_date - from_date

#         # Extract the number of days from the timedelta object
#         days_difference = date_difference.days
#         print("FromDate:", from_date)
#         print("ToDate:", to_date)
#         while row_index < len(df)-9:
#             # Read employee details (same for all attendance rows)
#             try:
#                 employee_code = df.iloc[row_index, employee_code_col]
#             except IndexError:
#                 print(f"IndexError at row {row_index}: check if data is available")
#                 break  # Exit loop if there's an issue with row indexing

#             # Extract attendance data
#             # try:
#             #     days = df.columns[5:].tolist()  # Assuming date columns start from the 6th column
#             #     in_times = df.iloc[row_index + 1, 5:].tolist()  # IN row
#             #     out_times = df.iloc[row_index + 2, 5:].tolist()  # OUT row
#             #     total_hours = df.iloc[row_index + 3, 5:].tolist()  # TOTAL row
#             #     statuses = df.iloc[row_index + 4, 5:].tolist()  # STATUS row
#             # except IndexError:
#             #     print(f"Data for employee at row {row_index} is incomplete.")
#             #     break  # Exit loop if there's an issue with row indexing

#             # Process each day's attendance for this employee
#             for i in range(days_difference+1):
#                 current_day = from_date + timedelta(days=i)
#                 if current_day:  # Only process if day is not NaN
#                     attendance_record = {
#                         'EmployeeCode': employee_code,
#                         'Date': current_day.strftime('%Y-%m-%d'),  # The day column contains the date
#                         'IN': df.iloc[row_index -1, 6+i] or None,
#                         'OUT': df.iloc[row_index , 6+i] or None,
#                         'Duty Hours': df.iloc[row_index +1, 6+i] or None,
#                         'STATUS': df.iloc[row_index+2 , 6+i] or None,
#                     }
#                     # Append to the attendance data list
#                     attendance_data.append(attendance_record)

#             # Move to the next set of rows for the next employee
#             row_index += 5  # Increment by 5 for the next employee

#         # Create a DataFrame for the attendance data
#         attendance_df = pd.DataFrame(attendance_data)

#         # Use BytesIO to create an in-memory buffer for the Excel file
#         output = BytesIO()
#         writer = pd.ExcelWriter(output, engine='xlsxwriter')

#         # Write the DataFrame to Excel
#         attendance_df.to_excel(writer, index=False, sheet_name='Attendance')

#         # Close the writer to finalize the Excel file in the buffer
#         writer.close()

#         # Set the buffer's position to the beginning
#         output.seek(0)

#         # Return the Excel file as a response
#         response = HttpResponse(output, content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
#         response['Content-Disposition'] = f'attachment; filename=attendance_data.xlsx'

#         return response

#     return redirect("AttendaceMonthlyReport")




from .azure import upload_file_to_blob,download_blob
from .models import AttendanceSalaryFile

# @transaction.atomic
# def UploadAttendanceSalaryFile(request):
#     if 'OrganizationID' not in request.session:
#         return redirect(MasterAttribute.Host)
    
#     OrganizationID = request.session["OrganizationID"]
#     UserID = str(request.session["UserID"])
    
#     if request.method == 'POST' and request.FILES['doc']:
#         file = request.FILES['doc']
        
#         file_type = request.POST.get('Type')
#         month = request.POST.get('month')
#         year = request.POST.get('year')
#         Previousattendance_salary_file = AttendanceSalaryFile.objects.filter(
#             Type=file_type,
#             Month=month,
#             Year=year,
#             OrganizationID=OrganizationID,
          
#         ).first()
#         if Previousattendance_salary_file:
#             Previousattendance_salary_file.IsDelete = True
#             Previousattendance_salary_file.ModifyBy  = UserID
#             Previousattendance_salary_file.save()            
        
#         file_title = f'{file_type}_{month}_{year}'
         
      
        
#         attendance_salary_file = AttendanceSalaryFile.objects.create(
#             Type=file_type,
#             Month=month,
#             Year=year,
           
#             FileTitle=file_title,  
#             OrganizationID=OrganizationID,
#             CreatedBy=UserID,
           
#         )
#         id = attendance_salary_file.id
#         new_file = upload_file_to_blob(file, id)
        
       
#         return redirect(reverse('AttendanceSalaryList') + f'?Type={file_type}&month={month}&year={year}')
    
@transaction.atomic
def UploadAttendanceSalaryFile(request):
    if 'OrganizationID' not in request.session:
        return redirect(MasterAttribute.Host)
    
    OrganizationID = request.session["OrganizationID"]
    UserID = str(request.session["UserID"])
    
    if request.method == 'POST':
        file = request.FILES.get('doc')  # Excel file
        pdf_file = None
        if 'pdf' in request.FILES:
            pdf_file = request.FILES.get('pdf')  # PDF file

        file_type = request.POST.get('Type')
        month = request.POST.get('month')
        year = request.POST.get('year')

        # Check if a previous record exists
        Previousattendance_salary_file = AttendanceSalaryFile.objects.filter(
            Type=file_type,
            Month=month,
            Year=year,
            OrganizationID=OrganizationID,IsDelete=False
        )
        for Pr in Previousattendance_salary_file:
        
            if Pr:
                Pr.IsDelete = True
                Pr.ModifyBy = UserID
                Pr.save()

        file_title = f'{file_type}_{month}_{year}'

        # Create a new AttendanceSalaryFile instance
        attendance_salary_file = AttendanceSalaryFile.objects.create(
            Type=file_type,
            Month=month,
            Year=year,
            FileTitle=file_title,
            PdfFileTitle=file_title if pdf_file is not None else "",

            OrganizationID=OrganizationID,
            CreatedBy=UserID,
        )
        
        id = attendance_salary_file.id
        
        # Upload Excel file to Azure Blob Storage
        if file:
            upload_file_to_blob(file, id)  # For Excel file

        # Upload PDF file to Azure Blob Storage
        if pdf_file is not None:
            pdf_id = id  # Using the same ID for the PDF upload; you can adjust if needed
            upload_file_to_blob(pdf_file, pdf_id, is_pdf=True)  # Set is_pdf to True for PDF file
        
        return redirect(reverse('AttendanceSalaryList') + f'?Type={file_type}&month={month}&year={year}')




import mimetypes
import os  # Import os for handling file names
from django.http import HttpResponse, Http404
from django.contrib import messages

# def download_file(request):
#     id = request.GET.get('DID') 
#     file = AttendanceSalaryFile.objects.filter(id=id).first()
#     if not file:
#         raise Http404("File not found")
    
#     FileTitle = file.FileTitle  
#     FileName = file.FileName    

#     _, suffix = os.path.splitext(FileName)

#     file_type, _ = mimetypes.guess_type(FileName)
#     if file_type is None:
#         file_type = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'  
#     print(f"Guessing MIME type for '{FileName}': {file_type}")

#     blob_content = download_blob(FileName)  

#     if blob_content:
       
#         response = HttpResponse(blob_content, content_type=file_type)
#         response['Content-Disposition'] = f'attachment; filename="{FileTitle}{suffix}"'
#         messages.success(request, f"{FileTitle} was successfully downloaded")
#         return response

#     raise Http404("File not found")

import os
import mimetypes
from django.http import HttpResponse, Http404
from django.contrib import messages
from .models import AttendanceSalaryFile  

def download_file(request):
    if 'OrganizationID' not in request.session:
        return redirect(MasterAttribute.Host)

    OrganizationID = request.session["OrganizationID"]
    UserID = str(request.session["UserID"])
    DomainCode = request.session["DomainCode"]
    id = request.GET.get('DID')
    file_type = request.GET.get('type') 
    
    file = AttendanceSalaryFile.objects.filter(id=id).first()
    if not file:
        raise Http404("File not found")

    if file_type == 'excel' and file.FileName:
        FileTitle = file.FileTitle  
        FileName = file.FileName
    elif file_type == 'pdf' and file.PdfFileName:
        FileTitle = file.FileTitle  
        FileName = file.PdfFileName
    else:
        raise Http404("File not found")

    _, suffix = os.path.splitext(FileName)

    file_type, _ = mimetypes.guess_type(FileName)
    if file_type is None:
        file_type = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' if suffix in ['.xls', '.xlsx'] else 'application/pdf'

    print(f"Guessing MIME type for '{FileName}': {file_type}")

    blob_content = download_blob(FileName)

    if blob_content:
        response = HttpResponse(blob_content, content_type=file_type)
        response['Content-Disposition'] = f'attachment; filename="{DomainCode}_{FileTitle}{suffix}"'
      
        return response

    raise Http404("File not found")



def get_current_month_abbr():
    months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
    
    current_month = datetime.now().month
    
    return months[current_month - 1]


@transaction.atomic
def AttendanceSalaryList(request):
    if 'OrganizationID' not in request.session:
        return redirect(MasterAttribute.Host)

    OrganizationID = request.session["OrganizationID"]
    UserID = str(request.session["UserID"])
    Type = request.GET.get('Type','Attendance')

    today = datetime.now()
    
    if 'year' in request.GET:
        year = int(request.GET.get('year'))
    else:
        year = today.year  

    if 'month' in request.GET:
        month = request.GET.get('month')
    else:
        month = get_current_month_abbr()  
    year  = year
    month = month
    if month == 'All':
        attsalobj = AttendanceSalaryFile.objects.filter(
                    IsDelete=False,
                    OrganizationID=OrganizationID,
                    Type=Type,
                  
                    Year=year
                )
    else:
         attsalobj = AttendanceSalaryFile.objects.filter(
                    IsDelete=False,
                    OrganizationID=OrganizationID,
                    Type=Type,
                     Month=month,
                    Year=year
                )    
    

    context = {
        'attsalobj': attsalobj,
        'CYear': range(today.year, 2020, -1),
        'CMonth': today.month,
        'month': month,
        'Type':Type
        
    } 
    return render(request, "EMP_PAY/Attendance/AttendanceSalaryList.html", context)


def AttendaceCorrectEtmExlUp(request):
    if 'OrganizationID' not in request.session:
        return redirect(MasterAttribute.Host)
    
    OrganizationID = request.session["OrganizationID"]
    UserID = str(request.session["UserID"])
    EmployeeCode = request.session["EmployeeCode"]

    if request.method == "POST":
        print("hello POST")
        file = request.FILES['doc']
        fs = FileSystemStorage()
        filename = fs.save(file.name, file)
        file_path = fs.path(filename)

        df = pd.read_excel(file_path)

        attendance_data = []

        employee_code_col = 1  

      
        row_index = 8  
        from_date_str =df.iloc[2, 0]
        print("FromDate",from_date_str)
        to_date_str = df.iloc[3, 0]
        print("ToDate",to_date_str)
        from_date_cleaned = from_date_str.replace("From :", "").strip()
        to_date_cleaned = to_date_str.replace("To :", "").strip()

       
        from_date = datetime.strptime(from_date_cleaned, '%d %b %Y')
        to_date = datetime.strptime(to_date_cleaned, '%d %b %Y')
        date_difference = to_date - from_date

     
        days_difference = date_difference.days
        print("FromDate:", from_date)
        print("ToDate:", to_date)
        while row_index < len(df)-9:
           
            try:
                employee_code = df.iloc[row_index, employee_code_col]
            except IndexError:
                print(f"IndexError at row {row_index}: check if data is available")
                break 
           
            for i in range(days_difference+1):
                current_day = from_date + timedelta(days=i)
                if current_day:  
                    attendance_record = {
                        'EmployeeCode': employee_code,
                        'Date': current_day.strftime('%Y-%m-%d'), 
                        'IN': df.iloc[row_index -1, 6+i] or None,
                        'OUT': df.iloc[row_index , 6+i] or None,
                        'DutyHours': df.iloc[row_index +1, 6+i] or None,
                        'STATUS': df.iloc[row_index+2 , 6+i] or None,
                    }
                    attendance_data.append(attendance_record)
                    EmployeeCode =  attendance_record['EmployeeCode']
                    AttendaceDate  = attendance_record['Date']
                    In_Time = attendance_record['IN']
                    Out_Time = attendance_record['OUT']
                    Duty_Hour = attendance_record['DutyHours']
                    Status = attendance_record['STATUS']

                    if EmployeeCode and AttendaceDate:
                           PreviousRecord  = Attendance_Data.objects.filter(OrganizationID=OrganizationID,IsDelete=False,EmployeeCode=EmployeeCode,Date=AttendaceDate)
                           if PreviousRecord: 
                                for Pr in PreviousRecord:
                                    Pr.IsDelete = True
                                    Pr.ModifyBy = UserID
                                    Pr.save()
                           NewRecord =  Attendance_Data.objects.create(OrganizationID=OrganizationID,IsDelete=False,EmployeeCode=EmployeeCode,Date=AttendaceDate,CreatedBy=UserID,In_Time= In_Time,Out_Time= Out_Time,Duty_Hour=Duty_Hour,Status=Status,IsUpload=True)
                           if NewRecord:
                               print(NewRecord.EmployeeCode)

                    

           
            row_index += 5  

        

    return redirect("AttendaceMonthlyReport")

# Attendance  
@transaction.atomic     
def AttendanceProcess(request):
    if 'OrganizationID' not in request.session:
        return redirect(MasterAttribute.Host)
    else:
        print("Show Page Session")

    OrganizationID = request.session["OrganizationID"]
    UserID = str(request.session["UserID"])
    # emp_list =  EmployeeMaster.objects.filter(OrganizationID=OrganizationID,IsDelete=False).order_by('EmployeeCode')
    emp_list = EmployeeDataSelect(OrganizationID)
   
    try:
        org_obj = Organization_Details.objects.get(OID=OrganizationID, IsDelete=False)
        S_EndDate = org_obj.EndDate
    except Organization_Details.DoesNotExist:
        S_EndDate = 26

    # current_date = datetime.now().date()
    current_date =  datetime.strptime("2024-04-26", "%Y-%m-%d").date()


    if S_EndDate is not None:
        if current_date.day >= S_EndDate:
            start_date = current_date.replace(day=S_EndDate)
        else:
            start_date = current_date.replace(day=S_EndDate)
    else:
        start_date = current_date.replace(day=26)

    _, last_day_of_month = calendar.monthrange(current_date.year, current_date.month)
    end_date = current_date.replace(day=last_day_of_month)
    with transaction.atomic():
            if request.method == "POST":
                all_emp_codes = request.POST.getlist('all_emp_codes[]')

                current_date = start_date
                while current_date <= end_date:
                    for empcode in all_emp_codes:
                        if empcode is not None and empcode != '':
                            Emp_code = empcode
                            # Check if the current date is between start_date and end_date
                            if start_date <= current_date <= end_date:
                                Att_obj = Attendance_Data.objects.create(
                                    EmployeeCode=Emp_code,
                                    Date=current_date,
                                    In_Time='00:00',
                                    Out_Time='00:00',
                                    Duty_Hour='00:00',
                                    OrganizationID=OrganizationID,
                                    CreatedBy=UserID,
                                    Status='Present',
                                    IsUpload=False
                                )
                    current_date += timedelta(days=1)


                    
                messages.success(request,"Attendace Record Created Successfully !")
                return redirect('Daily_Attendace')
        
    
    

    context = {'Emp_list': emp_list, 'Start_Date': start_date,
        'To_Date': end_date,}
    return render(request, "EMP_PAY/Attendance/AttendanceProcess.html", context)









def Upload_Attendance_List(request):
    if 'OrganizationID' not in request.session:
        return redirect(MasterAttribute.Host)
    else:
        print("Show Page Session")
     
    OrganizationID = request.session["OrganizationID"]
    UserID = str(request.session["UserID"])
    EmployeeCode = request.session["EmployeeCode"] 
    
    current_date = datetime.now()
    
    year = int(request.GET.get('year', current_date.year))
    month_no = int(request.GET.get('month_no', current_date.month))
    
    previous_month = current_date.replace(year=year, month=month_no, day=1) - timedelta(days=1)
    
   
    next_month = min(
        current_date.replace(year=year, month=month_no, day=28) + timedelta(days=4),
        datetime.now().replace(day=1)
    )
    
    if next_month.month == month_no:
        next_month = next_month.replace(day=1)
    
   
    Data_File = Raw_Attendance_Data_File.objects.filter(
          OrganizationID = OrganizationID,
                       
       
        Attendance_Date__year=year,
        Attendance_Date__month=month_no,
         Attendance_Date__lte=current_date,
        IsDelete=False
    ).order_by('Attendance_Date')
    
   
          
    context = {
        'Data_File': Data_File,
        'current_month': datetime(year, month_no, 1),
        'previous_month': previous_month,
        'next_month': next_month
    }
    
    return render(request, "EMP_PAY/Attendance/Upload_Attendance_List.html", context)





def Payroll_List(request):
    if 'OrganizationID' not in request.session:
        return redirect(MasterAttribute.Host)
    else:
        print("Show Page Session")
     
    OrganizationID = request.session["OrganizationID"]
    UserID = str(request.session["UserID"])
    EmployeeCode = request.session["EmployeeCode"]
    
    current_year = datetime.now().year
    year = int(request.GET.get('current_year', current_year))
    
    action = request.GET.get('action')
    if action == 'prev_year':
        year -= 1
    elif action == 'next_year':
        year += 1
    
    months_data = SalarySlip.objects.filter(OrganizationID=OrganizationID, 
                                            IsDelete=False, 
                                            EmployeeCode=EmployeeCode,
                                             generated = True,
                                        HrVerify = True,
                                        FcVerify =  True,

                                            year=year).order_by('month')

    context = {
        'months_data': months_data,
        'current_year': year,
    }
    
    return render(request, "EMP_PAY/Salary/Payroll_List.html", context)

 

from collections import defaultdict
    
from .models import SalarySlip
from collections import defaultdict
from datetime import datetime, timedelta
from django.shortcuts import render, redirect

def Employees_Payroll_List(request):
    if 'OrganizationID' not in request.session:
        return redirect(MasterAttribute.Host)
    else:
        print("Show Page Session")

    OrganizationID = request.session["OrganizationID"]
    UserID = str(request.session["UserID"])
    UserType = request.session["UserType"]

    emp_list = EmployeeDataSelect(OrganizationID)

    current_date = datetime.now()
    year = int(request.GET.get('year', current_date.year))
    month_no = int(request.GET.get('month_no', current_date.month))

    previous_month = current_date.replace(year=year, month=month_no, day=1) - timedelta(days=1)
    next_month = min(
        current_date.replace(year=year, month=month_no, day=28) + timedelta(days=4),
        datetime.now().replace(day=1)
    )
    if next_month.month == month_no:
        next_month = next_month.replace(day=1)

    salary_slips = SalarySlip.objects.filter(
        EmployeeCode__in=[emp['EmployeeCode'] for emp in emp_list],
        month=month_no,
        year=year,
        OrganizationID=OrganizationID,
        IsDelete=False
    )

    attendancelock = AttendanceLock.objects.filter(
        EmployeeCode__in=[emp['EmployeeCode'] for emp in emp_list],
        month=month_no,
        year=year,
        OrganizationID=OrganizationID,
        IsDelete=False
    ).values('EmployeeCode', 'IsLock', 'id')

    generated_dict = defaultdict(lambda: {
        'generated': False,
        'id': 0,
        'approval_html': '',
        'status': 'Pending'
    })
    lock_dict = defaultdict(lambda: {'IsLock': False, 'id': 0})

    for slip in salary_slips:
     
        generated_dict[slip.EmployeeCode] = {
            'generated': slip.generated,
            'id': slip.id,
            'approval_html': slip.get_approval_status_html()  ,  
            'status': "Approved" if slip.HrVerify and slip.FcVerify else "Pending"  
        }

    for lock in attendancelock:
        lock_dict[lock['EmployeeCode']] = {'IsLock': lock['IsLock'], 'id': lock['id']}

    for emp in emp_list:
        slip_info = generated_dict[emp['EmployeeCode']]
        lock_info = lock_dict[emp['EmployeeCode']]

        emp['generated'] = slip_info['generated']
        emp['id'] = slip_info['id']

        emp['IsLock'] = lock_info['IsLock']
        emp['lockid'] = lock_info['id']
        emp['get_approval_status_html'] = slip_info['approval_html']  or '<p style="color: #f8ac59;">Attendacne Lock is  Pending</p>'
        emp['status'] = slip_info['status']  

    context = {
        'emps': emp_list,
        'current_month': datetime(year, month_no, 1),
        'previous_month': previous_month,
        'next_month': next_month,
        'emp_list': emp_list,
        'month_no': month_no,
        'year': year
    }

    return render(request, "EMP_PAY/Salary/Employees_Payroll_List.html", context)

def View_Attendance(request):
    if 'OrganizationID' not in request.session:
        return redirect(MasterAttribute.Host)
    else:
        print("Show Page Session")
     
    OrganizationID = request.session["OrganizationID"]
    UserID = str(request.session["UserID"])
    EmployeeCode = request.session["EmployeeCode"] 
    
    current_date = datetime.now()
    
    year = int(request.GET.get('year', current_date.year))
    month_no = int(request.GET.get('month_no', current_date.month))
    
    previous_month = current_date.replace(year=year, month=month_no, day=1) - timedelta(days=1)
    
   
    next_month = min(
        current_date.replace(year=year, month=month_no, day=28) + timedelta(days=4),
        datetime.now().replace(day=1)
    )
    
    if next_month.month == month_no:
        next_month = next_month.replace(day=1)
    
   
    attendance_data = Attendance_Data.objects.filter(
        OrganizationID=OrganizationID, 
        EmployeeCode=EmployeeCode,
        Date__year=year,
        Date__month=month_no,
         Date__lte=current_date,
        IsDelete=False
    ).order_by('Date')
    
    for record in attendance_data:
        update_request_exists = Update_Attendance_Request.objects.filter(Attendance_Data=record,OrganizationID=OrganizationID, 
                                            IsDelete=False ).exists()
        record.update_request_exists = update_request_exists
          
    context = {
        'attendance_data': attendance_data,
        'current_month': datetime(year, month_no, 1),
        'previous_month': previous_month,
        'next_month': next_month
    }
    
    return render(request, "EMP_PAY/Attendance/View_Attendance.html", context)






def Daily_Attendace(request):
    if 'OrganizationID' not in request.session:
        return redirect(MasterAttribute.Host)
    else:
        print("Show Page Session")
     
    OrganizationID = request.session["OrganizationID"]
    UserID = str(request.session["UserID"])
    
    emp_list = EmployeeDataSelect(OrganizationID)
    
    
    Q_Date  =  request.GET.get('Q_Date')
    attendance_data = Attendance_Data.objects.filter(
        OrganizationID=OrganizationID, 
      
        Date= Q_Date,
        IsDelete=False
    ).order_by('Date','EmployeeCode')
    
    # for record in attendance_data:
    #     update_request_exists = Update_Attendance_Request.objects.filter(Attendance_Data=record,OrganizationID=OrganizationID, 
    #                                         IsDelete=False ).exists()
    #     record.update_request_exists = update_request_exists
    for record in attendance_data:
       
        for emp in emp_list:
            if emp['EmployeeCode'] == record.EmployeeCode:
                
                record.EmployeeName = emp['EmpName']
                break
        
            

        update_request_exists = Update_Attendance_Request.objects.filter(
            Attendance_Data=record,
            OrganizationID=OrganizationID,
            IsDelete=False
        ).exists()
        record.update_request_exists = update_request_exists

          
    context = {
        'attendance_data': attendance_data,
        'Q_Date':Q_Date
    }
    
    return render(request, "EMP_PAY/Attendance/Daily_Attendace.html", context)


# def AttendanceLockView(request):
#     if 'OrganizationID' not in request.session:
#         return redirect(MasterAttribute.Host)
#     else:
#         print("Show Page Session")
     
#     OrganizationID = request.session["OrganizationID"]
#     UserID = str(request.session["UserID"])
#     EmployeeCode = request.GET.get('emp')
 
#     emp_Details  = EmployeeDataSelect(OrganizationID,EmployeeCode)

    
    
#     year = int(request.GET.get('year'))
#     month_no =  int(request.GET.get('month_no'))
#     month_name = calendar.month_name[int(month_no)]
   
#     StartDate = datetime(year, month_no, 1)

#     next_month = StartDate.replace(day=28) + timedelta(days=4)  
#     EndDate = next_month - timedelta(days=next_month.day)
     
    
#     StartDate = datetime(year, month_no, 1) - timedelta(days=5)
#     if month_no == 1:
#         year -= 1
#         month_no = 12
#     else:
#         month_no -= 1
#     StartDate = datetime(year, month_no, 26)

#     next_month = StartDate.replace(day=28) + timedelta(days=4)
#     EndDate = next_month.replace(day=25)
    
#     month_no += 1    
#     Totaldays = [(StartDate + timedelta(days=i)).strftime('%#d') for i in range((EndDate - StartDate).days + 1)]

#     Attendance = Attendance_Data.objects.filter(EmployeeCode=EmployeeCode,OrganizationID=OrganizationID,IsDelete = False,Date__range=(StartDate,EndDate)).order_by('Date')
        
#     leave_type  =Leave_Type_Master.objects.filter(IsDelete=False,Is_Active=True)
   
#     leavetype = Leave_Type_Master.objects.filter( IsDelete=False,Is_Active=True)
#     leavelist = [leave.Type for leave in leavetype]
    
#     lockid =  request.GET.get('lockid')
#     IsLock = request.GET.get('IsLock')
    

#     if lockid is not None and lockid != '0':
#         lock_obj = get_object_or_404(AttendanceLock, id=lockid, IsDelete=False)

    

#     if request.method == "POST":
#         if lockid is not None and lockid != '0':
#                 print("if run")
#                 btn = request.POST['btn']
#                 if btn == "Save":
#                     IsLock = False
#                 if btn == "Lock":
#                     IsLock  = True
                
#                 WeekOffCount = 0
#                 PresentCount = 0
#                 AbsentCount = 0
#                 l_Count = 0
#                 leave_counts = {leave: 0 for leave in leavelist}
#                 for att in  Attendance:
                          
#                             status = att.Status
#                             if status == 'Week off':
#                                 WeekOffCount += 1
#                             elif status == 'Present':
#                                 PresentCount += 1
#                             elif status == 'Absent' or status == None :
#                                 AbsentCount += 1
#                             elif status in leavelist:
                            
#                                 leave_counts[status] += 1
            
#                 for leave in leavelist:
                
#                     l_Count =  l_Count + leave_counts[leave] 

                
                
#                 TotalWorkingDays = WeekOffCount + PresentCount + l_Count
              
             
                
#                 total_no_Days_in_month = days_in_selected_month(int(month_no), int(year))
#                 minus = len(Totaldays) - total_no_Days_in_month     
                    
#                 PaiDays = TotalWorkingDays -abs(minus)
                
#                 lock_obj.PaiDays =  PaiDays
#                 lock_obj.ModifyBy =  UserID
#                 lock_obj.IsLock = IsLock
#                 lock_obj.save()
#                 if btn == "Save":
#                     messages.success(request,"Saved Successfully")

#                 if btn == "Lock":
#                     messages.success(request,"Locked Successfully")
                
#         else:
#             print("else run")
             
#             btn = request.POST['btn']
#             if btn == "Save":
#                 IsLock = False
#             if btn == "Lock":
#                 IsLock  = True
           
           
#             WeekOffCount = 0
#             PresentCount = 0
#             AbsentCount = 0
#             l_Count = 0
#             leave_counts = {leave: 0 for leave in leavelist}
#             for att in  Attendance:
                        
#                         status = att.Status
#                         if status == 'Week off':
#                             WeekOffCount += 1
#                         elif status == 'Present':
#                             PresentCount += 1
#                         elif status == 'Absent' or status == None :
#                             AbsentCount += 1
#                         elif status in leavelist:
                        
#                             leave_counts[status] += 1
        
#             for leave in leavelist:
            
#                 l_Count =  l_Count + leave_counts[leave] 

            
            
#             TotalWorkingDays = WeekOffCount + PresentCount + l_Count
            
#             total_no_Days_in_month = days_in_selected_month(int(month_no), int(year))
#             minus = len(Totaldays) - total_no_Days_in_month 
            
          
                
#             PaiDays = TotalWorkingDays -  abs(minus)
            

#             att_lock = AttendanceLock.objects.create(OrganizationID = OrganizationID,CreatedBy = UserID,EmployeeCode = EmployeeCode, month = month_no,month_name = month_name,year = year,PaiDays = PaiDays,total_no_Days_in_month = total_no_Days_in_month,IsLock = IsLock)
#             if btn == "Save":
#                 messages.success(request,"Saved Successfully")

#             if btn == "Lock":
#                 messages.success(request,"Locked Successfully")
#         return redirect(reverse('Employees_Payroll_List') + f'?year={year}&month_no={month_no}') 
          

#     context= { 'attendance_data':Attendance,'leave_type':leave_type,'emp_Details':emp_Details,'month':month_name,'year':year,'lockid':lockid,
#               'IsLock':IsLock}
#     return render(request, "EMP_PAY/Attendance/AttendanceLockView.html", context)

def get_month_range(year, month_no):
    start_date = datetime(year, month_no, 1)
    next_month = start_date.replace(day=28) + timedelta(days=4)
    end_date = next_month - timedelta(days=next_month.day)
    return start_date, end_date

def get_previous_month_start_date(year, month_no):
    if month_no == 1:
        year -= 1
        month_no = 12
    else:
        month_no -= 1
    return datetime(year, month_no, 26)

def get_attendance_counts(attendance, leavelist):
    week_off_count = 0
    present_count = 0
    absent_count = 0
    leave_counts = {leave: 0 for leave in leavelist}

    for att in attendance:
        status = att.Status
        if status == 'Week off':
            week_off_count += 1
        elif status == 'Present':
            present_count += 1
        elif status == 'Absent' or status is None:
            absent_count += 1
        elif status in leavelist:
            leave_counts[status] += 1

    total_working_days = week_off_count + present_count + sum(leave_counts.values())
    return week_off_count, present_count, absent_count, leave_counts, total_working_days

def calculate_paid_days(total_working_days, total_days, total_no_days_in_month):
    adjustment = len(total_days) - total_no_days_in_month
    return total_working_days - adjustment

def days_in_selected_month(month_no, year):
    if month_no == 12:
        next_month = 1
        next_month_year = year + 1
    else:
        next_month = month_no + 1
        next_month_year = year
    start_date = datetime(year, month_no, 1)
    end_date = datetime(next_month_year, next_month, 1)
    return (end_date - start_date).days

def AttendanceLockView(request):
    if 'OrganizationID' not in request.session:
        return redirect(MasterAttribute.Host)
    
    OrganizationID = request.session["OrganizationID"]
    UserID = str(request.session["UserID"])
    EmployeeCode = request.GET.get('emp')
    emp_Details = EmployeeDataSelect(OrganizationID, EmployeeCode)

    year = int(request.GET.get('year'))
    month_no = int(request.GET.get('month_no'))
    month_name = calendar.month_name[month_no]

    # Correctly calculate the start and end dates
    start_date = get_previous_month_start_date(year, month_no)
    end_date = start_date.replace(day=28) + timedelta(days=4)
    end_date = end_date.replace(day=25)

    # Generate total_days list
    total_days = [(start_date + timedelta(days=i)).strftime('%#d') for i in range((end_date - start_date).days + 1)]

    attendance = Attendance_Data.objects.filter(EmployeeCode=EmployeeCode, OrganizationID=OrganizationID, IsDelete=False, Date__range=(start_date, end_date)).order_by('Date')

    leave_type = Leave_Type_Master.objects.filter(IsDelete=False, Is_Active=True)
    leavelist = [leave.Type for leave in leave_type]

    lockid = request.GET.get('lockid')
    IsLock = request.GET.get('IsLock')

    if lockid and lockid != '0':
        lock_obj = get_object_or_404(AttendanceLock, id=lockid, IsDelete=False)
    print(len(total_days))
    if request.method == "POST":
        btn = request.POST['btn']
        IsLock = btn == "Lock"

        week_off_count, present_count, absent_count, leave_counts, total_working_days = get_attendance_counts(attendance, leavelist)
        total_no_days_in_month = days_in_selected_month(month_no, year)
        # pai_days = calculate_paid_days(total_working_days, total_days, total_no_days_in_month)
        pai_days = len(total_days)
        # Adjust the paid days if there are 31 days from 26th to 25th, but the month has only 30 days
        print(total_days)
        if len(total_days) == 30 and total_no_days_in_month == 31:
            pai_days += 1
        elif len(total_days) == 31 and total_no_days_in_month == 30:
            pai_days -= 1
        elif len(total_days) == 30 and total_no_days_in_month == 28:  # Adjust for non-leap year February
            pai_days -= 2
        elif len(total_days) == 31 and total_no_days_in_month == 29:  # Adjust for leap year February
            pai_days -= 1

        if lockid and lockid != '0':
            lock_obj.PaiDays = pai_days
            lock_obj.ModifyBy = UserID
            lock_obj.IsLock = IsLock
            lock_obj.save()
        else:
            AttendanceLock.objects.create(
                OrganizationID=OrganizationID,
                CreatedBy=UserID,
                EmployeeCode=EmployeeCode,
                month=month_no,
                month_name=month_name,
                year=year,
                PaiDays=pai_days,
                total_no_Days_in_month=total_no_days_in_month,
                IsLock=IsLock
            )

        messages.success(request, "Saved Successfully" if btn == "Save" else "Locked Successfully")
        return redirect(reverse('Employees_Payroll_List') + f'?year={year}&month_no={month_no}')

    context = {
        'attendance_data': attendance,
        'leave_type': leave_type,
        'emp_Details': emp_Details,
        'month': month_name,
        'year': year,
        'lockid': lockid,
        'IsLock': IsLock
    }
    return render(request, "EMP_PAY/Attendance/AttendanceLockView.html", context)


 

from datetime import datetime, timedelta
from calendar import monthrange


from Leave_Management_System.models import Emp_Leave_Balance_Master,EmpMonthLevelCreditMaster

# def GenerateWeekoff(request):
#     if 'OrganizationID' not in request.session:
#         return redirect(MasterAttribute.Host)
#     else:
#         print("Show Page Session")

     
#     OrganizationID = request.session["OrganizationID"]
#     UserID = str(request.session["UserID"])
#     # EmployeeCode = request.GET.get('emp')
     
#     current_month = 4
#     current_year = 2024
#     EmployeeCode = 451000245
    
#     hotelapitoken = MasterAttribute.HotelAPIkeyToken
#     headers = {
#         'hotel-api-token': hotelapitoken  
#     }


#     emp_data_url = "http://hotelops.in/api/PyAPI/HREmployeeDataEmpCodeSelect?EmpCode="+str(EmployeeCode)+"&OID="+str(OrganizationID)

#     try:
#         response = requests.get(emp_data_url, headers=headers)
#         response.raise_for_status()  
#         emp_Details = response.json()
    
#     except requests.exceptions.RequestException as e:
#         print(f"Error occurred: {e}")

    
#     EmpName = emp_Details[0]['EmpName']
#     ReportingtoDesigantion =  emp_Details[0]['ReportingtoDesigantion']
   
#     _, num_days = monthrange(current_year, current_month)
   
#     first_weekday = monthrange(current_year, current_month)[0]
#     num_weeks = (num_days + first_weekday) // 7 + ((num_days + first_weekday) % 7 > 0)
    
#     week_offs_granted = 0
#     compo_offs_granted = 0
    
#     for week_number in range(1, num_weeks + 1):
#         week_start_day = (week_number - 1) * 7 + 1
#         week_end_day = min(week_start_day + 6, num_days)

#         Status_list = ['Present']
#         leave_type = Leave_Type_Master.objects.filter(OrganizationID=OrganizationID, IsDelete=False)
#         leave_list = []
#         for leave in leave_type:
#             leave_list.append(leave.Type)
#         Status_list.extend(leave_list)
        
#         attendance_data_working_days = Attendance_Data.objects.filter(EmployeeCode=EmployeeCode, OrganizationID=OrganizationID, IsDelete=False, Status__in=Status_list, Date__range=(datetime(current_year, current_month, week_start_day), datetime(current_year, current_month, week_end_day)))
        
#         working_days = attendance_data_working_days.count()
        
#         attendance_data_absent_days = Attendance_Data.objects.filter(EmployeeCode=EmployeeCode, OrganizationID=OrganizationID, IsDelete=False, Status='Absent', Date__range=(datetime(current_year, current_month, week_start_day), datetime(current_year, current_month, week_end_day)))
        
#         absent_dates = [data.Date for data in attendance_data_absent_days ]
      
        
#         if working_days >= 4 and week_offs_granted < 4 and working_days != 7:
            
#             for date in absent_dates:
#                 try:
#                     WeekOffDetails.objects.get(Emp_Code=EmployeeCode, WeekoffDate=date)
#                 except  WeekOffDetails.DoesNotExist :    
#                     WeekOffDetails.objects.create(Emp_Code=EmployeeCode, empname=EmpName, CreatedBy = UserID ,ReportingtoDesigantion = ReportingtoDesigantion, WeekoffDate=date,OrganizationID =OrganizationID)
#                     att_update =  Attendance_Data.objects.get(EmployeeCode = EmployeeCode , Date = date)
#                     att_update.Status = 'Week off'
#                     att_update.ModifyBy = UserID
#                     att_update.save()
                 
#                     week_offs_granted += 1
                
#         if working_days == 7:
            
                
#                 compo_offs_granted += 1
#                 com = Emp_Leave_Balance_Master.objects.get(Leave_Type_Master__Type__icontains = "comp" ,Emp_code = EmployeeCode,IsDelete=False,OrganizationID = OrganizationID)
#                 Balance = com.Balance + 1
#                 com.Balance = Balance
#                 com.ModifyBy = UserID
#                 com.save()
#                 Remarks = f'Credited  on behalf of  present'
#                 leave_id = Leave_Type_Master.objects.get(Type__icontains = 'comp' ,IsDelete = False,OrganizationID = OrganizationID) 
#                 credit = EmpMonthLevelCreditMaster.objects.create(
#                     Leave_Type_Master_id =  leave_id.id,
#                     Emp_code =  EmployeeCode,
#                     credit = Balance ,
#                     Remarks = Remarks 
#                 )
#     return JsonResponse({'success':'Run'})
      
    


def UpdateStatus(request):
    if 'OrganizationID' not in request.session:
        return redirect(MasterAttribute.Host)
    else:
        print("Show Page Session")
     
    OrganizationID = request.session["OrganizationID"]
    UserID = str(request.session["UserID"])
    if request.method == "GET":
        Attid = request.GET.get('Attid')
        Status = request.GET.get('Status')

          
        att_obj = get_object_or_404(Attendance_Data,id=Attid,IsDelete=False,OrganizationID=OrganizationID)
        att_obj.Status = Status
        att_obj.ModifyBy = UserID
        att_obj.save()

        response_data = {
           
            'message': f'Status {Status} updated successfully'
        }
        return JsonResponse(response_data, status=200)
        
        
        

def get_employee_attendance_data():
    try:
        with connection.cursor() as cursor:
            # Execute the stored procedure
            cursor.execute("{CALL getEmpAttendanceData}")

            # Fetch all rows (assuming a result set is returned)
            results = cursor.fetchall()

            # Manually specify the column names if `description` is unavailable
            columns = ["CID","ID","NAME","DEPARTMENT", "DESIGNATION","EmployeeCode","Date", "In_Time", "Out_Time", "S_In_Time", "S_Out_Time", "Duty_Hour", "Status"]

            # Map the results to a list of dictionaries
            data = [dict(zip(columns, row)) for row in results]

            return data
    except Exception as e:
        print(f"Error fetching data: {e}")
        return []
import json
from collections import defaultdict
import datetime
from datetime import date
def process_attendance_data(raw_data):
    # Example function to process the data and convert date objects to strings
    for record in raw_data:
        if isinstance(record.get('Date'), date):
            record['Date'] = record['Date'].strftime('%Y-%m-%d')  # Convert date to string
        # If you have any other date fields, you can handle them similarly
        if isinstance(record.get('In_Time'), date):
            record['In_Time'] = record['In_Time'].strftime('%Y-%m-%d')
        if isinstance(record.get('Out_Time'), date):
            record['Out_Time'] = record['Out_Time'].strftime('%Y-%m-%d')

    return raw_data

from datetime import datetime, timedelta
from django.shortcuts import render

def attendance_report(request):
    report_data = get_employee_attendance_data()  # This should return a list of records
    
    start_date = datetime.strptime(request.GET.get('start_date', '2024-10-26'), '%Y-%m-%d')
    end_date = datetime.strptime(request.GET.get('end_date', '2024-11-25'), '%Y-%m-%d')

    # Group the attendance data by EmployeeCode
    # grouped_data = {}
    # for record in report_data:
    #     emp_code = record['EmployeeCode']
    #     if emp_code not in grouped_data:
    #         grouped_data[emp_code] = []
    #     grouped_data[emp_code].append(record)

    grouped_data = {}  # Initialize an empty dictionary to hold grouped records
    for record in report_data:
        emp_code = record['EmployeeCode']  # Get the EmployeeCode for each record
        
        # If this EmployeeCode does not exist in grouped_data, create a new entry with an empty list
        if emp_code not in grouped_data:
            grouped_data[emp_code] = []
        
        # Append the current record to the list of that EmployeeCode
        grouped_data[emp_code].append(record)
    

    # Generate the list of all unique dates in the report data
    all_dates = sorted(set(record['Date'] for record in report_data))

    # Generate the date range from start_date to end_date
    date_range = []
    current_date = start_date
    while current_date <= end_date:
        date_range.append(current_date.strftime('%Y-%m-%d'))
        current_date += timedelta(days=1)

    # Create the table header row with both date and weekday
    header_row = ['NAME',  'EmployeeCode']
    for date_str in date_range:
        date_obj = datetime.strptime(date_str, '%Y-%m-%d')
        day_of_month = date_obj.day
        day_of_week = date_obj.strftime('%A')  # Full weekday name (e.g., "Monday")
        header_row.append(f'{day_of_month} <br/> {day_of_week}')

    # Create the table body for each employee
    table_rows = []
    for emp_code, employee_data in grouped_data.items():
        employee = employee_data[0]  # Assume the first record has all the employee details
        row = [
            employee['NAME'],
            # employee['DEPARTMENT'],
            # employee['DESIGNATION'],
            emp_code+"<br/> In <br/> Out </br>  In <br/> Out <br> Hours </br> Status"
        ]

        # For each date, check if the employee has attendance data
        for date_str in date_range:
            # Find the record for this employee and date
            date_obj = datetime.strptime(date_str, "%Y-%m-%d").date()
            record = next((r for r in employee_data if r['Date'] == date_obj), None)
            
            if record:
                # Format times (remove unnecessary microseconds)
                in_time = record['In_Time'][:-7] if record['In_Time'] else ''
                out_time = record['Out_Time'][:-7] if record['Out_Time'] else ''
                s_in_time = record['S_In_Time'][:-7] if record['S_In_Time'] else ''
                s_out_time = record['S_Out_Time'][:-7] if record['S_Out_Time'] else ''
                duty_hour = record['Duty_Hour'][:-7] if record['Duty_Hour'] else ''
                status = record['Status']
                
                row.append(f'<br/> {in_time} <br/> {out_time} <br/>  {s_in_time}  <br/> {s_out_time} <br/> {duty_hour} <br/><b>{status}</b>')
            else:
                row.append('')  # Empty cell if no data for that date

        table_rows.append(row)

    # Pass the grouped data, date range, and header row to the template
    return render(request, 'EMP_PAY/Attendance/attendance_report.html', {
        'date_range': date_range,
        'header_row': header_row,
        'table_rows': table_rows,
        'start_date': start_date,
        'end_date': end_date
    })


def attendance_report_Old(request):
    raw_data = get_employee_attendance_data()  # This fetches raw data
    raw_data = process_attendance_data(raw_data)  # Convert any date fields to strings

    # Now serialize the data into JSON
    raw_data_json = json.dumps(raw_data)
    start_date = '2024-10-26'
    end_date  = '2024-11-25'
    # Pass the JSON data to the template
    return render(request, 'EMP_PAY/Attendance/attendance_report.html', {'report_data_json': raw_data_json,'start_date':start_date,'end_date':end_date})


from django.db import connection
def AttendaceMonthlyReport(request):
    if 'OrganizationID' not in request.session:
        return redirect(MasterAttribute.Host)
    else:
        print("Show Page Session")
     
    OrganizationID = request.session["OrganizationID"]
    UserID = str(request.session["UserID"])
    
    
   


    I = request.GET.get('I',OrganizationID)
    emp_list =  EmployeeDataSelect(OrganizationID)
    EmployeeCode = request.GET.get('EmployeeCode','All')  # Get the EmployeeCode from the form
    print("EmployeeCode = ",EmployeeCode)

    year = request.GET.get('year')
    if year:
        year = int(year)
    else:
        year = datetime.now().year
    month_no =  request.GET.get('month_no')
    if month_no:
        month_no = int(month_no)
    else:
        month_no = datetime.now().month  
    month_name = calendar.month_name[int(month_no)]    
    StartDate = datetime(year, month_no, 1)

    next_month = StartDate.replace(day=28) + timedelta(days=4)  
    EndDate = next_month - timedelta(days=next_month.day)
     
    
    StartDate = datetime(year, month_no, 1) - timedelta(days=5)
    if month_no == 1:
        year -= 1
        month_no = 11
    else:
        month_no -= 1
    StartDate = datetime(year, month_no, 26)

    next_month = StartDate.replace(day=28) + timedelta(days=4)
    EndDate = next_month.replace(day=25)
    
    month_no += 1
    days = [(StartDate + timedelta(days=i)).strftime('%#d') for i in range((EndDate - StartDate).days + 1)]
    
    with connection.cursor() as cursor:
        cursor.execute("EXEC GetAttendancePivot_New %s, %s, %s, %s", [OrganizationID, StartDate, EndDate, EmployeeCode])
        rows = cursor.fetchall()
        columns = [col[0] for col in cursor.description]

    rowslist = [dict(zip(columns, row)) for row in rows]
    
   
   
      
   
    leavetype = Leave_Type_Master.objects.filter(IsDelete=False,Is_Active=True)
    leavelist = [leave.Type for leave in leavetype]
    print(leavelist)
    for row in rowslist:
        
            TotalDays = len(days)
            

            WeekOffCount = 0
            PresentCount = 0
            AbsentCount = 0
            l_Count = 0
            leave_counts = {leave: 0 for leave in leavelist}
            
            for day in days:
                status = row[day]
                actual_status=None
                if status:
                    # Extract the actual status from the last part of the string
                    actual_status = status.split("^")[-1].strip()
                
                if actual_status == 'Week off': 
                    WeekOffCount += 1
                elif actual_status == 'P':
                    PresentCount += 1
                elif actual_status == 'A' or actual_status == None :
                    AbsentCount += 1
                elif actual_status in leavelist:
                   
                    leave_counts[actual_status] += 1
            
            for leave in leavelist:
              
                l_Count =  l_Count + leave_counts[leave] 
            TotalWorkingDays = WeekOffCount + PresentCount + l_Count
            row['TotalWorkingDays'] =  TotalWorkingDays
            row['Present'] = PresentCount
            row['Absent'] = AbsentCount
            row['WeekOff'] = WeekOffCount
            total_no_Days_in_month = days_in_selected_month(int(month_no), int(year))
            minus = TotalDays - total_no_Days_in_month 
            row['TotalPaidDays'] = TotalWorkingDays - ( minus )
            

            row['leave_counts'] = leave_counts 
            row['l_Count'] = l_Count 
            
            
            
           
   

    today = datetime.today()
    CYear = today.year
    CMonth = today.month

    context = {
                'CYear':range(CYear,2020,-1),'CMonth':CMonth,
                'month_no':month_no,
                'year':year,
                'month_name':month_name,
                'rowslist':rowslist,
                'days':days,
                'leavelist':leavelist,
                'emp_list':emp_list,
                'EmployeeCode':EmployeeCode
               
            
               }
     
   
    return render(request, "EMP_PAY/Attendance/AttendaceMonthlyReport.html", context)





def UpdateRequestlist(request):
    if 'OrganizationID' not in request.session:
        return redirect(MasterAttribute.Host)
    else:
        print("Show Page Session")
     
    OrganizationID = request.session["OrganizationID"]
    UserID = str(request.session["UserID"])
    EmployeeCode = request.session["EmployeeCode"]
    Status = request.GET.get('Status')
    if Status:
        Apporve_status = Status
    if Status is None:
        Apporve_status = 0    

    att_reqs = Update_Attendance_Request.objects.filter(OrganizationID=OrganizationID,Attendance_Data__EmployeeCode= EmployeeCode,IsDelete=False,Apporve_status= Apporve_status)
    
    context = {'att_reqs':att_reqs,'Apporve_status':Apporve_status}
    return render(request, "EMP_PAY/Attendance/UpdateRequestlist.html", context)

 





def UpdateRequestlist_HR(request):
    if 'OrganizationID' not in request.session:
        return redirect(MasterAttribute.Host)
    else:
        print("Show Page Session")
     
    OrganizationID = request.session["OrganizationID"]
    UserID = str(request.session["UserID"])
    # EmployeeCode = request.session["EmployeeCode"]
    
    
    # emp_list =  EmployeeMaster.objects.filter(OrganizationID=OrganizationID, IsDelete=False).order_by('EmployeeCode')
    emp_list =  EmployeeDataSelect(OrganizationID)
    
    
 
    Status = request.GET.get('Status')
    if Status:
        Apporve_status = Status
    if Status is None:
        Apporve_status = 0    

    att_reqs = Update_Attendance_Request.objects.filter(OrganizationID=OrganizationID,IsDelete=False,Apporve_status= Apporve_status)
    print("att_reqs = ",att_reqs)
  
    employee_data = []
    try:
        for emp in emp_list:
            
            EmployeeCode = emp['EmployeeCode']
            print
            Update_Attendance = Update_Attendance_Request.objects.filter(Attendance_Data__EmployeeCode=EmployeeCode,OrganizationID=OrganizationID,IsDelete=False)

            if Update_Attendance:
            
                employee_details = {
                    'EmployeeCode': EmployeeCode,
                    'EmpName': emp['EmpName'],
                    'Department': emp['Department'],
                    'Designation': emp['Designation']
                    
                }

                employee_data.append(employee_details)
        
    except:
        messages.warning(request,'Data Not Found')            
   

    context = {'att_reqs':att_reqs,'Apporve_status':Apporve_status,'employee_data':employee_data}
    return render(request, "EMP_PAY/Attendance/UpdateRequestlist_HR.html", context)



@transaction.atomic
def UpdateRequest(request):
    if 'OrganizationID' not in request.session:
        return redirect(MasterAttribute.Host)
    else:
        print("Show Page Session")
     
    OrganizationID = request.session["OrganizationID"]
    UserID = str(request.session["UserID"])
    EmployeeCode = request.session["EmployeeCode"]
    id = request.GET.get('ID')
    obj = Attendance_Data.objects.get(id=id)
    with transaction.atomic():
        if request.method == "POST":
            Reason = request.POST['Reason'] 
            req =  Update_Attendance_Request.objects.create(Attendance_Data_id = id,Reason=Reason,
                                                            CreatedBy= UserID,OrganizationID=OrganizationID,IsDelete=False)
            messages.success(request,"Applied Successfully")
            return redirect('UpdateRequestlist')
    
    context = {'obj':obj} 
    return render(request,"EMP_PAY/Attendance/UpdateRequest.html", context)



# @transaction.atomic
# def Update_Attendance(request):
#     if 'OrganizationID' not in request.session:
#         return redirect(MasterAttribute.Host)
#     else:
#         print("Show Page Session")
     
#     OrganizationID = request.session["OrganizationID"]
#     UserID = str(request.session["UserID"])
#     id = request.GET.get('ID')
    
#     obj = Attendance_Data.objects.get(id=id)
#     pre_status = obj.Status
    
#     U_ID = request.GET.get('U_ID')
    
#     req =  Update_Attendance_Request.objects.get(id=U_ID)
#     leave_type  =Leave_Type_Master.objects.filter(Is_Active=True,IsDelete=False)
#     with transaction.atomic():
#         if request.method == "POST":
#             btn = request.POST.get('btn')
#             if btn == "1" :
#                 obj.In_Time = request.POST.get('in') 
#                 obj.Out_Time =  request.POST.get('Out')
                

#                 Status =  request.POST.get('Status')
#                 if Status == "":
#                     obj.Status = pre_status
#                 else:
#                     obj.Status = Status    
#                 obj.ModifyBy = UserID
#                 obj.save()
            
#                 req.Apporve_status = 1
#             else:
#                 req.Apporve_status = -1
                
#             req.ModifyBy = UserID
#             req.save()

#             messages.success(request,"Updated Successfully")
            
#             return redirect(reverse('UpdateRequestlist_HR') + f'?Status={btn}') 
        
        
    
#     context ={'obj':obj,'req':req}
#     return render(request,"EMP_PAY/Attendance/Update_Attendance.html", context)
from django.shortcuts import render, redirect, get_object_or_404
from django.urls import reverse
from django.contrib import messages
from django.db import transaction

@transaction.atomic
def Update_Attendance(request):
    if 'OrganizationID' not in request.session:
        return redirect(MasterAttribute.Host)
    
    organization_id = request.session["OrganizationID"]
    user_id = str(request.session["UserID"])
    attendance_id = request.GET.get('ID')
    update_request_id = request.GET.get('U_ID')
    
    # Fetch required objects
    obj = get_object_or_404(Attendance_Data, id=attendance_id)
    req = get_object_or_404(Update_Attendance_Request, id=update_request_id)
    pre_status = obj.Status

    if request.method == "POST":
        btn = request.POST.get('btn')
        with transaction.atomic():
            # Update Attendance Data
            obj.In_Time = request.POST.get('in_time') or obj.In_Time
            obj.Out_Time = request.POST.get('out_time') or obj.Out_Time
            obj.S_In_Time = request.POST.get('s_in_time') or obj.S_In_Time
            obj.S_Out_Time = request.POST.get('s_out_time') or obj.S_Out_Time
            new_status = request.POST.get('status')

            if new_status:
                obj.Status = new_status
            else:
                obj.Status = pre_status

            obj.ModifyBy = user_id
            obj.save()

            # Update Request Approval Status
            req.Apporve_status = 1 if btn == "1" else -1
            req.ModifyBy = user_id
            req.save()

            messages.success(request, "Attendance updated successfully.")
            return redirect(reverse('UpdateRequestlist_HR') + f'?Status={btn}')

    context = {
        'obj': obj,
        'req': req,
    }
    return render(request, "EMP_PAY/Attendance/Update_Attendance.html", context)



@transaction.atomic
def Update_Attendance_HR(request):
    if 'OrganizationID' not in request.session:
        return redirect(MasterAttribute.Host)
    else:
        print("Show Page Session")
     
    OrganizationID = request.session["OrganizationID"]
    UserID = str(request.session["UserID"])
    id = request.GET.get('ID')
    
    obj = Attendance_Data.objects.get(id=id)
    pre_status = obj.Status
    leave_type  =Leave_Type_Master.objects.filter(Is_Active=True,IsDelete=False)
    
    with transaction.atomic():
        if request.method == "POST":
                Page = request.POST.get('Page')
                emp = request.POST.get('emp')
                year = request.POST.get('year')
                month_no = request.POST.get('month_no')


           
                obj.In_Time = request.POST.get('in') 
                obj.Out_Time =  request.POST.get('Out')
                Q_Date = obj.Date
                
                Status =  request.POST.get('Status')
                if Status == "":
                    obj.Status = pre_status
                else:
                    obj.Status = Status    
                obj.ModifyBy = UserID
                obj.save()
            
                messages.success(request,"Updated Successfully")
                if Page == "VESD":
                    return redirect(reverse('View_Emmployee_Salary_Details') + f'?emp={emp}&year={year}&month_no={month_no}')
                    
                if Page  == "DA":
                    
                    return redirect(reverse('Daily_Attendace') + f'?Q_Date={Q_Date}') 
                
                    

    context ={'obj':obj,'leave_type':leave_type}
    return render(request,"EMP_PAY/Attendance/Update_Attendance_HR.html", context)









def days_in_selected_month(month_no, year):
    num_days = calendar.monthrange(year, month_no)[1]
    return num_days


import pandas as pd
@transaction.atomic
def View_Emmployee_Salary_Details(request):
    if 'OrganizationID' not in request.session:
        return redirect(MasterAttribute.Host)
    else:
        print("Show Page Session")
     
    OrganizationID = request.session["OrganizationID"]
    UserID = str(request.session["UserID"])
    EmployeeCode = request.GET.get('emp')
    org_Details  =  OrganizationMaster.objects.get(OrganizationID= OrganizationID)
    
    leave_type  =Leave_Type_Master.objects.filter(Is_Active=True,IsDelete=False)

    hotelapitoken = MasterAttribute.HotelAPIkeyToken
    headers = {
    'hotel-api-token': hotelapitoken  
    }
    api_url = "http://hotelops.in/api/PyAPI/HREmployeeSalary?EmpCode="+str(EmployeeCode)+"&OrganizationID="+str(OrganizationID)

    try:
        response = requests.get(api_url, headers=headers)
        response.raise_for_status()  
        emp_sal_Det = response.json()
        # df = pd.DataFrame(emp_sal_Det)
        # print(df) 
     
    except requests.exceptions.RequestException as e:
         print(f"Error occurred: {e}")
    
  
 
    api_ur = "http://hotelops.in/api/PyAPI/HREmployeeDataEmpCodeSelect?EmpCode="+str(EmployeeCode)+"&OID="+str(OrganizationID)

    try:
        response = requests.get(api_ur, headers=headers)
        response.raise_for_status()  
        emp_Details = response.json()
        date_object = datetime.strptime(emp_Details[0]['DateofBirth']  , '%Y-%m-%d')
        formatted_date_DOB = date_object.strftime('%d %b %Y')
        emp_Details[0]['DOB'] = formatted_date_DOB
      
    except requests.exceptions.RequestException as e:
        print(f"Error occurred: {e}")
    
    # print(emp_Details)
    ID =  request.GET.get('ID')
    sal_obj  = None
    if ID != '0' :
        sal_obj = get_object_or_404(SalarySlip,id= ID,IsDelete = False,OrganizationID = OrganizationID)

    year = request.GET.get('year')
    month_no =  request.GET.get('month_no')
    month_name = calendar.month_name[int(month_no)]
    # Gross (A)
    fixed_basic = emp_sal_Det[0]['Monthly'] or 0
    fixed_HRA  =  emp_sal_Det[1]['Monthly'] or 0
    Conveyance_Allowance  =  emp_sal_Det[2]['Monthly'] or 0
    CCA  =  emp_sal_Det[3]['Monthly'] or 0
    Other_Allowance  =  emp_sal_Det[4]['Monthly'] or 0
    # Deduction (B) 
    PT  =  emp_sal_Det[5]['Monthly'] or 0
    Meals  =  emp_sal_Det[8]['Monthly'] or 0
    Accommodation  =  emp_sal_Det[9]['Monthly'] or 0
 



    EmployeePF = 	emp_sal_Det[10]['Monthly'] or 0
    CompanyContributionToESIC =	emp_sal_Det[11]['Monthly'] or 0
    TotalCompanyContribution =	int((EmployeePF + CompanyContributionToESIC)) or 0
   


    BankName =  emp_Details[0]['BankName'] 
    BankIFSCCode =  emp_Details[0]['BankIFSCCode']
    BankBranch  = emp_Details[0]['BankBranch']
      
  
    Attendance = Attendance_Data.objects.filter(EmployeeCode=EmployeeCode,OrganizationID=OrganizationID,IsDelete = False,Date__month=month_no,Date__year=year).order_by('Date')
    EmpName = emp_Details[0]['EmpName'] or ''
    if fixed_basic and fixed_HRA:
        gross_salary = fixed_basic + fixed_HRA + Conveyance_Allowance + CCA + Other_Allowance

        try:

            att_lock = AttendanceLock.objects.get(EmployeeCode = EmployeeCode,month = month_no,year= year) 
            total_no_Days_in_month = int(att_lock.total_no_Days_in_month)
            IsLock  = att_lock.IsLock
            print(IsLock)
            # print(total_no_Days_in_month)
        except AttendanceLock.DoesNotExist:
            IsLock = None
            messages.error(request,f'Attendance is not Locked for {EmpName}')
            return redirect(reverse('Employees_Payroll_List')+f'?year={year}&month_no={month_no}')
        
            # return redirect(reverse('Daily_Attendace') + f'?Q_Date={Q_Date}') 
        
       
         
        no_of_days = int(att_lock.PaiDays)
        print(no_of_days)
        no_of_absent = total_no_Days_in_month - no_of_days

        Earned_Basic = int(((fixed_basic / total_no_Days_in_month) * no_of_days))

        Earned_HRA = int(((fixed_HRA / total_no_Days_in_month) * no_of_days))
        
        Front_Total_Earning = Earned_Basic + Earned_HRA
        
        if gross_salary > 21000:
            ESIC = 0
        else:    
            ESIC = int(((Front_Total_Earning/100)*0.75))
        
        if fixed_basic > 15000:
            EPFO = 1800
        else:
            EPFO =  int(((Earned_Basic/100)*12))

        Deduction = EPFO + ESIC + PT + Meals + Accommodation
        
        Front_Net_salary = int((Front_Total_Earning - Deduction))
        

        
        Front_Total_Deduction = int(Deduction)
      
        Earned_Total_Allowance  =  Conveyance_Allowance + CCA + Other_Allowance
        
        Total_Earning  =  Front_Total_Earning + Earned_Total_Allowance
        Net_salary = Front_Net_salary + Earned_Total_Allowance
        

        grid_data =  {
            'gross_salary':gross_salary,
            'total_no_Days_in_month':total_no_Days_in_month,
            'no_of_days':no_of_days,
            'no_of_absent':no_of_absent,
            'Total_Earning':'{:.1f}'.format(Total_Earning),
            'Earned_Basic':'{:.1f}'.format(Earned_Basic),
            'Earned_HRA':'{:.1f}'.format(Earned_HRA),
            'Earned_Total_Allowance':'{:.1f}'.format(Earned_Total_Allowance),

            'ESIC':'{:.1f}'.format(ESIC),
            'EPFO':'{:.1f}'.format(EPFO),
            'Total_Deduction':'{:.1f}'.format(Front_Total_Deduction),
            'Net_salary':'{:.1f}'.format(Net_salary),
             
        


        }
        Leave_Balance = Emp_Leave_Balance_Master.objects.filter(OrganizationID=OrganizationID,IsDelete =False,Emp_code=EmployeeCode)
        with transaction.atomic():
            if request.method == "POST":
                G_employee_code = request.POST['G_employee_code']
                G_month = request.POST['G_month']
                G_year = request.POST['G_year']
                PayMode = request.POST['PayMode']


                Arrear = request.POST['Arrear'] or 0
                RewardIncentive	 =   request.POST['RewardIncentive'] or 0
                print("Earned_Total_Allowance",Earned_Total_Allowance)
                #Earned_Total_Allowance = request.POST['RewardIncentive'] or 0

                AdvanceLoan	=  request.POST['AdvanceLoan'] or 0
                TaxDeduction	=   request.POST['TaxDeduction'] or 0
                OtherDeduction	=    request.POST['OtherDeduction'] or 0 
                
                Total_Earning =   request.POST['TotalEarnings'] or 0
                Total_Deduction =  request.POST['Total_Deduction'] or 0
                Net_salary = float(request.POST['NetPay'] or 0)
                Net_salary_In_Words = number_to_words(int(Net_salary))

                FrontESIC =  request.POST['ESIC'] or 0
                                                            


                


                attendance_data = Attendance_Data.objects.filter(EmployeeCode=G_employee_code, Date__month=G_month, Date__year=G_year,   
                                                                 OrganizationID = OrganizationID,
                                                                 IsDelete = False,)
            
                try:
                    salary_slip = SalarySlip.objects.get(EmployeeCode=G_employee_code, month=G_month, year=G_year,generated = True,
                                                            OrganizationID = OrganizationID,
                                                            IsDelete = False,
                                                         )
                    messages.success(request,f"Salary slip is already  created of {EmpName}")

                except SalarySlip.DoesNotExist:    
                   
                     salary_slip = SalarySlip.objects.create(
                                                            EmployeeCode = G_employee_code, 
                                                            Emp_Name = EmpName ,
                                                            
                                                            month =  G_month,
                                                            year =  G_year,
                                                            month_name = month_name, 
                                                            
                                                            generated = True ,
                                                            
                                                            Desingation =  emp_Details[0]['Designation'],
                                                            Department =  emp_Details[0]['Department'],
                                                            DOJ =  emp_Details[0]['DateofJoiningDate'],
                                                            DOB =  formatted_date_DOB,
                                                            
                                                            total_no_Days_in_month = total_no_Days_in_month,  
                                                            no_of_days =   no_of_days,
                                                            no_of_absent = no_of_absent,
                                                            
                                                            fixed_basic =   fixed_basic,
                                                            fixed_HRA =  fixed_HRA,
                                                            ConveyanceAllowance = Conveyance_Allowance,
                                                            CCA	 = CCA,
                                                            OtherAllowance = Other_Allowance,
                                                            gross_salary =   gross_salary,
                                                            
                                                            
                                                            Earned_Basic =   Earned_Basic,
                                                            Earned_HRA =   Earned_HRA,
                                                            Arrear = Arrear  ,
                                                            RewardIncentive	 =  RewardIncentive,
                                                            Earned_Total_Allowance =  Earned_Total_Allowance,    
                                                            
                                                            ESIC =   FrontESIC,
                                                            EPFO =   EPFO,
                                                            PT	= PT,
                                                            Meals	= Meals,
                                                            Accommodation	= Accommodation,
                                                            AdvanceLoan	= AdvanceLoan,
                                                            TaxDeduction	= TaxDeduction,
                                                            OtherDeduction	= OtherDeduction,


                                                            EmployeePF = 	EmployeePF,
                                                            CompanyContributionToESIC =	CompanyContributionToESIC,
                                                            TotalCompanyContribution =	TotalCompanyContribution,
                                                            CTC = gross_salary + TotalCompanyContribution, 

                                                            
                                                            Total_Earning =   Total_Earning,
                                                            Total_Deduction =  Total_Deduction,
                                                            Net_salary =   Net_salary,
                                                            Net_salary_In_Words =   Net_salary_In_Words,
                                                            
                                                            ProvidentFundNumber =emp_Details[0]['ProvidentFundNumber'],
                                                            ESINumber =emp_Details[0]['ESINumber'],
                                                            BankAccountNumber = emp_Details[0]['BankAccountNumber'],
                                                            PayMode =  PayMode,
                                                            BankName  =  BankName,
                                                            BankIFSCCode = BankIFSCCode,
                                                            BankBranch =  BankBranch,
                                                            
                                                            


                                                            OrganizationID =  OrganizationID,
                                                            CreatedBy =  UserID,



                                                                        )
            
                messages.success(request,f"Salary slip is created for {EmpName}")
                
                return redirect(reverse('Employees_Payroll_List') + f'?year={G_year}&month_no={G_month}')
    else:
        messages.success(request,f"Salary details  of {EmpName} is not present")
            
        return redirect('Employees_Payroll_List')   
    context = {'sal_obj':sal_obj,'org_Details':org_Details,'emp_sal_Det':emp_sal_Det,'emp_Details':emp_Details,'month_no':month_no,'month':month_name,'year':year,'grid_data':grid_data,'Leave_Balance':Leave_Balance, 
              'attendance_data':Attendance,'IsLock':IsLock
               }
    return render(request, "EMP_PAY/Salary/View_Emmployee_Salary_Details.html", context)






import locale
@transaction.atomic
def Generate_Salary_Slip(request):
    if 'OrganizationID' not in request.session:
        return redirect(MasterAttribute.Host)
    else:
        print("Show Page Session")
   
    OrganizationID = request.session["OrganizationID"]
    UserID = str(request.session["UserID"])
    org_Details  =  OrganizationMaster.objects.get(OrganizationID= OrganizationID)
    
    hotelapitoken = MasterAttribute.HotelAPIkeyToken
    headers = {
    'hotel-api-token': hotelapitoken  
    }
    
    org_url = f"http://hotelops.in/API/PyAPI/OrganizationListSelect?OrganizationID={OrganizationID}"

    try:
        response = requests.get(org_url, headers=headers)
        response.raise_for_status()  
        memOrg = response.json()
    except requests.exceptions.RequestException as e:
        print(f"Error occurred: {e}")
     
    
    
    with transaction.atomic():
        Hr = request.GET.get('HR')
        if Hr:
            EmployeeCode = request.GET.get('Emp')
            
            api_ur = "http://hotelops.in/api/PyAPI/HREmployeeDataEmpCodeSelect?EmpCode="+str(EmployeeCode)+"&OID="+str(OrganizationID)

            try:
                response = requests.get(api_ur, headers=headers)
                response.raise_for_status()  
                emp_Details = response.json()
            
            except requests.exceptions.RequestException as e:
                print(f"Error occurred: {e}")
            
            emp_name = emp_Details[0]['EmpName']        
        else:
            EmployeeCode = request.session["EmployeeCode"]
            api_ur = "http://hotelops.in/api/PyAPI/HREmployeeDataEmpCodeSelect?EmpCode="+str(EmployeeCode)+"&OID="+str(OrganizationID)

            try:
                response = requests.get(api_ur, headers=headers)
                response.raise_for_status()  
                emp_Details = response.json()
            
            except requests.exceptions.RequestException as e:
                print(f"Error occurred: {e}")

            
        
        
        year = request.GET.get('year')
        month_no =  request.GET.get('month_no')
        month_name = calendar.month_name[int(month_no)]
        
        try:

            salary = SalarySlip.objects.get(OrganizationID=OrganizationID,IsDelete=False,
                                        EmployeeCode = EmployeeCode,month=month_no ,year =year,
                                        generated = True,
                                        HrVerify = True,
                                        FcVerify =  True
                                        )
           
           
            locale.setlocale(locale.LC_NUMERIC, 'en_IN')
   
          
            fixed_basic = locale.format_string("%.2f", float(salary.fixed_basic), grouping=True)
            fixed_HRA = locale.format_string("%.2f", float(salary.fixed_HRA), grouping=True)
            ConveyanceAllowance = locale.format_string("%.2f", float(salary.ConveyanceAllowance), grouping=True)
            CCA = locale.format_string("%.2f", float(salary.CCA), grouping=True)
            OtherAllowance = locale.format_string("%.2f", float(salary.OtherAllowance), grouping=True)
            gross_salary = locale.format_string("%.2f", float(salary.gross_salary), grouping=True)

            Earned_Basic = locale.format_string("%.2f", float(salary.Earned_Basic), grouping=True)
            Earned_HRA = locale.format_string("%.2f", float(salary.Earned_HRA), grouping=True)
            Arrear = locale.format_string("%.2f", float(salary.Arrear), grouping=True)
            RewardIncentive = locale.format_string("%.2f", float(salary.RewardIncentive), grouping=True)
            Total_Deduction = locale.format_string("%.2f", float(salary.Total_Deduction), grouping=True)
            Net_salary = locale.format_string("%.2f", float(salary.Net_salary), grouping=True)
            
            Total_Earning = locale.format_string("%.2f", float(salary.Total_Earning), grouping=True)



            ESIC = locale.format_string("%.2f", float(salary.ESIC), grouping=True)
            EPFO = locale.format_string("%.2f", float(salary.EPFO), grouping=True)
            PT = locale.format_string("%.2f", float(salary.PT), grouping=True)
            Meals = locale.format_string("%.2f", float(salary.Meals), grouping=True)
            Accommodation = locale.format_string("%.2f", float(salary.Accommodation), grouping=True)
            AdvanceLoan = locale.format_string("%.2f", float(salary.AdvanceLoan), grouping=True)
            TaxDeduction = locale.format_string("%.2f", float(salary.TaxDeduction), grouping=True)
            OtherDeduction = locale.format_string("%.2f", float(salary.OtherDeduction), grouping=True)
            Total_Deduction = locale.format_string("%.2f", float(salary.Total_Deduction), grouping=True)
            if salary.Earned_Total_Allowance is not None:
                Earned_Total_Allowance = locale.format_string("%.2f", float(salary.Earned_Total_Allowance), grouping=True)
            else:
                Earned_Total_Allowance = "0.00" 

            formatted = {
                    'fixed_basic' : fixed_basic ,
                    'fixed_HRA' : fixed_HRA ,
                    'ConveyanceAllowance' : ConveyanceAllowance,
                     'CCA' : CCA,
                    'OtherAllowance' : OtherAllowance,
                    'gross_salary' : gross_salary,
                    'Earned_Basic' : Earned_Basic,
                    'Earned_HRA' : Earned_HRA,
                    'Arrear' :  Arrear,
                    'RewardIncentive' :  RewardIncentive,
                    'Total_Deduction' :  Total_Deduction,
                    'Net_salary' :  Net_salary,
                    'ESIC' :  ESIC,
                    'EPFO' : EPFO,
                    'PT' : PT,
                    'Meals' : Meals ,
                    'Accommodation' : Accommodation ,
                    'AdvanceLoan' : AdvanceLoan,
                    'TaxDeduction' : TaxDeduction ,
                    'OtherDeduction' : OtherDeduction ,
                    'Total_Deduction' :  Total_Deduction,
                    'Total_Earning':Total_Earning,
                    'Earned_Total_Allowance':Earned_Total_Allowance

            }

          


            

            


            

             
        except SalarySlip.DoesNotExist:
            if Hr:
                messages.warning(request,f"No Salary Slip is present for {month_name} of {emp_name}")
                return redirect('Employees_Payroll_List')
            else:

                messages.warning(request,f"No Salary Slip is present for {month_name}")
            return redirect('Payroll_List')

    
        
        
        Leave_Balance = Emp_Leave_Balance_Master.objects.filter(OrganizationID=OrganizationID,IsDelete =False,Emp_code=EmployeeCode)
        template_path = "EMP_PAY/Salary/Generate_Salary_Slip.html"
        mydict = {'month':month_name,'year':year,'formatted' :formatted
                ,'salary':salary,'org_Details':org_Details,'Leave_Balance':Leave_Balance} 

        response = HttpResponse(content_type='application/pdf')
        response['Content-Disposition'] = 'filename="padp.pdf"'
        
        template = get_template(template_path)
        html = template.render(mydict)

        result = BytesIO()
        pdf = pisa.pisaDocument(BytesIO(html.encode("ISO-8859-1")), result)
        
        if not pdf.err:
            return HttpResponse(result.getvalue(), content_type='application/pdf')
        return None






def Generate_Salary_Slip_Emails(OrganizationID,UserID,EmployeeCode,year,month_no):
    # if 'OrganizationID' not in request.session:
    #     return redirect(MasterAttribute.Host)
    # else:
    #     print("Show Page Session")
   
    # OrganizationID = request.session["OrganizationID"]
    # UserID = str(request.session["UserID"])
    org_Details  =  OrganizationMaster.objects.get(OrganizationID= OrganizationID)
    
    hotelapitoken = MasterAttribute.HotelAPIkeyToken
    headers = {
    'hotel-api-token': hotelapitoken  
    }
    
    org_url = f"http://hotelops.in/API/PyAPI/OrganizationListSelect?OrganizationID={OrganizationID}"

    try:
        response = requests.get(org_url, headers=headers)
        response.raise_for_status()  
        memOrg = response.json()
    except requests.exceptions.RequestException as e:
        print(f"Error occurred: {e}")
     
    
    
    print(OrganizationID,UserID,EmployeeCode,year,month_no)
    
    with transaction.atomic():
            
        
            api_ur = "http://hotelops.in/api/PyAPI/HREmployeeDataEmpCodeSelect?EmpCode="+str(EmployeeCode)+"&OID="+str(OrganizationID)

            try:
                response = requests.get(api_ur, headers=headers)
                response.raise_for_status()  
                emp_Details = response.json()
            
            except requests.exceptions.RequestException as e:
                print(f"Error occurred: {e}")
                
            emp_name = emp_Details[0]['EmpName']        
            
                
            
            
            
            month_name = calendar.month_name[int(month_no)]
            
            try:

                salary = SalarySlip.objects.get(OrganizationID=OrganizationID,IsDelete=False,
                                            EmployeeCode = EmployeeCode,month=month_no ,year = year,
                                              generated = True,
                                            HrVerify = True,    
                                            FcVerify =  True
                                            )
                
                locale.setlocale(locale.LC_NUMERIC, 'en_IN')
   
          
                fixed_basic = locale.format_string("%.2f", float(salary.fixed_basic), grouping=True)
                fixed_HRA = locale.format_string("%.2f", float(salary.fixed_HRA), grouping=True)
                ConveyanceAllowance = locale.format_string("%.2f", float(salary.ConveyanceAllowance), grouping=True)
                CCA = locale.format_string("%.2f", float(salary.CCA), grouping=True)
                OtherAllowance = locale.format_string("%.2f", float(salary.OtherAllowance), grouping=True)
                gross_salary = locale.format_string("%.2f", float(salary.gross_salary), grouping=True)

                Earned_Basic = locale.format_string("%.2f", float(salary.Earned_Basic), grouping=True)
                Earned_HRA = locale.format_string("%.2f", float(salary.Earned_HRA), grouping=True)
                Arrear = locale.format_string("%.2f", float(salary.Arrear), grouping=True)
                RewardIncentive = locale.format_string("%.2f", float(salary.RewardIncentive), grouping=True)
                Total_Deduction = locale.format_string("%.2f", float(salary.Total_Deduction), grouping=True)
                Net_salary = locale.format_string("%.2f", float(salary.Net_salary), grouping=True)
                
                Total_Earning = locale.format_string("%.2f", float(salary.Total_Earning), grouping=True)



                ESIC = locale.format_string("%.2f", float(salary.ESIC), grouping=True)
                EPFO = locale.format_string("%.2f", float(salary.EPFO), grouping=True)
                PT = locale.format_string("%.2f", float(salary.PT), grouping=True)
                Meals = locale.format_string("%.2f", float(salary.Meals), grouping=True)
                Accommodation = locale.format_string("%.2f", float(salary.Accommodation), grouping=True)
                AdvanceLoan = locale.format_string("%.2f", float(salary.AdvanceLoan), grouping=True)
                TaxDeduction = locale.format_string("%.2f", float(salary.TaxDeduction), grouping=True)
                OtherDeduction = locale.format_string("%.2f", float(salary.OtherDeduction), grouping=True)
                Total_Deduction = locale.format_string("%.2f", float(salary.Total_Deduction), grouping=True)

                formatted = {
                        'fixed_basic' : fixed_basic ,
                        'fixed_HRA' : fixed_HRA ,
                        'ConveyanceAllowance' : ConveyanceAllowance,
                        'CCA' : CCA,
                        'OtherAllowance' : OtherAllowance,
                        'gross_salary' : gross_salary,
                        'Earned_Basic' : Earned_Basic,
                        'Earned_HRA' : Earned_HRA,
                        'Arrear' :  Arrear,
                        'RewardIncentive' :  RewardIncentive,
                        'Total_Deduction' :  Total_Deduction,
                        'Net_salary' :  Net_salary,
                        'ESIC' :  ESIC,
                        'EPFO' : EPFO,
                        'PT' : PT,
                        'Meals' : Meals ,
                        'Accommodation' : Accommodation ,
                        'AdvanceLoan' : AdvanceLoan,
                        'TaxDeduction' : TaxDeduction ,
                        'OtherDeduction' : OtherDeduction ,
                        'Total_Deduction' :  Total_Deduction,
                        'Total_Earning':Total_Earning

                }
                Leave_Balance = Emp_Leave_Balance_Master.objects.filter(OrganizationID=OrganizationID,IsDelete =False,Emp_code=EmployeeCode)
                template_path = "EMP_PAY/Salary/Generate_Salary_Slip.html"
                
                
                
                mydict = {'month':month_name,'year':year
                        ,'salary':salary,'org_Details':org_Details,'Leave_Balance':Leave_Balance,'formatted':formatted} 

                response = HttpResponse(content_type='application/pdf')
                response['Content-Disposition'] = 'filename="padp.pdf"'
                
                template = get_template(template_path)
                html = template.render(mydict)

                result = BytesIO()
                pdf = pisa.pisaDocument(BytesIO(html.encode("ISO-8859-1")), result)
                
                if not pdf.err:
                    return result.getvalue()  
                return None
                
            except SalarySlip.DoesNotExist:
                
                ErrorMessage = f"No Salary Slip is present for {month_name}"
                ErrorPage = "Generate_Salary_Slip_Emails"
                ErrorFucntion =  "Generate_Salary_Slip_Emails()"
                errorlog = PayrollErrorLog.objects.create(OrganizationID = OrganizationID,ErrorMessage = ErrorMessage,ErrorPage  = ErrorPage, ErrorFucntion = ErrorFucntion,CreatedBy= UserID)
            

        
            
            




from django.core.mail import EmailMessage
from django.template.loader import render_to_string
from django.conf import settings
def SalarySendEmails(request):
    if 'OrganizationID' not in request.session:
        return redirect(MasterAttribute.Host)
    else:
        print("Show Page Session")
   
    OrganizationID = request.session["OrganizationID"]
    UserID = str(request.session["UserID"])
    hotelapitoken = MasterAttribute.HotelAPIkeyToken
    headers = {
        'hotel-api-token': hotelapitoken  
    }
    api_url = "http://hotelops.in/API/PyAPI/HREmployeeList?OrganizationID="+str(OrganizationID)
    

    try:
        response = requests.get(api_url, headers=headers)
        response.raise_for_status() 
        emp_list = response.json()
     
    except requests.exceptions.RequestException as e:
        print(f"Error occurred: {e}")
    
    if request.method == "POST":
            year = request.POST.get('year')
            month_no =  request.POST.get('month_no')
            
            month_name = calendar.month_name[int(month_no)]
            for emp in emp_list:
            
                EmployeeCode = emp['EmployeeCode']
                # Remove if when live
                if  EmployeeCode  == '451000245':
                        emp_data_url  = "http://hotelops.in/api/PyAPI/HREmployeeDataEmpCodeSelect?EmpCode="+str(EmployeeCode)+"&OID="+str(OrganizationID)

                        try:
                            response = requests.get(emp_data_url, headers=headers)
                            response.raise_for_status()  
                            emp_Details = response.json()
                        
                        except requests.exceptions.RequestException as e:
                            print(f"Error occurred: {e}")
                        
                        emp_name = emp_Details[0]['EmpName']
                        # emp_email  = emp_Details[0]['EmailAddress']
                        # update when live
                        emp_email = ["darpananjanaynilehospitality@gmail.com" ]
                    
                        pdf_content = Generate_Salary_Slip_Emails(OrganizationID,UserID, EmployeeCode, year, month_no)
                      
                        subject =  f'Salary Slip of {month_name},{year}'
                        message = f'Dear {emp_name} Please Find attachement of your salary slip of {month_name},{year}'

                        try:
                            if pdf_content:
                                email = EmailMessage(subject, message, settings.EMAIL_HOST_USER, emp_email)
                                email.content_subtype = "html"
                                email.attach('attachment.pdf', pdf_content, 'application/pdf')
                                email.send()
                                email_obj = SalaryEmails.objects.create(OrganizationID = OrganizationID,CreatedBy =  UserID,
                                                                        EmpCode = EmployeeCode,
                                                                        email = emp_email)  
                        except requests.exceptions.RequestException as e:
                                        
                        
                                ErrorMessage = f"Error while sending Email {e}"
                                ErrorPage = "SendEmails"
                                ErrorFucntion =  "SendEmails()"
                                errorlog = PayrollErrorLog.objects.create(OrganizationID = OrganizationID,ErrorMessage = ErrorMessage,ErrorPage  = ErrorPage, ErrorFucntion = ErrorFucntion,CreatedBy =  UserID)
                    
                        messages.success(request,'Sended Successfully')        
                        return redirect('SalarySendEmails')


       
    today = datetime.today()
    CYear = today.year
    CMonth = today.month

    context = {'CYear':range(CYear,2020,-1),'CMonth':CMonth}
    return render(request, "EMP_PAY/Email/SalarySendEmails.html", context)
    


def number_to_words(number):
  
    units = ['Zero', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine',
             'Ten', 'Eleven', 'Twelve', 'Thirteen', 'Fourteen', 'Fifteen', 'Sixteen', 'Seventeen', 'Eighteen', 'Nineteen']
    
    tens = ['', '', 'Twenty', 'Thirty', 'Forty', 'Fifty', 'Sixty', 'Seventy', 'Eighty', 'Ninety']
    
   
    powers_of_ten = ['', 'Thousand', 'Million', 'Billion', 'Trillion', 'Quadrillion', 'Quintillion']

    
    def less_than_thousand(num):
        if num == 0:
            return ''
        elif num < 20:
            return units[num]
        elif num < 100:
            return tens[num // 10] + ('' if num % 10 == 0 else ' ' + units[num % 10])
        else:
            return units[num // 100] + ' Hundred' + ('' if num % 100 == 0 else ' and ' + less_than_thousand(num % 100))

   
    def convert_to_words(num):
        if num == 0:
            return 'Zero'
        words = ''
        for i in range(len(powers_of_ten)):
            if num % 1000 != 0:
                words = less_than_thousand(num % 1000) + ' ' + powers_of_ten[i] + ' ' + words
            num //= 1000
        return words.strip()

    return convert_to_words(number)


# Salary List of Employees
def SalaryList(request):
    if 'OrganizationID' not in request.session:
        return redirect(MasterAttribute.Host)
    else:
        print("Show Page Session")
     
    OrganizationID = request.session["OrganizationID"]
    UserID = str(request.session["UserID"])
    UserType =   request.session["UserType"]
    Department_Name = request.session["Department_Name"]

   

    hotelapitoken = MasterAttribute.HotelAPIkeyToken
    headers = {
        'hotel-api-token': hotelapitoken  # Replace with your actual header key and value
    }
    api_url = "http://hotelops.in/API/PyAPI/OrganizationListSelect?OrganizationID=" + str(OrganizationID)

    try:
        response = requests.get(api_url, headers=headers)
        response.raise_for_status()  # Optional: Check for any HTTP errors
        memOrg = response.json()
    except requests.exceptions.RequestException as e:
        print(f"Error occurred: {e}")   

    
    
    
    I = request.GET.get('I',OrganizationID)
    
    # year = request.GET.get('year')
    # month_no =  request.GET.get('month_no')
    year = request.GET.get('year')
    if year:
        year = int(year)
    else:
        year = datetime.now().year
    month_no =  request.GET.get('month_no')
    if month_no:
        month_no = int(month_no)
    else:
        month_no = datetime.now().month  
    month_name = calendar.month_name[int(month_no)]    
    # StartDate = datetime(year, month_no, 1)

    # next_month = StartDate.replace(day=28) + timedelta(days=4)  
    # EndDate = next_month - timedelta(days=next_month.day)
    PayMode =request.GET.get('PayMode','')
    Status = request.GET.get('Status',0)

    

    if Status is None:
        VerifyStatus = None
    elif Status == '2':
        VerifyStatus = None  
    else:
        VerifyStatus = bool(int(Status))  
    
    
    
    
    if I == '':
        I= OrganizationID
    
   
    


   
    sal_list = SalarySlip.objects.filter(
        OrganizationID=I,
        IsDelete=False,
        month=month_no,
        year=year,
        generated=True
    ).order_by('EmployeeCode')

  
    if UserType.lower() == "hod":
        if Department_Name.lower() == "hr":
            if VerifyStatus == None:
                sal_list = sal_list
            else:
                sal_list = sal_list.filter(HrVerify=VerifyStatus)

        elif Department_Name.lower() == "finance":
                if VerifyStatus == None:
                    sal_list = sal_list.filter(HrVerify=True)
                    
                else:    
           
                    sal_list = sal_list.filter(FcVerify=VerifyStatus,HrVerify=True)

  
   
    

   
    if PayMode:
        sal_list = sal_list.filter(PayMode=PayMode)
        

        
    today = datetime.today()
    CYear = today.year
    CMonth = today.month

    context = {'sal_list':sal_list,'I':I,'memOrg':memOrg,'PayMode':PayMode,
                'CYear':range(CYear,2020,-1),'CMonth':CMonth,
                'month_no':month_no,
                'month_name':month_name,
                'year':year,
                'Status':str(Status)
             
               
               }
    return render(request,"EMP_PAY/Salary/SalaryList.html", context)





# Update status 
from django.http import JsonResponse

def update_verification(request):
    if 'OrganizationID' not in request.session:
        return redirect(MasterAttribute.Host)
    else:
        print("Show Page Session")
     
    OrganizationID = request.session["OrganizationID"]
    UserID = str(request.session["UserID"])
    if request.method == 'POST':
        employee_code = request.POST.get('employee_code')
        verify_type = request.POST.get('verify_type')  
        
     
     
     

        try:
            salary_slip = SalarySlip.objects.get(EmployeeCode=employee_code,
                                                 OrganizationID = OrganizationID,
                                                            IsDelete = False,
                                                 )
            if verify_type == 'Verify HR':
                salary_slip.HrVerify = True
            elif verify_type == 'Verify FC':
                salary_slip.FcVerify = True

       
           
           
            salary_slip.ModifyBy = UserID
            
            salary_slip.save()
            return JsonResponse({'message': 'Verification updated successfully.'})
        except SalarySlip.DoesNotExist:
            return JsonResponse({'error': 'Salary slip not found.'}, status=404)
    
    return JsonResponse({'error': 'Invalid request.'}, status=400)
# organization Config
def OrgConfigList(request):
    if 'OrganizationID' not in request.session:
        return redirect(MasterAttribute.Host)
    else:
        print("Show Page Session")
     
    OrganizationID = request.session["OrganizationID"]
    UserID = str(request.session["UserID"])
    hotelapitoken = MasterAttribute.HotelAPIkeyToken
    headers = {
        'hotel-api-token': hotelapitoken  # Replace with your actual header key and value
    }
    api_url = "http://hotelops.in/API/PyAPI/OrganizationListSelect?OrganizationID=" + str(OrganizationID)

    try:
        response = requests.get(api_url, headers=headers)
        response.raise_for_status()  # Optional: Check for any HTTP errors
        memOrg = response.json()
    except requests.exceptions.RequestException as e:
        print(f"Error occurred: {e}")   
    I = request.GET.get('I',OrganizationID)
    if I == '':
        I= OrganizationID

    
 
    orgconfig = Organization_Details.objects.filter(OID = I,IsDelete = False)
    
    context = {'orgconfig':orgconfig,'I':I,'memOrg':memOrg,'OrganizationID':OrganizationID}
    return render(request, "EMP_PAY/OrgConfig/OrgConfigList.html", context)


from pathlib import Path   
from django.urls import reverse
@transaction.atomic
def AddConfig(request):
    if 'OrganizationID' not in request.session:
        return redirect(MasterAttribute.Host)
    else:
        print("Show Page Session")
    
    OrganizationID = request.session["OrganizationID"]
    
    UserID = str(request.session["UserID"])
    hotelapitoken = MasterAttribute.HotelAPIkeyToken
    headers = {
        'hotel-api-token': hotelapitoken  # Replace with your actual header key and value
    }
    api_url = "http://hotelops.in/API/PyAPI/OrganizationListSelect?OrganizationID=" + str(OrganizationID)

    try:
        response = requests.get(api_url, headers=headers)
        response.raise_for_status()  # Optional: Check for any HTTP errors
        memOrg = response.json()
    except requests.exceptions.RequestException as e:
        print(f"Error occurred: {e}")  
    ID  = request.GET.get('ID')
    config = None
    if ID is not None:
        config = get_object_or_404(Organization_Details,id=ID,IsDelete=False)

    with transaction.atomic():
        if request.method == "POST":
             if ID is not None:

                OID_Code =   request.POST['OID_Code']
                OID =  request.POST['OID']
                I = OID
                
                UploadFormatType = request.POST['UploadFormatType']
                DownloadFormat = request.FILES.get('DownloadFormat')
                EndDate =request.POST['EndDate']
                
               
                

                config.OID_Code =   OID_Code
                config.OID =  OID
                config.OrgUrl = request.POST['OrgUrl']
                config.cid = request.POST['cid']
                
                config.UploadFormatType = UploadFormatType



                UploadFile = DownloadFormat
                
                if UploadFile is None:
                    previous = config.DownloadFormat
                    if previous:
                        UploadFile = config.DownloadFormat.url
                        print(UploadFile)

                
                if DownloadFormat is not None:
                    if UploadFormatType != "." +Path(UploadFile).suffix.lower()[1:]:
                        messages.warning(request,f'Selected Type is not macthed with upload format')
                        
                        return redirect(reverse('AddConfig') + f'?ID={config.id}') 
                
                config.DownloadFormat = UploadFile
                config.EndDate =request.POST['EndDate']
                
                config.ModifyBy = UserID
                config.save()
                messages.success(request,"Updated Succesfully")
                 
             else:
                  
                OID_Code =   request.POST['OID_Code']
                OrgUrl = request.POST['OrgUrl']
                OID =  request.POST['OID']
                cid = request.POST['cid']
                I = OID
                UploadFormatType = request.POST['UploadFormatType']
                DownloadFormat = request.FILES.get('DownloadFormat')
                EndDate =request.POST['EndDate']
                
                if DownloadFormat is not None:
                    if UploadFormatType != "." +Path(DownloadFormat.name).suffix.lower()[1:]:
                        messages.warning(request,f'Selected Type is not macthed with upload format')
                        return redirect('AddConfig')
                try:
                     orgcon = Organization_Details.objects.get(OID=OID)

                     messages.warning(request,"Data is present for Selected Organization")
                except Organization_Details.DoesNotExist:
                        orgcon = Organization_Details.objects.create(
                            OID_Code =  OID_Code,
                            OID = OID,
                            OrgUrl = OrgUrl,
                            cid = cid,
                
                            UploadFormatType = UploadFormatType,
                            DownloadFormat = DownloadFormat,
                            EndDate = EndDate,
                            
                            OrganizationID = OrganizationID,
                            CreatedBy = UserID
                        )
                        messages.success(request,"Added Succesfully")
             
             return redirect(reverse('OrgConfigList') + f'?I={I}')    

    
    

    context = {'config':config,'memOrg':memOrg}
    return render(request, "EMP_PAY/OrgConfig/AddConfig.html", context)
    


@transaction.atomic
def ConfigDelete(request):
    if 'OrganizationID' not in request.session:
        return redirect(MasterAttribute.Host)
    else:
        print("Show Page Session")
     
    OrganizationID = request.session["OrganizationID"]
    UserID = str(request.session["UserID"])
    id = request.GET.get('ID')
    obj = Organization_Details.objects.get(id=id,IsDelete=False,OrganizationID = OrganizationID )
    with transaction.atomic():
       obj.IsDelete = True
       obj.ModifyBy = UserID
       I = obj.OID
       obj.save()
    return redirect(reverse('OrgConfigList') + f'?I={I}') 







# Employee weekoff Mapping


from django.shortcuts import render, redirect
from django.http import JsonResponse
import requests
from datetime import datetime
from .models import WeekOffDetails
from hotelopsmgmtpy.GlobalConfig import  MasterAttribute
from pprint import pprint

import requests
from django.shortcuts import render, redirect

def index(request):
    if 'OrganizationID' not in request.session:
        return redirect('MasterAttribute.Host')
    else:
        OrganizationID = request.session["OrganizationID"]
    
    UserID = str(request.session["UserID"])
    EmployeeCode = request.session["EmployeeCode"]
    Department_Name  =  request.session["Department_Name"]
    
    hotelapitoken = MasterAttribute.HotelAPIkeyToken  
    headers = {
        'hotel-api-token': hotelapitoken
    }
    
   
                
    Approval_url = "http://hotelops.in/API/PyAPI/HREmployeeListForApproval?UserID="+str(UserID)
    
    try:
        response = requests.get(Approval_url, headers=headers)
        response.raise_for_status()
        emp_list = response.json()
        emp_list.sort(key=lambda emp: emp.get('FirstName', '').lower()) 
    except requests.exceptions.RequestException as e:
        print(f"Error fetching approval list: {e}")
                
                
    today = datetime.today()
    CYear = today.year
    CMonth = today.month            
    context = {'emp_list': emp_list,'CYear':range(CYear,2020,-1),'CMonth':CMonth}
    return render(request, 'EMP_PAY/Weekoff/index.html', context)



from django.http import JsonResponse
import requests
from django.shortcuts import redirect




def all_events(request):
    if 'OrganizationID' not in request.session:
        return redirect('MasterAttribute.Host')
    
    OrganizationID = request.session["OrganizationID"]
    
    Department_Name  =  request.session["Department_Name"]
    UserID = str(request.session["UserID"])
    hotelapitoken = MasterAttribute.HotelAPIkeyToken
    headers = {
        'hotel-api-token': hotelapitoken
    }
    EmployeeSelect = request.GET.get('EmployeeSelect') or 'All'
    
    
    Approval_url = "http://hotelops.in/API/PyAPI/HREmployeeListForApproval?UserID="+str(UserID)
    
    try:
        response = requests.get(Approval_url, headers=headers)
        response.raise_for_status()
        emplist = response.json()
    except requests.exceptions.RequestException as e:
        print(f"Error fetching approval list: {e}")

    Emp_Codelist = []                
    for emp in emplist:
        
        Emp_Codelist.append(emp['EmployeeCode'])

    EmployeeDetails = []
    for emp in emplist:
           
            employee_dict = {
            "EmployeeCode": emp['EmployeeCode'],
            "EmployeeName": emp['FirstName'] + " " + emp['LastName'] 
            }
            EmployeeDetails.append(employee_dict)

        
    
    
    if not emplist:
        return JsonResponse({'error': 'No employee data found'}, status=404)
    
    
    
    if EmployeeSelect == "All":   
            all_events = WeekOffDetails.objects.filter(OrganizationID=OrganizationID, IsDelete=False, Emp_Code__in = Emp_Codelist).order_by('Emp_Code')
    else:
            all_events = WeekOffDetails.objects.filter(OrganizationID=OrganizationID, IsDelete=False, Emp_Code__in = Emp_Codelist,
                                                    Emp_Code = EmployeeSelect).order_by('Emp_Code')

    event_list = []
    
    for event in all_events:
        employee_name = next((emp['EmployeeName'] for emp in EmployeeDetails if emp['EmployeeCode'] == event.Emp_Code), '')

        event_dict = {
            'title':   employee_name   ,
            'start': event.WeekoffDate.strftime('%Y-%m-%d'),
            'end': event.WeekoffDate.strftime('%Y-%m-%d'),
            'empcode': event.Emp_Code,
            'id': event.id
        }
        event_list.append(event_dict)

    return JsonResponse(event_list, safe=False)




def add_event(request):
    if 'OrganizationID' not in request.session:
        return redirect(MasterAttribute.Host)
    else:
        OrganizationID = request.session["OrganizationID"]
    UserID = str(request.session["UserID"])
    if request.method == 'GET':
        try:
            emp_code = request.GET.get("empcode", None)
            hotelapitoken = MasterAttribute.HotelAPIkeyToken
            headers = {
                'hotel-api-token': hotelapitoken  
            }
    
            WeekOffDate = request.GET.get("WeekOffDate", None)  
            

            weekoff_id = request.GET.get("id")  
           
            if emp_code and WeekOffDate:
                
                if weekoff_id == "0":
                    existing_event = WeekOffDetails.objects.filter(WeekoffDate=WeekOffDate, OrganizationID=OrganizationID,Emp_Code=emp_code,IsDelete=False).first()
                    if existing_event:
                        return JsonResponse({'error': 'Weekoff details already exist for this employee on selected date'}, status=400)
                  
                    WeekOffDetails.objects.create(Emp_Code=emp_code, WeekoffDate=WeekOffDate, OrganizationID=OrganizationID)
                    objAtt, created = Attendance_Data.objects.update_or_create(
                        Date=WeekOffDate,
                        EmployeeCode=emp_code,
                        OrganizationID=OrganizationID,
                        defaults={
                            'IsDelete': False,  # Fields to update or set
                            # Add other fields you want to update or set here
                            'Status': "Week Off",
                        }
                    )

                    if created:
                        print("A new object was created.")
                    else:
                        print("An existing object was updated.")
                    return JsonResponse({'success': True})
                elif weekoff_id:
                    
                    try:
                        weekoff_id_int = int(weekoff_id)
                    except ValueError:
                        return JsonResponse({'error': 'Invalid weekoff ID provided'}, status=400)
                    
                    weekoff_instance = WeekOffDetails.objects.filter(id=weekoff_id_int, OrganizationID=OrganizationID).first()
                    if not weekoff_instance:
                        return JsonResponse({'error': 'Weekoff entry not found for given ID'}, status=404)
                     
                    
                    weekoff_instance.WeekoffDate = WeekOffDate
                    weekoff_instance.ModifyBy = UserID
                    weekoff_instance.save()
                    objAtt, created = Attendance_Data.objects.update_or_create(
                        Date=WeekOffDate,
                        EmployeeCode=emp_code,
                        OrganizationID=OrganizationID,
                        defaults={
                            'IsDelete': False,  # Fields to update or set
                            # Add other fields you want to update or set here
                            'Status': "Week Off",
                        }
                    )

                    if created:
                        print("A new object was created.")
                    else:
                        print("An existing object was updated.")
                    return JsonResponse({'success': True})
            else:
                return JsonResponse({'error': 'Missing parameters'}, status=400)
        except ValueError:
            return JsonResponse({'error': 'Incorrect date format. Please provide the date in MM/DD/YYYY format.'}, status=400)
        except Exception as e:
            return JsonResponse({'error': str(e)}, status=500)



def remove(request):
    if 'OrganizationID' not in request.session:
        return redirect(MasterAttribute.Host)
    else:
        OrganizationID = request.session["OrganizationID"]
    UserID = str(request.session["UserID"])
    if request.method == 'GET':
        id = request.GET.get("id", None)
        if id:
            obj = WeekOffDetails.objects.get(id=id)
            obj.IsDelete = True
            obj.ModifyBy = UserID
            obj.save()

            return JsonResponse({'success': True})
        else:
            return JsonResponse({'error': 'Missing ID'}, status=400)






import requests
from datetime import datetime, timedelta
from openpyxl import Workbook
from django.http import HttpResponse
import io

def download_weekoff(request):
    if 'OrganizationID' not in request.session:
        return redirect('MasterAttribute.Host')

    OrganizationID = request.session["OrganizationID"]
    
    UserID = str(request.session["UserID"])
    hotelapitoken = MasterAttribute.HotelAPIkeyToken

    headers = {
        'hotel-api-token': hotelapitoken
    }

    Approval_url = f"http://hotelops.in/API/PyAPI/HREmployeeListForApproval?UserID={UserID}"

    try:
        response = requests.get(Approval_url, headers=headers)
        response.raise_for_status()
        emplist = response.json()
    except requests.exceptions.RequestException as e:
        print(f"Error fetching approval list: {e}")
        return HttpResponse("Error fetching approval list.", status=500)

    year = int(request.GET.get('year'))
    month = int(request.GET.get('month'))

    wb = Workbook()
    ws = wb.active
    ws.title = "Weekoffs"
    ws.append(["EmployeeName" ,"Department","EmployeeCode", "WeekoffDate"])

    start_date = datetime(year, month, 1)
    while start_date.weekday() != 6:  
        start_date += timedelta(days=1)

    sundays = []
    while start_date.month == month:
        sundays.append(start_date.strftime("%d-%m-%Y"))
        start_date += timedelta(days=7)

    for emp in emplist:
            employee_name = f"{emp['FirstName']} {emp['MiddleName']} {emp['LastName']}".strip()
            department = emp['Department']
            employee_code = emp['EmployeeCode']
            for sunday in sundays:
                ws.append([employee_name, department, employee_code, sunday])


    output = io.BytesIO()
    wb.save(output)
    output.seek(0)

    response = HttpResponse(output, content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
    response['Content-Disposition'] = f'attachment; filename=Weekoffs_{year}_{month}.xlsx'
    return response


from datetime import datetime
import pandas as pd
from django.http import JsonResponse
from django.shortcuts import redirect
from .models import WeekOffDetails

def upload_weekoff(request):
    if 'OrganizationID' not in request.session:
        print("OrganizationID not found in session.")
        return redirect(MasterAttribute.Host)
    
    OrganizationID = request.session.get("OrganizationID")
    UserID = str(request.session.get("UserID"))
    
    if request.method == 'POST':
        error_messages = []
        try:
            if 'file' not in request.FILES:
                print("File not found in request.")
                return JsonResponse({"error": "File not found in request."})
            
            excel_file = request.FILES['file']
            df = pd.read_excel(excel_file)
            
            for index, row in df.iterrows():
                emp_code = row.get('EmployeeCode')
                weekdate = row.get('WeekoffDate')
                
                if not emp_code or not weekdate:
                    error_message = f"Row {index + 1}: Employee code or week-off date missing."
                    print(error_message)
                    error_messages.append(error_message)
                    continue
                
                try:
                    parsed_date = datetime.strptime(weekdate, '%d-%m-%Y')
                    weekoff_date = parsed_date.strftime('%Y-%m-%d')
                except ValueError as ve:
                    error_message = f"Row {index + 1}: Date format error: {ve}"
                    print(error_message)
                    error_messages.append(error_message)
                    continue
                
                try:
                    existing_event = WeekOffDetails.objects.filter(
                        WeekoffDate=weekoff_date,
                        OrganizationID=OrganizationID,
                        Emp_Code=emp_code,
                        IsDelete=False
                    ).first()
                    
                    if existing_event:
                        error_message = f"Row {index + 1}: Weekoff details already exist for employee {emp_code} on {weekoff_date}."
                        print(error_message)
                        error_messages.append(error_message)
                        continue
                    
                    WeekOffDetails.objects.create(
                        Emp_Code=emp_code,
                        WeekoffDate=weekoff_date,
                        OrganizationID=OrganizationID,
                        CreatedBy=UserID
                    )
                    objAtt, created = Attendance_Data.objects.update_or_create(
                        Date=weekoff_date,
                        EmployeeCode=emp_code,
                        OrganizationID=OrganizationID,
                        defaults={
                            'IsDelete': False,  # Fields to update or set
                            # Add other fields you want to update or set here
                            'Status': "Week Off",
                        }
                    )

                    if created:
                        print("A new object was created.")
                    else:
                        print("An existing object was updated.")
                    
                except Exception as e:
                    error_message = f"Row {index + 1}: An error occurred while processing: {e}"
                    print(error_message)
                    error_messages.append(error_message)
                    continue
            
            if error_messages:
                return JsonResponse({"error": "Some rows contained errors.", "details": error_messages})
            
            print("Weekoff details uploaded successfully.")
            return JsonResponse({"success": "Weekoff details uploaded successfully"})
        
        except Exception as e:
            print(f"An error occurred: {e}")
            return JsonResponse({"error": f"An error occurred: {e}"})
            
    print("Invalid request method.")
    return JsonResponse({"error": "Invalid request method."})

    


# Shfit Managerer
def ShfitList(request):
    if 'OrganizationID' not in request.session:
        return redirect(MasterAttribute.Host)
    else:
        print("Show Page Session")
     
    OrganizationID = request.session["OrganizationID"]
    UserID = str(request.session["UserID"])
    hotelapitoken = MasterAttribute.HotelAPIkeyToken
    headers = {
        'hotel-api-token': hotelapitoken
    }
    
    Approval_url = "http://hotelops.in/API/PyAPI/HREmployeeListForApproval?UserID="+str(UserID)
    
    try:
        response = requests.get(Approval_url, headers=headers)
        response.raise_for_status()
        emp_list = response.json()
        emp_list.sort(key=lambda emp: emp.get('EmployeeCode', '').lower()) 
    except requests.exceptions.RequestException as e:
        print(f"Error fetching approval list: {e}")
        emp_list = []  
    
   
    filtered_emp_list = []
    for emp in emp_list:
        EmployeeCode = emp['EmployeeCode']
        shfit =  ShfitMaster.objects.filter(EmployeeCode=EmployeeCode, OrganizationID=OrganizationID, IsDelete=False).first()
        if shfit:
            emp['ShfitType'] = shfit.ShfitType
            filtered_emp_list.append(emp)
    
    context = {"emp_list": filtered_emp_list}
    return render(request, "EMP_PAY/Shfit/ShfitList.html", context)



from django.http import JsonResponse

def UpdateShift(request):
    if 'OrganizationID' not in request.session:
        return redirect(MasterAttribute.Host)
    else:
        print("Show Page Session")
     
    OrganizationID = request.session["OrganizationID"]
    UserID = str(request.session["UserID"])
    if request.method == "GET":
        EmployeeCode = request.GET.get('EmployeeCode')
        ShiftType = request.GET.get('ShfitType')  

        obj = get_object_or_404(ShfitMaster,EmployeeCode=EmployeeCode, OrganizationID = OrganizationID, IsDelete=False)
       
        obj.ShfitType = ShiftType  
        obj.ModifyBy = UserID
        obj.save()

        response_data = {
            'message': f'Status {ShiftType} updated successfully'  
        }
        return JsonResponse(response_data, status=200)



def IntialShfitCreate(request):
    if 'OrganizationID' not in request.session:
        return redirect(MasterAttribute.Host)
    else:
        print("Show Page Session")
     
    OrganizationID = request.session["OrganizationID"]
    UserID = str(request.session["UserID"])
    hotelapitoken = MasterAttribute.HotelAPIkeyToken
    headers = {
        'hotel-api-token': hotelapitoken
    }
    
    Approval_url = "http://hotelops.in/API/PyAPI/HREmployeeListForApproval?UserID="+str(UserID)
    
    try:
        response = requests.get(Approval_url, headers=headers)
        response.raise_for_status()
        emp_list = response.json()
        emp_list.sort(key=lambda emp: emp.get('EmployeeCode', '').lower()) 
    except requests.exceptions.RequestException as e:
        print(f"Error fetching approval list: {e}")

    create  = request.GET.get('create')
    if create == "True":
        for emp in emp_list:
            EmployeeCode = emp['EmployeeCode']
            ShfitDetails =  ShfitMaster.objects.filter(EmployeeCode= EmployeeCode,OrganizationID =OrganizationID,IsDelete=False).first()
            if ShfitDetails:
                messages.warning(request,f'Shfit is present for {EmployeeCode}')
            ShfitMaster.objects.create(EmployeeCode= EmployeeCode,OrganizationID =OrganizationID,CreatedBy = UserID)    



    messages.success(request,"Created Successfully")
    return redirect('ShfitList')





from django.db.models import Max, Min
from django.shortcuts import redirect, render
from django.contrib import messages
from .models import Raw_Attendance_Data, WeekOffDetails, Attendance_Data
from datetime import datetime, timedelta
import requests

@transaction.atomic
def DumpAttendace(request):
    if 'OrganizationID' not in request.session:
        return redirect(MasterAttribute.Host)
    
    OrganizationID = request.session["OrganizationID"]
    UserID = str(request.session["UserID"])
    
    hotelapitoken = MasterAttribute.HotelAPIkeyToken
    headers = {
        'hotel-api-token': hotelapitoken  
    }
    api_url = "http://hotelops.in/API/PyAPI/HREmployeeList?OrganizationID="+str(OrganizationID)
    
    try:
        response = requests.get(api_url, headers=headers)
        response.raise_for_status() 
        emp_list = response.json()
    except requests.exceptions.RequestException as e:
        print(f"Error occurred: {e}")
    
    if request.method == "POST":
        S_Date_str = request.POST['S_Date']
        E_Date_str = request.POST['E_Date']

        S_Date = datetime.strptime(S_Date_str, '%Y-%m-%d').date()
        E_Date = datetime.strptime(E_Date_str, '%Y-%m-%d').date()

        date_range = [S_Date + timedelta(days=x) for x in range((E_Date - S_Date).days + 1)]
        print(date_range)
        for attendance_date_obj in date_range:
            for emp in emp_list:
                EmployeeCode = emp['EmployeeCode']

                latest_out_time_subquery = Raw_Attendance_Data.objects.filter(
                    EmployeeCode=EmployeeCode,
                    Date=attendance_date_obj,
                    OrganizationID = OrganizationID  ,
                    IsDelete=False,
                    Status='OUT'
                ).aggregate(Max('Time'))

                earliest_in_time_subquery = Raw_Attendance_Data.objects.filter(
                    EmployeeCode=EmployeeCode,
                     OrganizationID = OrganizationID  ,
                    IsDelete=False,
                    Date=attendance_date_obj,
                    Status='IN'
                ).aggregate(Min('Time'))

                latest_out_time = latest_out_time_subquery['Time__max']
                earliest_in_time = earliest_in_time_subquery['Time__min']

                if latest_out_time and earliest_in_time:
                    in_time = datetime.strptime(earliest_in_time, '%H:%M:%S')
                    out_time = datetime.strptime(latest_out_time, '%H:%M:%S')
                    duty_hours = out_time - in_time
                    duty_hours_time = str(duty_hours).split()[-1]

                    attendance_records = {
                        'EmployeeCode': EmployeeCode,
                        'Date': attendance_date_obj,
                        'MinInTime': earliest_in_time,
                        'MaxOutTime': latest_out_time,
                        'DutyHours': duty_hours_time,
                    }

                    status = "Absent"
                    if duty_hours >= timedelta(hours=9):
                        status = "Present"
                    elif duty_hours >= timedelta(hours=5):
                        status = "Half Day Present"

                    attendance_records['status'] = status

                    Attendance_Data.objects.create(
                        EmployeeCode=EmployeeCode,
                        Date=attendance_date_obj,
                        In_Time=attendance_records['MinInTime'],
                        Out_Time=attendance_records['MaxOutTime'],
                        Duty_Hour=attendance_records['DutyHours'],
                        OrganizationID=OrganizationID,
                        CreatedBy=UserID,
                        Status=attendance_records['status'],
                        IsUpload=True
                    )

                else:
                    try:
                        leave = Leave_Application.objects.get(
                            Start_Date__lte=attendance_date_obj,
                            End_Date__gte=attendance_date_obj,
                            IsDelete=False,
                            Emp_code=EmployeeCode,
                            Status=1,
                             OrganizationID = OrganizationID  ,
                   
                        )
                        status = leave.Leave_Type_Master.Type
                    except Leave_Application.DoesNotExist:
                        try:
                            weekoff = WeekOffDetails.objects.get(
                                Emp_Code=EmployeeCode,
                                WeekoffDate=attendance_date_obj,
                                IsDelete=False,
                                 OrganizationID = OrganizationID  ,
                  
                            )
                            status = "WeekOff"
                        except WeekOffDetails.DoesNotExist:
                            status = "Absent"

                    Attendance_Data.objects.create(
                        EmployeeCode=EmployeeCode,
                        Date=attendance_date_obj,
                        In_Time=None,
                        Out_Time=None,
                        Duty_Hour=None,
                        OrganizationID=OrganizationID,
                        CreatedBy=UserID,
                        Status=status,
                        IsUpload=True
                    )

        messages.success(request, 'Attendance data dumped successfully.')
        return redirect('DumpAttendace')
    
    context = {}    
    return render(request, "EMP_PAY/Attendance/DumpAttendace.html", context)
