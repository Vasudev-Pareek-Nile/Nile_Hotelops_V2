from datetime import datetime
import calendar
from HumanResources.views import MultipleDepartmentofEmployee
from django.shortcuts import render,redirect,render
from app.views import OrganizationList,Error
from hotelopsmgmtpy.GlobalConfig import MasterAttribute
from .models import Assessment_Master,Assessment_Factor_Details,Assessment_MasterDeletedFile,UserTypeFlow,DepartmentLevelConfig,DepartmentLevelConfigDetails,Factors,EmployeeDataRequest_Master,EmployeePersonalDataDeletedFile,EmployeePersonalData, EmployeeFamilyData, EmployeeEmergencyInfoData
from Manning_Guide.models import OnRollDepartmentMaster,LavelAdd,OnRollDesignationMaster
from .azure import upload_file_to_blob,download_blob
from django.contrib import messages
import json
from django.views.decorators.csrf import csrf_exempt
import datetime
from Open_position.models import CareerResume
from InterviewAssessment.views import AppliedForORGID,HODLevel,LastApprovalStageFun,repalce_file,upload_file,CopyFileResume,CheckHeadDepartment,ApprovalStageFun
from io import BytesIO
from app.models import OrganizationMaster
from Reference_check.models import ReferenceDetails

from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework import status
from datetime import datetime
import calendar
from django.http import JsonResponse

# ------------------------------------- 100 % Working Code --------------------------------------------------------------------

# @api_view(['GET'])
# def InterviewAssessment_Mobile_List_Api(request):
#     year = request.query_params.get('year')
#     year = int(year) if year else datetime.now().year

#     OrganizationID = request.query_params.get('I')
#     Level = request.query_params.get('Level', 'All')
#     Status = request.query_params.get('Status', 'All')
#     LOIstatus = request.query_params.get('LOIstatus', 'All')
#     month_no = request.query_params.get('month_no')
#     year = request.query_params.get('year')

#     # year = request.query_params.get('year')
#     year = int(year) if year else datetime.now().year

#     # month_no = request.query_params.get('month_no')
#     month_no = int(month_no) if month_no and month_no != 'All' else None
#     month_name = "All Months" if not month_no else calendar.month_name[month_no]

#     today = datetime.today()
#     CYear = today.year
#     CMonth = today.month

#     # OrganizationID = request.session.get("OrganizationID")
#     UserID = request.query_params.get("UserID")
#     EmployeeCode = request.query_params.get("EmployeeCode")
#     SessionOrganizationID = int(OrganizationID)

#     DepartmentList = []
#     if EmployeeCode:
#         Departmentobj = MultipleDepartmentofEmployee(OrganizationID, EmployeeCode)
#         if Departmentobj:
#             DepartmentList = Departmentobj
#         else:
#             return Response({'error': 'Employee Details not Found. Update in Human Resources.'}, status=status.HTTP_404_NOT_FOUND)
#     else:
#         return Response({'error': 'Employee Code is required.'}, status=status.HTTP_400_BAD_REQUEST)

#     Department = 'hr' if 'Human Resources' in DepartmentList else ''
#     UserType = str(request.session.get("UserType", '')).lower()
#     if OrganizationID == '3' and UserType == 'hod':
#         UserType = 'rd'

#     I = OrganizationID
#     if OrganizationID == "3":
#         I = 'All'

#     # if OrganizationID == '3':
#     #     orgs = OrganizationMaster.objects.filter(IsDelete=False, Activation_status=1)
#     # else:
#     #     orgs = OrganizationMaster.objects.filter(IsDelete=False, Activation_status=1, OrganizationID=OrganizationID)

#     # Levels = LavelAdd.objects.filter(IsDelete=False)

#     # Level = request.query_params.get('Level', 'All')
#     # Status = request.query_params.get('Status', 'All')
#     # LOIstatus = request.query_params.get('LOIstatus', 'All')

#     assessments_filter = {'IsDelete': False, 'InterviewDate__year': year}
#     if month_no:
#         assessments_filter['InterviewDate__month'] = month_no
#     if I != 'All':
#         assessments_filter['OrganizationID'] = I
#     if Level != 'All':
#         assessments_filter['Level'] = Level
#     if Status != 'All':
#         assessments_filter['LastApporvalStatus'] = Status
#     else:
#         assessments_filter['LastApporvalStatus__in'] = ['Approved', 'Pending']
#     if LOIstatus != 'All':
#         assessments_filter['LOIStatus'] = LOIstatus

#     Assessments = Assessment_Master.objects.filter(**assessments_filter).order_by('-CreatedDateTime')

#     AssessmentsList = []

#     for Assessment in Assessments:
#         ref = 'Fresher'
#         if Assessment.workexperience != 'Fresher':
#             ref = 0
#             if Assessment.reference:
#                 refobj = ReferenceDetails.objects.filter(
#                     IsDelete=False, OrganizationID=OrganizationID, Inteview_AssementID=Assessment.id
#                 ).first()
#                 if refobj and refobj.ref1_status == 1:
#                     ref = 1
#                 if isinstance(Assessment.reference, str):
#                     ref = 1
#         Assessment.ref = ref

#         AssessmentDepartment = Assessment.Department
#         head_department_obj = CheckHeadDepartment(AssessmentDepartment, Assessment.Level, OrganizationID)
#         head_department = head_department_obj.HeadDepartment if head_department_obj else ''

#         ApprovalStageFunobj = ApprovalStageFun(Assessment.Level, Assessment.Department, Assessment.OrganizationID)

#         Found = False
#         if UserID == '20230110136226':
#             Found = True
#         elif not ApprovalStageFunobj:
#             if any(dept in DepartmentList for dept in ['Human Resources', "Executive Office", "Talent Acquisition and Development", "Corporate Office"]):
#                 Found = True
#         else:
#             if any(dept in DepartmentList for dept in ['Human Resources', "Executive Office", "Talent Acquisition and Development", "Corporate Office"]):
#                 Found = True
#             elif UserType.lower() in [item.lower() for item in ApprovalStageFunobj]:
#                 Found = True

#         if UserType != "ceo":
#             if Found and (
#                 any(dept in DepartmentList for dept in ['Human Resources', "Executive Office", "Talent Acquisition and Development", "Corporate Office"]) or UserID == '20230110136226'
#             ):
#                 AssessmentsList.append(Assessment)
#             elif AssessmentDepartment.strip() in DepartmentList or head_department.strip() in DepartmentList:
#                 if Found:
#                     AssessmentsList.append(Assessment)
#         elif Found:
#             AssessmentsList.append(Assessment)

#     # Serialize the assessments into basic dictionaries
#     assessment_data = []
#     for ass in AssessmentsList:
#         assessment_data.append({
#             'id': ass.id,
#             'CandidateName': f"{ass.Prefix or ''} {ass.Name or ''}".strip(),
#             'Designation':ass.position,
#             # 'CandidateName': ass.Name,
#             # 'InterviewDate': ass.InterviewDate.strftime("%Y-%m-%d") if ass.InterviewDate else None,
#             # 'Department': ass.Department,
#             'Level': ass.Level,
#             'LastApporvalStatus': ass.LastApporvalStatus,
#             # 'LOIStatus': ass.LOIStatus,
#             # 'ref': ass.ref,
#             'OrganizationID':ass.OrganizationID,
#         })

#     return JsonResponse({
#         'Assessments': assessment_data,
#         # 'Organizations': [{'id': o.OrganizationID, 'name': o.OrganizationName} for o in orgs],
#         # 'I': I,
#         # 'Levels': [{'id': l.id, 'name': l.lavelname} for l in Levels],
#         # 'Level': Level,
#         # 'Status': Status,
#         # 'LOIstatus': LOIstatus,
#         # 'SessionOrganizationID': SessionOrganizationID,
#         # 'CYear': list(range(CYear, 2020, -1)),
#         # 'CMonth': CMonth,
#         # 'month_no': month_no if month_no else "All",
#         # 'month_name': month_name,
#         # 'year': year,
#         # 'Department': Department
#     })

# ------------------------------------- / 100 % Working Code --------------------------------------------------------------------

@api_view(['GET'])
def InterviewAssessment_Mobile_List_Api(request):
    OrganizationID_Session = request.query_params.get('OrganizationID_Session')
    OrganizationID = request.query_params.get('OrganizationID')
    Level = request.query_params.get('Level', 'All')
    Status = request.query_params.get('Status', 'All')
    LOIstatus = request.query_params.get('LOIstatus', 'All')
    month_no = request.query_params.get('month_no')
    year = request.query_params.get('year')
    # UserType = str(request.session.get("UserType", '')).lower()
    UserType = request.query_params.get("UserType", '').lower()
    UserID = request.query_params.get("UserID")
    EmployeeCode = request.query_params.get("EmployeeCode")


    # print("New ------------------------------------------------")
    # print("UserType ", UserType)
    # print("I ", OrganizationID)
    # print("OrganizationID type", type(OrganizationID))
    # print("OrganizationID ", OrganizationID)
    # print("UserID ", UserID)
    # print("SessionOrganizationID ", SessionOrganizationID)
    # print("EmployeeCode ", EmployeeCode)
    # print("year ", year)
    # print("month_no ", month_no)
    # print("Level ", Level)
    # print("Status ", Status)
    # print("LOIstatus ", LOIstatus)
    # print("/ End ------------------------------------------------")

    if OrganizationID_Session == "3" and (OrganizationID == '' or None):
        OrganizationID = OrganizationID_Session



    # year = request.query_params.get('year')
    year = int(year) if year else datetime.now().year

    # month_no = request.query_params.get('month_no')
    month_no = int(month_no) if month_no and month_no != 'All' else None
    month_name = "All Months" if not month_no else calendar.month_name[month_no]

    today = datetime.today()
    CYear = today.year
    CMonth = today.month


    DepartmentList = []
    if EmployeeCode:
        Departmentobj = MultipleDepartmentofEmployee(OrganizationID_Session, EmployeeCode)
        if Departmentobj:
            DepartmentList = Departmentobj
        else:
            return Response({'error': 'Employee Details not Found. Update in Human Resources.'}, status=status.HTTP_404_NOT_FOUND)
    else:
        return Response({'error': 'Employee Code is required.'}, status=status.HTTP_400_BAD_REQUEST)

    Department = 'hr' if 'Human Resources' in DepartmentList else ''
    # UserType = str(request.session.get("UserType", '')).lower()
    if OrganizationID == '3' and UserType == 'hod':
        UserType = 'rd'

    I = OrganizationID
    if OrganizationID == "3":
        I = 'All'

    assessments_filter = {'IsDelete': False, 'InterviewDate__year': year}
    if month_no:
        assessments_filter['InterviewDate__month'] = month_no
    if I != 'All':
        assessments_filter['OrganizationID'] = I
    if Level != 'All':
        assessments_filter['Level'] = Level
    if Status != 'All':
        assessments_filter['LastApporvalStatus'] = Status
    else:
        assessments_filter['LastApporvalStatus__in'] = ['Approved', 'Pending']
    if LOIstatus != 'All':
        assessments_filter['LOIStatus'] = LOIstatus

    Assessments = Assessment_Master.objects.filter(**assessments_filter).order_by('-CreatedDateTime')

    AssessmentsList = []

    for Assessment in Assessments:
        ref = 'Fresher'
        if Assessment.workexperience != 'Fresher':
            ref = 0
            if Assessment.reference:
                refobj = ReferenceDetails.objects.filter(
                    IsDelete=False, OrganizationID=OrganizationID, Inteview_AssementID=Assessment.id
                ).first()
                if refobj and refobj.ref1_status == 1:
                    ref = 1
                if isinstance(Assessment.reference, str):
                    ref = 1
        Assessment.ref = ref

        AssessmentDepartment = Assessment.Department
        head_department_obj = CheckHeadDepartment(AssessmentDepartment, Assessment.Level, OrganizationID)
        head_department = head_department_obj.HeadDepartment if head_department_obj else ''

        ApprovalStageFunobj = ApprovalStageFun(Assessment.Level, Assessment.Department, Assessment.OrganizationID)

        Found = False
        if UserID == '20230110136226':
            Found = True
        elif not ApprovalStageFunobj:
            if any(dept in DepartmentList for dept in ['Human Resources', "Executive Office", "Talent Acquisition and Development", "Corporate Office"]):
                Found = True
        else:
            if any(dept in DepartmentList for dept in ['Human Resources', "Executive Office", "Talent Acquisition and Development", "Corporate Office"]):
                Found = True
            elif UserType.lower() in [item.lower() for item in ApprovalStageFunobj]:
                Found = True

        if UserType != "ceo":
            if Found and (
                any(dept in DepartmentList for dept in ['Human Resources', "Executive Office", "Talent Acquisition and Development", "Corporate Office"]) or UserID == '20230110136226'
            ):
                AssessmentsList.append(Assessment)
            elif AssessmentDepartment.strip() in DepartmentList or head_department.strip() in DepartmentList:
                if Found:
                    AssessmentsList.append(Assessment)
        elif Found:
            AssessmentsList.append(Assessment)
        

    # Serialize the assessments into basic dictionaries
    assessment_data = []
    for ass in AssessmentsList:
        org = OrganizationMaster.objects.filter(
            IsDelete=False, Activation_status=1, OrganizationID=ass.OrganizationID
        ).values_list('ShortDisplayLabel', flat=True).first()

        assessment_data.append({
            'id': ass.id,
            'Hotel':org,
            'CandidateName': f"{ass.Prefix or ''} {ass.Name or ''}".strip(),
            'Designation':ass.position,
            # 'CandidateName': ass.Name,
            # 'InterviewDate': ass.InterviewDate.strftime("%Y-%m-%d") if ass.InterviewDate else None,
            # 'Department': ass.Department,
            'Level': ass.Level,
            'LastApporvalStatus': ass.LastApporvalStatus,
            # 'LOIStatus': ass.LOIStatus,
            # 'ref': ass.ref,
            'OrganizationID':ass.OrganizationID,
        })

    return JsonResponse({
        'Assessments': assessment_data,
    })



# ------------------------------------- Trial Version (count API) --------------------------------------------------------------------
from datetime import datetime, timedelta

@api_view(['GET'])
def InterviewAssessment_Mobile_Count_Api(request):
    OrganizationID_Session = request.query_params.get('OrganizationID_Session')
    OrganizationID = request.query_params.get('OrganizationID')
    Level = request.query_params.get('Level', 'All')
    Status = request.query_params.get('Status', 'All')
    LOIstatus = request.query_params.get('LOIstatus', 'All')
    month_no = request.query_params.get('month_no')
    year = request.query_params.get('year')
    # UserType = str(request.session.get("UserType", '')).lower()
    UserType = request.query_params.get("UserType", '').lower()
    UserID = request.query_params.get("UserID")
    EmployeeCode = request.query_params.get("EmployeeCode")


    # print("New ------------------------------------------------")
    # print("UserType ", UserType)
    # print("I ", OrganizationID)
    # print("OrganizationID type", type(OrganizationID))
    # print("OrganizationID ", OrganizationID)
    # print("UserID ", UserID)
    # print("SessionOrganizationID ", SessionOrganizationID)
    # print("EmployeeCode ", EmployeeCode)
    # print("year ", year)
    # print("month_no ", month_no)
    # print("Level ", Level)
    # print("Status ", Status)
    # print("LOIstatus ", LOIstatus)
    # print("/ End ------------------------------------------------")

    if OrganizationID_Session == "3" and (OrganizationID == '' or None):
        OrganizationID = OrganizationID_Session



    # year = request.query_params.get('year')
    year = int(year) if year else datetime.now().year

    # month_no = request.query_params.get('month_no')
    month_no = int(month_no) if month_no and month_no != 'All' else None
    month_name = "All Months" if not month_no else calendar.month_name[month_no]

    # today = datetime.today()
    # CYear = today.year
    # CMonth = today.month
    
    today = datetime.today().date()
    yesterday = today - timedelta(days=1)
    today_yesterday_count = 0


    DepartmentList = []
    if EmployeeCode:
        Departmentobj = MultipleDepartmentofEmployee(OrganizationID_Session, EmployeeCode)
        if Departmentobj:
            DepartmentList = Departmentobj
        else:
            return Response({'error': 'Employee Details not Found. Update in Human Resources.'}, status=status.HTTP_404_NOT_FOUND)
    else:
        return Response({'error': 'Employee Code is required.'}, status=status.HTTP_400_BAD_REQUEST)

    Department = 'hr' if 'Human Resources' in DepartmentList else ''
    # UserType = str(request.session.get("UserType", '')).lower()
    if OrganizationID == '3' and UserType == 'hod':
        UserType = 'rd'

    I = OrganizationID
    if OrganizationID == "3":
        I = 'All'

    assessments_filter = {'IsDelete': False, 'InterviewDate__year': year}
    if month_no:
        assessments_filter['InterviewDate__month'] = month_no
    if I != 'All':
        assessments_filter['OrganizationID'] = I
    if Level != 'All':
        assessments_filter['Level'] = Level
    if Status != 'All':
        assessments_filter['LastApporvalStatus'] = Status
    else:
        assessments_filter['LastApporvalStatus__in'] = ['Approved', 'Pending']
    if LOIstatus != 'All':
        assessments_filter['LOIStatus'] = LOIstatus

    Assessments = Assessment_Master.objects.filter(**assessments_filter).order_by('-CreatedDateTime')

    AssessmentsList = []


    for Assessment in Assessments:
        ref = 'Fresher'
        if Assessment.workexperience != 'Fresher':
            ref = 0
            if Assessment.reference:
                refobj = ReferenceDetails.objects.filter(
                    IsDelete=False, OrganizationID=OrganizationID, Inteview_AssementID=Assessment.id
                ).first()
                if refobj and refobj.ref1_status == 1:
                    ref = 1
                if isinstance(Assessment.reference, str):
                    ref = 1
        Assessment.ref = ref

        AssessmentDepartment = Assessment.Department
        head_department_obj = CheckHeadDepartment(AssessmentDepartment, Assessment.Level, OrganizationID)
        head_department = head_department_obj.HeadDepartment if head_department_obj else ''

        ApprovalStageFunobj = ApprovalStageFun(Assessment.Level, Assessment.Department, Assessment.OrganizationID)

        Found = False
        if UserID == '20230110136226':
            Found = True
        elif not ApprovalStageFunobj:
            if any(dept in DepartmentList for dept in ['Human Resources', "Executive Office", "Talent Acquisition and Development", "Corporate Office"]):
                Found = True
        else:
            if any(dept in DepartmentList for dept in ['Human Resources', "Executive Office", "Talent Acquisition and Development", "Corporate Office"]):
                Found = True
            elif UserType.lower() in [item.lower() for item in ApprovalStageFunobj]:
                Found = True

        if UserType != "ceo":
            if Found and (
                any(dept in DepartmentList for dept in ['Human Resources', "Executive Office", "Talent Acquisition and Development", "Corporate Office"]) or UserID == '20230110136226'
            ):
                AssessmentsList.append(Assessment)
            elif AssessmentDepartment.strip() in DepartmentList or head_department.strip() in DepartmentList:
                if Found:
                    AssessmentsList.append(Assessment)
        elif Found:
            AssessmentsList.append(Assessment)
        
            # 👇 Count today or yesterday
        if Assessment.InterviewDate and Assessment.CreatedDateTime.date() in [today, yesterday]:
            today_yesterday_count += 1

    # Serialize the assessments into basic dictionaries
    assessment_data = []
    for ass in AssessmentsList:
        org = OrganizationMaster.objects.filter(
            IsDelete=False, Activation_status=1, OrganizationID=ass.OrganizationID
        ).values_list('ShortDisplayLabel', flat=True).first()

        assessment_data.append({
            'id': ass.id,
            'Hotel':org,
            'CandidateName': f"{ass.Prefix or ''} {ass.Name or ''}".strip(),
            'Designation':ass.position,
            # 'CandidateName': ass.Name,
            # 'InterviewDate': ass.InterviewDate.strftime("%Y-%m-%d") if ass.InterviewDate else None,
            # 'Department': ass.Department,
            'Level': ass.Level,
            'LastApporvalStatus': ass.LastApporvalStatus,
            # 'LOIStatus': ass.LOIStatus,
            # 'ref': ass.ref,
            'OrganizationID':ass.OrganizationID,
        })

    return JsonResponse({
        # 'Assessments': assessment_data,
        'total_count': len(assessment_data),
        'today_yesterday_count': today_yesterday_count
    })


# @csrf_exempt
# def InterviewAssessment_Mobile_List_Api(request):
#     OrganizationID = request.GET.get("OrganizationID")
#     UserID = request.GET.get("UserID")
#     EmployeeCode = request.GET.get("EmployeeCode")
#     UserType = request.GET.get("UserType", '').lower()

#     year = int(request.GET.get('year', datetime.now().year))
#     month_no = request.GET.get('month_no')
#     if month_no and month_no != 'All':
#         month_no = int(month_no)
#     else:
#         month_no = None

#     DepartmentList = MultipleDepartmentofEmployee(OrganizationID, EmployeeCode) or []

#     Department = 'hr' if 'Human Resources' in DepartmentList else ''
#     if OrganizationID == '3' and UserType == 'hod':
#         UserType = 'rd'

#     I = request.GET.get('I', OrganizationID)
#     Level = request.GET.get('Level', 'All')
#     Status = request.GET.get('Status', 'All')
#     LOIstatus = request.GET.get('LOIstatus', 'All')

#     filters = {
#         'IsDelete': False,
#         'InterviewDate__year': year,
#     }

#     if month_no:
#         filters['InterviewDate__month'] = month_no
#     if I != 'All':
#         filters['OrganizationID'] = I
#     if Level != 'All':
#         filters['Level'] = Level
#     if Status != 'All':
#         filters['LastApporvalStatus'] = Status
#     else:
#         filters['LastApporvalStatus__in'] = ['Approved', 'Pending']
#     if LOIstatus != 'All':
#         filters['LOIStatus'] = LOIstatus

#     assessments = Assessment_Master.objects.filter(**filters).order_by('-CreatedDateTime')
#     AssessmentsList = []

#     for ass in assessments:
#         ref = 'Fresher'
#         if ass.workexperience != 'Fresher':
#             ref = 0
#             if ass.reference:
#                 refobj = ReferenceDetails.objects.filter(IsDelete=False, OrganizationID=OrganizationID, Inteview_AssementID=ass.id).first()
#                 if refobj and refobj.ref1_status == 1:
#                     ref = 1
#                 if isinstance(ass.reference, str):
#                     ref = 1
#         ass.ref = ref

#         head_department_obj = CheckHeadDepartment(ass.Department, ass.Level, ass.OrganizationID)
#         head_department = head_department_obj.HeadDepartment if head_department_obj else ""

#         ApprovalStageFunobj = ApprovalStageFun(ass.Level, ass.Department, ass.OrganizationID)
#         Found = False

#         if not ApprovalStageFunobj:
#             if any(d in DepartmentList for d in ['Human Resources', 'Executive Office', 'Talent Acquisition and Development', 'Corporate Office']):
#                 Found = True
#         elif UserType in [stage.lower() for stage in ApprovalStageFunobj]:
#             Found = True

#         if UserType != "ceo":
#             if Found and (
#                 any(d in DepartmentList for d in ['Human Resources', 'Executive Office', 'Talent Acquisition and Development', 'Corporate Office']) or
#                 UserID == '20230110136226' or
#                 ass.Department.strip() in DepartmentList or
#                 head_department.strip() in DepartmentList
#             ):
#                 AssessmentsList.append(ass)
#         elif Found:
#             AssessmentsList.append(ass)

#     data = [{
#         "id": a.id,
#         "CandidateName": a.CandidateName,
#         "Level": a.Level,
#         "Department": a.Department,
#         "InterviewDate": a.InterviewDate,
#         "LastApporvalStatus": a.LastApporvalStatus,
#         "ref": a.ref
#     } for a in AssessmentsList]

#     return JsonResponse({
#         "success": True,
#         "data": data,
#         "year": year,
#         "month_no": month_no or "All"
#     }, safe=False)
