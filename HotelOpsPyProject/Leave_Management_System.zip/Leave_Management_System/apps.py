from django.apps import AppConfig


class LeaveManagementSystemConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Leave_Management_System'
