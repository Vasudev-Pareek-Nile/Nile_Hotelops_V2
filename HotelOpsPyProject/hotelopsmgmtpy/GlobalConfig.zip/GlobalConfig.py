from app.models import OrganizationMaster


class MasterAttribute:
    CurrentHost="http://localhost:50970"
    Host = "http://hotelops.in"
    DomainCode = ""
    Logout = "hotelops.in/Home/Logout?Token="
    HomeURL = "hotelops.in/Master/Product?Token="
    ChangePassword = "hotelops.in/Master/ChangePassword?Token="
    MonthList=["","Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"]
    HotelAPIkeyToken="WfEj45ON8BKl!udLGPu!szcWtY!e9MTm4jpXSqD7wNM1HITpnbJhhp=aElxgkShcdaBhvgqLeOMjz9G?qliY6FK/AcJN0iTB3fIl5g55bllJHdrF-Yh-O4W-eEjKaPk/DBGqHU6XDhbG5m68RtVxZGH?B6n1F5u=F84npBeJIMS/SzrT7=dXuAj=8aqDyvRpIh=nswd!XPTMobzhw2jKxocrOYJkzo0osZFSMxK1hMqRbqGJIKR=bgRfS!cea2fb"
    azure_storage_account_key = "PV6pykN3d/a4jjH64vEd4qsQUGQuohDthY2JUGN9z5+9EmoGBJpabNShKP0rJOAxWj5kvwAXD1BPUUUSUZgSfg=="
    azure_storage_account_name = "hotelopsblob"
    azure_connection_string = "DefaultEndpointsProtocol=https;AccountName=hotelopsblob;AccountKey=PV6pykN3d/a4jjH64vEd4qsQUGQuohDthY2JUGN9z5+9EmoGBJpabNShKP0rJOAxWj5kvwAXD1BPUUUSUZgSfg==;BlobEndpoint=https://hotelopsblob.blob.core.windows.net/;QueueEndpoint=https://hotelopsblob.queue.core.windows.net/;TableEndpoint=https://hotelopsblob.table.core.windows.net/;FileEndpoint=https://hotelopsblob.file.core.windows.net/;"


class OrganizationDetail:
    def __init__(self, OrganizationID):
        # Initialize attributes with default values
        self.OrganizationID = OrganizationID
        self.Organization_name = ""
        self.OrganizationLogo = ""
        self.OrganizationDomainCode = ""
        self.ShortDisplayLabel = ""
        
        # Retrieve user details from the model
        try:
            user = OrganizationMaster.objects.get(OrganizationID=OrganizationID)
            self.Organization_name = user.Organization_name  # Replace 'username' with the actual field name
            self.OrganizationLogo = "https://hotelopsblob.blob.core.windows.net/hotelopslogos/"+user.OrganizationLogo  # Replace 'full_name' with the actual field name
            self.OrganizationDomainCode = user.OrganizationDomainCode  # Replace 'full_name' with the actual field name
            self.ShortDisplayLabel = user.ShortDisplayLabel  # Replace 'full_name' with the actual field name
        except OrganizationMaster.DoesNotExist:
            # Handle the case where the user does not exist in the database
            pass

    def get_Organization_name(self):
        return self.Organization_name

    def get_OrganizationLogo(self):
        return self.OrganizationLogo
    def get_OrganizationDomainCode(self):
        return self.OrganizationDomainCode
    def get_ShortDisplayLabel(self):
        return self.ShortDisplayLabel